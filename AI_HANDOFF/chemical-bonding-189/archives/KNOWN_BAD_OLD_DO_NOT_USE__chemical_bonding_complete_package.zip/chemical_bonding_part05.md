## Part 5 — Bond Parameters and Molecular Polarity

### 5.1 Bond Length

**Bond length** is the equilibrium internuclear distance $r_0$ introduced in §1.2 — the separation at which the potential-energy curve reaches its minimum. It is measured directly (X-ray diffraction, microwave/rotational spectroscopy) and can also be estimated as the sum of the two atoms' **covalent radii**, each defined as half the bond length in a symmetric homonuclear molecule of that element (e.g., $r_{\mathrm{cov}}(\mathrm{Cl}) = \tfrac{1}{2} d(\mathrm{Cl-Cl})$).

**Bond order and bond length.** For a given pair of atoms, higher bond order means more shared electron density concentrated between the nuclei (§2.2), which pulls the nuclei closer together — bond length falls as bond order rises. Verified numerically (`Chemical_Bonding_Kohinoor_.pdf` p.142):

$$\mathrm{C{\equiv}C \; (BO=3,\ C_2H_2) < C{=}C \; (BO=2,\ C_2H_4) < C{\cdots}C \; (BO=1.5,\ C_6H_6) < C{-}C \; (BO=1,\ C_2H_6)}$$

in bond length (shortest to longest), and equivalently for the carbon–oxygen series:

$$\mathrm{CO \; (BO=3) < CO_2 \; (BO=2) < CO_3^{2-} \; (BO=1.33)}$$

in bond length. This is the same relationship stated in Worked Example 2.3's resonance discussion (fractional bond order in $\mathrm{NO_3^-}$, bond order $4/3$) and will recur as the organizing principle for bond-length ordering questions throughout Part 13.

### 5.2 Bond Angle

Bond angle is the angle subtended at the central atom between two of its bonds. It is controlled primarily by electron-domain repulsion (developed fully as VSEPR theory in Part 9); here it is introduced only as a measurable bond parameter, with the general statement that increasing lone-pair character on the central atom, or increasing s-character in the bonding hybrid orbital, systematically affects the angle (Bent's rule, Part 8) — both threads are picked up in full in their dedicated Parts.

### 5.3 Bond Dissociation Enthalpy and Mean Bond Enthalpy

**Bond dissociation enthalpy** is the energy required to break one specific bond in a specific molecule into gaseous atoms/fragments, holding everything else fixed. For a polyatomic molecule with several chemically identical-looking bonds, the dissociation enthalpy of the *first* bond broken is generally different from that of the *second*, *third*, etc., because breaking one bond changes the electronic environment of the remaining ones.

**Mean bond enthalpy** is the *average* of the successive dissociation enthalpies for chemically equivalent bonds in a given type of molecule, and it is this averaged quantity — not any single dissociation step — that is tabulated as "the" C–H bond enthalpy, O–H bond enthalpy, etc., for use in Hess's-law-type enthalpy estimates.

> **Important Conceptual Distinction** — Bond dissociation enthalpy (one specific, measurable bond-breaking step) and mean bond enthalpy (an average over several such steps for a class of bonds) are frequently conflated. A mean bond enthalpy is an estimate useful for approximate calculations; it is not the exact energy of any one real bond-breaking event in a specific molecule.

Bond enthalpy is systematically affected by:
- **Bond order** — higher order, stronger bond (§5.1's ordering logic applies equally to bond strength as to bond length: $\mathrm{C \equiv C > C = C > C - C}$ in bond enthalpy).
- **Atomic size** — smaller atoms generally give shorter, stronger bonds (more effective orbital overlap at closer range, §1.2).
- **Bond polarity** — a polar bond is often (though not universally) somewhat stronger than the purely covalent, non-polar prediction would suggest, because the ionic-resonance-energy contribution (Part 6) adds extra stabilization.

**Worked example 5.1 — Numerical bond-length/BDE cross-check**

*Problem:* Using the data $r$(HF) shorter than $r$(HCl), and $D$(HF) $>$ $D$(HCl) $>$ $D$(HBr) $>$ $D$(HI) (all confirmed against `Chemical_Bonding_Kohinoor_.pdf` p.144's tabulated X–H bond-length/dissociation-energy data), explain the trend.

*Reasoning:* Descending the halogen group, atomic (and hence covalent) radius increases substantially (F<Cl<Br<I), so H–X bond length increases correspondingly. Longer bond length means less effective orbital overlap (§1.2's potential-energy-well argument: a shallower, wider well for a longer, weaker bond), so bond dissociation enthalpy falls in step.

*Conclusion:* $r$(H–F) $<$ $r$(H–Cl) $<$ $r$(H–Br) $<$ $r$(H–I), while $D$(H–F) $>$ $D$(H–Cl) $>$ $D$(H–Br) $>$ $D$(H–I) — bond length and bond enthalpy move in *opposite* directions along this series, which is the general rule (shorter ⇒ stronger) rather than an exception.

### 5.4 Electronegativity

**Electronegativity** is the relative tendency of an atom, within a molecule, to attract the shared pair of a covalent bond toward itself. It is a relational property — meaningful only in the context of a bond to another specific atom, unlike an isolated-atom property such as ionization energy.

**Pauling's scale** defines electronegativity operationally from the "excess" bond energy of a polar A–B bond over the geometric mean of the A–A and B–B bond energies — the physical idea being that if A and B had *identical* electronegativity, the A–B bond would simply be the average of the two homonuclear bond strengths; any *extra* stabilization beyond that average reflects the additional ionic-resonance-energy contribution from unequal sharing (Part 6 revisits this same "extra stabilization from charge separation" idea in the context of resonance energy generally).

$$\chi_A - \chi_B \propto \sqrt{E_{AB} - \sqrt{E_{AA}\cdot E_{BB}}}$$

Electronegativity, as a general trend, increases across a period (increasing nuclear charge, roughly constant shielding, so valence electrons are held more tightly) and decreases down a group (increasing atomic size and shielding outweigh the increased nuclear charge).

### 5.5 Bond Polarity, Dipole Moment, and Percentage Ionic Character

**Bond polarity** arises whenever two bonded atoms differ in electronegativity: the shared electron pair is not shared equally, and a partial negative charge $\delta^-$ develops on the more electronegative atom, with a corresponding partial positive charge $\delta^+$ on the other.

**Dipole moment** quantifies this charge separation:

$$\mu = q \times d$$

where $q$ is the magnitude of the separated charge and $d$ is the distance between the charge centres. Dipole moment is a **vector quantity**, conventionally drawn from the less electronegative to the more electronegative atom (i.e., pointing toward the negative end), measured in **debye** ($1\text{ D} = 10^{-18}\text{ esu cm} = 3.33\times10^{-30}\text{ C m}$).

**Bond moment vs. molecular dipole moment.** For a diatomic molecule, the bond moment *is* the molecular dipole moment. For a polyatomic molecule, the overall molecular dipole moment is the **vector sum** of every individual bond moment *and* every lone-pair moment present — this is the direct link between dipole moment (a bulk, measurable property) and molecular shape (Part 9), since vector addition depends entirely on the geometric arrangement of the bonds and lone pairs.

**Lone-pair moment.** A lone pair occupying a pure $s$ or pure $p$ orbital contributes nothing to the net dipole moment (an $s$ orbital is spherically symmetric; a pure $p$ orbital's two lobes point in exactly opposite directions and cancel). A lone pair occupying a **hybrid** orbital, however, is asymmetric (§1.8-style "one lobe small, one lobe large" hybrid-orbital shape) and contributes a real, often substantial, moment directed from the small lobe toward the large lobe.

**Worked example 5.2 — Why NH₃ has a much larger dipole moment than NF₃, despite similar bond-electronegativity differences**

*Problem:* $\Delta\chi(\mathrm{N-H}) \approx 0.9$ and $\Delta\chi(\mathrm{N-F}) \approx 1.0$ — comparable electronegativity differences — yet $\mu(\mathrm{NH_3}) = 1.47\text{ D}$ while $\mu(\mathrm{NF_3}) = 0.24\text{ D}$, a six-fold difference. Explain.

*Reasoning:* In both molecules, N carries a lone pair in a hybrid orbital pointing away from the three bonded atoms, contributing a lone-pair moment $\mu_L$ directed away from the bonding face (toward the "top" of the pyramid, in the direction of the lone pair). The bond-moment resultant $\mu_R$ (vector sum of the three N–X bond moments) also points along this same axis, but its *direction relative to N* depends on which atom is more electronegative:
- In $\mathrm{NH_3}$, N is more electronegative than H, so each N–H bond moment points *toward* N (away from the H atoms). This resultant $\mu_R$ points in the *same general direction* as the lone-pair moment $\mu_L$ — **they add**, giving a large net dipole moment.
- In $\mathrm{NF_3}$, F is more electronegative than N, so each N–F bond moment points *away from* N (toward the F atoms) — the *opposite* direction to the $\mathrm{NH_3}$ case. This resultant **opposes** the lone-pair moment $\mu_L$ — the two largely **cancel**, leaving only a small net dipole moment.

*Conclusion:* the six-fold difference is not primarily a story about electronegativity-difference magnitude (which is comparable in both cases) — it is a story about the *relative direction* of the bond-moment resultant versus the lone-pair moment, which flips depending on whether the central atom is more or less electronegative than its substituents. The same reasoning applies directly to $\mathrm{H_2O}$ ($\mu = 1.84\text{ D}$, bond and lone-pair moments add) vs. $\mathrm{F_2O}$ ($\mu = 0.30\text{ D}$, bond and lone-pair moments oppose).

![Figure 5.1: Dipole vectors in NH3 vs NF3](figures/fig5_1_dipole_nh3_nf3.svg)

**Figure 5.1.** Bond-moment resultant (green) and lone-pair moment (red) add in NH₃ (N more electronegative than the substituent) but oppose in NF₃ (substituent more electronegative than N) — the direction relationship, not the magnitude of $\Delta\chi$ alone, controls the large observed difference in net dipole moment.

*Common mistake:* trying to explain the NH₃-vs-NF₃ dipole moment gap using electronegativity-difference magnitude alone — a genuinely common error, since the magnitudes are in fact similar and the real explanation is entirely about relative vector direction.

**Worked example 5.3 — Calculating percentage ionic character from dipole moment**

*Problem:* The dipole moment of HCl is $1.03\text{ D}$ and the H–Cl bond length is $1.27\text{ Å}$. Calculate the percentage ionic character of the H–Cl bond.

*Concept tested:* the ratio of the *observed* dipole moment to the dipole moment the bond *would have if it were 100% ionic* (i.e., if a full electronic charge $e$ were completely transferred and separated by the actual bond length) gives the fractional ionic character.

*Reasoning:* First calculate the hypothetical 100%-ionic dipole moment, $\mu_{\text{calc}} = e \times d$:

$$\mu_{\text{calc}} = (4.8\times10^{-10}\text{ esu}) \times (1.27\times10^{-8}\text{ cm}) = 6.10\times10^{-18}\text{ esu cm} = 6.10\text{ D}$$

Then:

$$\%\text{ ionic character} = \dfrac{\mu_{\text{obs}}}{\mu_{\text{calc}}}\times 100 = \dfrac{1.03}{6.10}\times100 = 16.9\%$$

*Conclusion:* the H–Cl bond is approximately 17% ionic and correspondingly about 83% covalent — consistent with chlorine's substantial but not extreme electronegativity relative to hydrogen, and a useful concrete anchor figure for calibrating intuition about what "significant but minority ionic character" looks like numerically in a bond usually classified simply as "polar covalent."

*Common mistake:* forgetting that $\mu_{\text{calc}}$ must use the *electronic charge* $e$ (the 100%-ionic, one-full-charge-transferred hypothetical) rather than any other charge value — the percentage ionic character calculation is specifically a comparison against this one well-defined reference point, not a general formula with a free parameter.

### 5.6 Molecular Shape from Dipole Moment — Symmetry and Cancellation

Because molecular dipole moment is a vector sum, a **non-zero measured dipole moment directly rules out any perfectly symmetric geometry** in which the bond moments would cancel exactly, and this becomes a genuine structure-determination tool:

| Molecular type | $\mu = 0$ implies | $\mu \ne 0$ implies |
|---|---|---|
| $\mathrm{AX_2}$ | Linear (e.g., $\mathrm{BeCl_2}$, $\mathrm{XeF_2}$, $\mathrm{CO_2}$) | Bent/angular (e.g., $\mathrm{H_2O}$, $\mathrm{SO_2}$, $\mathrm{SCl_2}$) |
| $\mathrm{AX_3}$ | Trigonal planar (e.g., $\mathrm{BF_3}$, $\mathrm{AlCl_3}$) | Pyramidal or T-shaped (e.g., $\mathrm{NH_3}$; $\mathrm{ClF_3}$) |
| $\mathrm{AX_4}$ | Tetrahedral or square planar (e.g., $\mathrm{CH_4}$; $\mathrm{XeF_4}$) | See-saw (e.g., $\mathrm{SF_4}$) |
| $\mathrm{AX_5}$ | Trigonal bipyramidal (e.g., $\mathrm{PF_5}$) | Square pyramidal (e.g., $\mathrm{XeF_5^+}$) |
| $\mathrm{AX_6}$ | Regular octahedral (e.g., $\mathrm{SF_6}$) | Distorted (any deviation) |

![Figure 5.2: CO2 dipole cancellation](figures/dipoles/fig_dipole_co2.svg)
![Figure 5.3: BF3 dipole cancellation](figures/dipoles/fig_dipole_bf3.svg)
![Figure 5.4: CH4 dipole cancellation](figures/dipoles/fig_dipole_ch4.svg)

**Figures 5.2–5.4.** Three zero-dipole examples spanning steric numbers 2–4: in every case individual bonds are polar, but the symmetric arrangement forces the vector sum to zero — nonpolar bonds are never the reason (CO₂'s C=O and BF₃'s B–F bonds are both substantially polar); geometry is.

![Figure 5.5: H2O dipole reinforcement](figures/dipoles/fig_dipole_h2o.svg)
![Figure 5.6: XeF4 dipole cancellation](figures/dipoles/fig_dipole_xef4.svg)
![Figure 5.7: SF4 net dipole](figures/dipoles/fig_dipole_sf4.svg)
![Figure 5.8: ClF3 net dipole](figures/dipoles/fig_dipole_clf3.svg)

**Figures 5.5–5.8.** H₂O (bond dipoles and lone-pair-axis moment reinforce, §5.5's mechanism), XeF₄ (perfectly cancels despite bearing lone pairs — the *trans* lone-pair placement established in §9.5 is itself symmetric), and SF₄/ClF₃ (asymmetric electron-domain arrangements with no cancelling symmetry, net dipole shown as the resultant vector) — directly connecting each dipole outcome to the specific VSEPR geometry established in Part 9 for that species.

**Worked example 5.4 — Distinguishing cis and trans isomers by dipole moment**

*Problem:* Two isomers of $\mathrm{N_2F_2}$ exist. One has essentially zero dipole moment; the other has a small but distinctly non-zero dipole moment ($\approx 0.16\text{ D}$). Assign each isomer.

*Reasoning:* In the *trans* isomer, the two N–F bond moments point in opposite directions across the N=N axis and cancel exactly by symmetry — $\mu = 0$. In the *cis* isomer, the two N–F bond moments (and the two nitrogen lone-pair moments) point on the *same* side, so they do not cancel — $\mu \ne 0$.

*Conclusion:* the essentially-zero-dipole isomer is *trans*-$\mathrm{N_2F_2}$; the small-but-nonzero-dipole isomer is *cis*-$\mathrm{N_2F_2}$.

*Common mistake:* assuming a "small" non-zero dipole moment must indicate a highly polar or asymmetric structure — here, the *cis* isomer's dipole moment is small in *absolute* terms (0.16 D) precisely because the two contributing moments only partially reinforce each other (they are not aligned in exactly the same direction), even though the molecule is unambiguously non-centrosymmetric. The qualitative conclusion (zero vs. non-zero) is what carries the structural information, not the precise numerical size of a small non-zero value.

> **Exception — a non-zero dipole moment alone does not uniquely fix a structure.** Two different structural isomers of the same molecular formula (not just cis/trans forms of one connectivity) can each have $\mu \ne 0$, so a non-zero reading only *rules out* the symmetric possibility — it does not, by itself, distinguish between multiple asymmetric candidates without additional structural information (e.g., NMR, IR, or independently known connectivity).

### 5.7 Percentage Ionic Character vs. Ionic Character — A Terminology Distinction

**Important Conceptual Distinction:** "ionic character" (qualitative — is the bond better described as more ionic or more covalent, Ketelaar's triangle, §1.4) and "**percentage** ionic character" (a specific, numerically defined quantity, Worked Example 5.3) are related but not interchangeable terms. A bond can be correctly described qualitatively as "predominantly covalent with some ionic character" while also having a precisely calculable percentage ionic character (e.g., HCl's 17%) — the percentage is the quantitative backbone underneath the qualitative label, not a separate concept.

> **Model Limitation** — The percentage-ionic-character calculation (Worked Example 5.3) assumes the bond length used is accurate and that $e \times d$ is a physically meaningful "fully ionic" reference — both reasonable approximations for simple diatomics, but the method becomes progressively less reliable for polyatomic molecules, where the "bond length" of one specific bond within a larger structure may not isolate cleanly from the rest of the molecule's electronic structure, and where a molecule's overall measured dipole moment reflects the *vector sum* of several bonds (§5.6) rather than any single bond in isolation.

### Part 5 Summary

- Bond length and bond order are inversely related (higher order ⇒ shorter bond) for a given pair of atoms; bond length and bond dissociation enthalpy move in the same "shorter is stronger" direction across a homologous series, and in opposite numerical directions across a series where atomic size is the controlling variable (§5.3).
- Electronegativity (Pauling scale) is a relational, bond-context-dependent property, operationally defined from the "extra" stabilization energy of a polar bond beyond the non-polar reference.
- Dipole moment is a vector sum of bond moments and lone-pair moments; whether these add or cancel — not merely the size of the electronegativity difference — controls the resulting net molecular dipole moment (NH₃ vs. NF₃, Worked Example 5.2).
- Percentage ionic character is calculated as $(\mu_{\text{obs}}/\mu_{\text{calc}})\times100$, where $\mu_{\text{calc}} = e \times d$ is the hypothetical fully-ionic reference (Worked Example 5.3, HCl = 17% ionic).
- A zero net dipole moment is a reliable, specific structural signature of a symmetric geometry and is a genuine shape-determination tool, including for distinguishing cis/trans isomers — but a non-zero reading alone only rules out full symmetry, without uniquely fixing the remaining structure.

---

## Source Traceability — Part 5

| Source PDF | Pages | Material found | Destination | Status |
|---|---|---|---|---|
| `CHEMICAL_BONDING.pdf` | §3.14 (Dipole Moment, full section) | Definition, bond moment, lone-pair moment mechanism and magnitude order (sp>sp²>sp³), NH₃/NF₃ and H₂O/F₂O comparisons, %ionic character formula, AX₂–AX₇ shape-from-dipole-moment table, cis/trans N₂F₂, ortho/meta/para disubstituted benzene dipole ordering, special cases (CO's anomalously low dipole moment, mesomeric-effect reversals) | §5.5, §5.6 | INCORPORATED |
| `Chemical_Bonding_Kohinoor_.pdf` | p.120 (of 261) | HCl %ionic character fully worked numerical example — independently re-derived and verified in this pass, arithmetic confirmed correct | Worked Example 5.3 | INCORPORATED |
| `Chemical_Bonding_Kohinoor_.pdf` | p.142 | Bond-order-vs-bond-length data (C₂H₂/C₂H₄/C₆H₆/C₂H₆; CO/CO₂/CO₃²⁻) | §5.1 | INCORPORATED |
| `Chemical_Bonding_Kohinoor_.pdf` | p.144 | X–H bond-length/dissociation-energy data table across halogens | Worked Example 5.1 | INCORPORATED |
| `Chemical_Bonding_Kohinoor_.pdf` | pp.95, 97, 102, 111 | Bond angle vs. %s-character, C–H bond strength in CH₃Cl/CH₃F, P–Cl bond length in fluorochlorophosphoranes, extensive B/C/N back-bonding bond-length table | Flagged as Part 7/8/9 scope (hybridization, back-bonding) | PENDING LATER PART — not force-fit into Part 5 |
| `cbvj.pdf`, `Chemical Bonding (E)/1–12.pdf` | full existing OCR index re-queried (dipole, electronegativity, bond length, bond order, debye, percentage ionic) | No new material beyond what is already logged in the Parts 1–4 matrix under "bond length" hits (all previously confirmed to belong to Part 7/8/9 scope: overlap types, VSEPR steric number) | — | IRRELEVANT TO PART 5 / already logged elsewhere |

---

*Part 5 complete. Continuing to Part 6 (Resonance and Delocalisation).*
