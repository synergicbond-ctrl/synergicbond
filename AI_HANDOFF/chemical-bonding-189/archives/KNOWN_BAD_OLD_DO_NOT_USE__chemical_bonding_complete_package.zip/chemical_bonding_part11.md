## Part 11 — Hydrogen Bonding and Intermolecular Forces

### 11.1 Why Intermolecular Forces Are Needed at All

Kinetic theory's simplest model treats gas molecules as non-interacting. Real gases liquefy and solidify, which is direct evidence that some attractive force acts **between** already-complete molecules, over and above the covalent/ionic bonding that holds each molecule's own atoms together (§1.4's classification table, revisited here in full depth). These forces are collectively termed **van der Waals forces** and are categorically weaker than covalent, ionic, or even hydrogen bonds (§1.4's table), but they are what determines bulk physical properties — melting point, boiling point, viscosity, solubility — for molecular substances.

### 11.2 The Three van der Waals Interactions

**(a) Dipole–dipole interaction (Keesom forces).** Two polar molecules orient so that oppositely-charged ends attract — either head-to-tail or antiparallel, depending on molecular shape — with the interaction strength falling off as $1/r^3$ (verified against `CHEMICAL_BONDING.pdf` §3.30's energy-distance table). This is the direct extension of the single-bond dipole-moment concept (Part 5) to *intermolecular*, rather than intramolecular, electrostatics.

**(b) Dipole-induced dipole interaction (Debye forces).** A polar molecule's electric field can distort (polarize — the same physical mechanism as anion polarisation, §4.2, now acting on a whole neutral, non-ionic molecule rather than an anion) the electron cloud of a nearby non-polar molecule, inducing a temporary dipole that is then attracted to the permanent dipole. This is the mechanism behind noble-gas solubility in water and the formation of **clathrate hydrates** ($\mathrm{Ar\cdot6H_2O}$, $\mathrm{Kr\cdot6H_2O}$, $\mathrm{Xe\cdot6H_2O}$) — larger, more polarizable noble gas atoms are more strongly induced and more soluble, giving the solubility order $\mathrm{He < Ne < Ar < Kr < Xe}$ (source-verified, `cbvj.pdf` pp.8–9). Helium and neon, being too small and weakly polarizable, do not form stable clathrate cages.

**(c) Instantaneous dipole–induced dipole interaction (London dispersion forces).** Even a genuinely non-polar molecule or atom has, at any instant, a fluctuating, momentarily asymmetric electron distribution (electrons are in constant motion, not frozen in a perfectly symmetric average position) — this instantaneous dipole induces a corresponding dipole in a neighbouring atom/molecule, and the resulting attraction, averaged over time, is non-zero. This is the **only** attractive force available between genuinely non-polar species (e.g., $\mathrm{H_2}$, $\mathrm{He}$, $\mathrm{N_2}$), and it is present in *every* system, polar or non-polar, solid, liquid, or gas.

![Figure 11.7: London dispersion](figures/intermolecular/fig_imf_london_dispersion.svg)
![Figure 11.8: Dipole-dipole interaction](figures/intermolecular/fig_imf_dipole_dipole.svg)
![Figure 11.9: Dipole-induced dipole interaction](figures/intermolecular/fig_imf_dipole_induced_dipole.svg)
![Figure 11.10: Ion-dipole interaction, hydration](figures/intermolecular/fig_imf_ion_dipole.svg)
![Figure 11.11: Full interaction comparison panel](figures/intermolecular/fig_imf_comparison_master.svg)

**Figures 11.7–11.11.** The complete interaction family in one consistent visual language: solid bonds = covalent, green dashed = the intermolecular/ion-molecule attraction itself, δ+/δ− = partial (not full ionic) charge. Figure 11.10 makes explicit what §3.6's hydration enthalpy discussion described only in words: water's O (δ−) end orients toward cations, its H (δ+) end toward anions. Figure 11.11's comparison table carries its own explicit qualification — the ordering shown is a general guide only, not a rigid universal ranking.

London forces increase with:
- **Number of polarizable electrons / molecular weight** — more electrons give a larger, more easily distorted electron cloud, hence a larger instantaneous dipole.
- **Molecular surface area available for contact** — more contact area allows more simultaneous induced-dipole interactions.

**Worked example 11.1 — Why boiling point increases down the halogen and noble-gas groups**

*Problem:* $\mathrm{F_2}$ is a gas, $\mathrm{Cl_2}$ is a gas, $\mathrm{Br_2}$ is a liquid, and $\mathrm{I_2}$ is a solid at room temperature (all non-polar, homonuclear diatomics). Explain, and contrast with the case where molecular weight is held roughly constant but branching changes.

*Reasoning:* Down the halogen group, both the number of electrons and the molecular weight increase substantially (F₂ = 38 amu, I₂ = 254 amu), directly increasing the polarizability and hence the London dispersion attraction between molecules — stronger intermolecular attraction requires more thermal energy to overcome, raising both melting and boiling points, eventually crossing from gas to liquid to solid at room temperature across the series.

*Conclusion:* $\mathrm{I_2 > Br_2 > Cl_2 > F_2}$ in melting/boiling point, purely a London-dispersion-driven trend (none of these molecules has a permanent dipole moment, so Keesom and Debye forces play no role) — the standard, frequently-tested illustration that **for non-polar species, London dispersion alone controls the trend**, and molecular weight/electron count is the correct variable to track.

*Common mistake:* invoking "van der Waals forces" generically without specifying *which* of the three types is actually operative — for these specifically non-polar molecules, only London dispersion applies, and citing dipole–dipole (Keesom) forces here would be incorrect, since $\mathrm{I_2}$ has no permanent dipole moment.

**Worked example 11.2 — Branching decreases boiling point at fixed molecular weight**

*Problem:* $n$-pentane boils higher than iso-pentane, which boils higher than neo-pentane, despite all three being $\mathrm{C_5H_{12}}$ (identical molecular weight and electron count).

*Reasoning:* Since molecular weight is fixed, the controlling variable shifts to **molecular surface area** (§11.2's second London-force factor): the linear, unbranched $n$-pentane has the largest surface area available for intermolecular contact, while the compact, highly-branched, nearly spherical neo-pentane has the smallest.

*Conclusion:* $n\text{-pentane} > \text{iso-pentane} > \text{neo-pentane}$ in boiling point — a clean illustration that London dispersion depends on *two* separate variables (molecular weight/electron count, *and* surface area/shape), and a question holding one fixed is specifically testing the other.

### 11.3 Hydrogen Bonding

**Conditions for hydrogen bonding:** a hydrogen atom must be covalently bonded to a small, highly electronegative atom (N, O, or F — the standard donor set) *and* there must be a nearby atom (also typically N, O, or F, occasionally Cl in specific contexts) bearing a lone pair to accept the interaction. The H–X bond is highly polarized ($\delta^+$ on H, since X is far more electronegative), and this small, exposed, positively-polarized H nucleus is strongly attracted to a neighbouring lone pair.

$$\mathrm{X{-}H \cdots {:}Y} \qquad (X, Y = \mathrm{N, O, F\ typically})$$

> **Why? (why H specifically, and not other small, electropositive-relative-to-X atoms)**
> Hydrogen is unique in having **no inner shielding shell at all** — when its single electron is pulled away toward X, the resulting exposed nucleus is a bare proton with no inner electron cloud left to soften the resulting positive charge concentration, unlike any other element's partially-positive end (which always retains at least one inner filled shell shielding the nucleus). This exceptionally concentrated, unshielded positive charge is what allows H to approach a neighbouring lone pair closely enough to form an interaction (10–40 kJ mol⁻¹, §1.4's table) substantially stronger than an ordinary dipole–dipole interaction, while still remaining far weaker than a genuine covalent bond (150–950 kJ mol⁻¹) — hydrogen bonding is a special, H-specific case of dipole–dipole interaction, not a fundamentally different force (`cbvj.pdf` p.4 explicitly frames it this way: "H-bonding is a special type of dipole-dipole interaction").

**Intermolecular vs. intramolecular hydrogen bonding.** An **intermolecular** hydrogen bond forms *between* separate molecules (e.g., between two HF molecules, or between water molecules, Figure 11.2) and tends to *raise* melting/boiling point (extra energy needed to separate the associated molecules) and *increase* viscosity (associated molecules resist flowing past each other). An **intramolecular** hydrogen bond forms *within* a single molecule (e.g., in $o$-nitrophenol, between the phenolic O–H and an adjacent nitro group oxygen) and, because it satisfies the H-bonding capacity internally rather than linking separate molecules together, generally *lowers* melting/boiling point relative to the corresponding molecule capable only of intermolecular H-bonding (e.g., $p$-nitrophenol, which cannot form the same intramolecular interaction due to geometry, and instead engages in extensive intermolecular H-bonding).

> **Important Conceptual Distinction — intermolecular vs. intramolecular hydrogen bonding** produces *opposite* effects on melting/boiling point precisely because one *links separate molecules together* (raising the energy needed to separate them) while the other *ties up the H-bonding capacity within one molecule* (removing that capacity from intermolecular association) — this is the standard $o$/$p$-nitrophenol worked comparison, and the reasoning generalizes to any ortho/para-disubstituted pair where one isomer's geometry permits intramolecular bonding and the other's does not.

![Figure 11.6: Intramolecular vs intermolecular hydrogen bonding, o- vs p-nitrophenol](figures/intermolecular/fig_hbond_intra_vs_inter.svg)

**Figure 11.6.** Side-by-side structural comparison: the ortho isomer's geometry permits a favourable ring closure (intramolecular, consuming the H-bonding capacity internally), while the para isomer's geometry cannot form that same ring, leaving its donor group free for intermolecular association — directly producing the opposite boiling-point/solubility consequences stated in the box above. This comparison is valid specifically within this closely related isomer pair, not as a universal rule independent of molecular mass or other competing interactions.

### 11.4 Association and the Anomalous Properties of Water, HF, Ammonia, and Related Compounds

![Figure 11.2: Water hydrogen-bond network](figures/intermolecular/fig_hbond_water_network.svg)

**Water's extensive H-bonding network** (Figure 11.2) — each molecule can simultaneously donate two H-bonds (through its two H atoms) and accept two (through its two O lone pairs) — gives water anomalously high melting/boiling points, high viscosity, high surface tension, and a uniquely open, low-density crystalline solid structure (ice), in which every water molecule is tetrahedrally hydrogen-bonded to four neighbours, leaving substantial open space and making ice *less* dense than liquid water — a well-known anomaly directly traceable to this specific 4-fold H-bonding geometry.

**Worked example 11.3 — Why HF, not HCl/HBr/HI, has the anomalously highest boiling point in its series** (verified pattern, `cbvj.pdf` p.13: "$\mathrm{H_2O > H_2Te > H_2Se > H_2S}$")

![Figure 11.3: HF chain association](figures/intermolecular/fig_hbond_hf_chain.svg)

**Figure 11.3.** Repeated H–F···H–F association gives HF a zig-zag chain structure in the condensed phase — the structural basis of the anomaly worked through immediately below.

*Problem:* Within Group 17 hydrides, boiling point normally rises down the group (§11.2's London-dispersion argument: heavier, more polarizable atoms), giving the expected order $\mathrm{HCl < HBr < HI}$. Yet **HF** breaks this pattern, boiling *higher* than HCl despite being the *lightest* member. Explain — and note the closely analogous pattern for Group 16 hydrides, where $\mathrm{H_2O}$ boils anomalously higher than $\mathrm{H_2S}$, even though $\mathrm{H_2Te > H_2Se > H_2S}$ follows the expected London-dispersion order among the heavier members.

*Reasoning:* HF (and $\mathrm{H_2O}$, and $\mathrm{NH_3}$) are the specific hydrides of the *most* electronegative, smallest atoms capable of the strongest possible hydrogen bonding (§11.3's conditions are most strongly satisfied precisely for N, O, F). This additional, substantial H-bonding contribution (10–40 kJ mol⁻¹ per interaction, extensively networked as in Figure 11.2) outweighs the otherwise-expected London-dispersion-driven trend for the lightest member of each hydride series, producing the characteristic "anomalous spike" at the top of each group when boiling point is plotted against period for Group 15, 16, and 17 hydrides.

*Conclusion:* the general London-dispersion trend (heavier = higher boiling point) applies *within* the non-hydrogen-bonded members of a series (HCl < HBr < HI; H₂S < H₂Se < H₂Te), but is overridden specifically at the top of Groups 15–17 by hydrogen bonding, which is itself strongest for the smallest, most electronegative donor/acceptor atoms (N, O, F) — a case where two competing trends (dispersion, increasing down the group; H-bonding, strongest only at the very top) must both be tracked, with H-bonding dominating only for the single lightest member.

*Common mistake:* stating "HF has the highest boiling point because fluorine is most electronegative" without connecting this to the *mechanism* (strongest H-bonding, §11.3's shielding-based explanation) — electronegativity alone, without the H-bonding-specific reasoning, does not actually explain *why* this produces an anomalously high boiling point rather than simply a strongly polar-covalent molecule with an otherwise unremarkable dispersion-driven boiling point.

**Two further worked structural examples of intermolecular hydrogen bonding, beyond the water/HF cases above:**

![Figure 11.4: Ethanol intermolecular hydrogen bonding](figures/intermolecular/fig_hbond_alcohol_association.svg)

**Figure 11.4.** Only the polar –OH group participates directly in hydrogen bonding; the nonpolar alkyl chain does not. This is why ethanol (b.p. 78°C) boils far higher than dimethyl ether (b.p. −24°C) despite both having the formula $\mathrm{C_2H_6O}$ — the ether has no O–H donor group at all, so it cannot hydrogen-bond to itself the way an alcohol can (it can still *accept* a hydrogen bond from a donor like water, but cannot donate one).

![Figure 11.5: Carboxylic acid cyclic dimer](figures/intermolecular/fig_hbond_carboxylic_acid_dimer.svg)

**Figure 11.5.** Two simultaneous O–H···O=C hydrogen bonds close an eight-membered ring — this cyclic dimer is the direct structural explanation for carboxylic acids' anomalously high boiling points and their tendency to show close to double their true molar mass when measured by colligative methods in non-polar solvents (the "dimer" behaves as a single kinetic unit).

### 11.5 Ion–Dipole and Ion-Induced Dipole Interactions

**Ion–dipole interaction** is the attraction between a full ion and the partial charge of a polar molecule — the mechanism directly underlying the hydration/solvation processes already treated quantitatively in §3.6 (ion–dipole interaction is, precisely, what "hydration enthalpy" measures at the molecular level) and depicted with the polar solvent orienting its negative end toward cations and positive end toward anions.

**Ion-induced dipole interaction** is the attraction between a full ion and a dipole it induces in an otherwise non-polar neighbour — the mechanism behind polyhalide ion formation (e.g., $\mathrm{I_3^-}$, $\mathrm{ICl_2^-}$, already encountered structurally in §9.4): an iodide ion (I⁻) induces a dipole in a neutral $\mathrm{I_2}$ molecule, allowing them to associate. Stability of polyhalide ions follows the anion's polarizability directly ($\mathrm{F_3^- < Cl_3^- < Br_3^- < I_3^-}$), since a more polarizable neighbour is more strongly induced and hence more strongly bound.

**Table 11.1 — Relative strength and distance-dependence of intermolecular/ion-molecule interactions** (verified against `CHEMICAL_BONDING.pdf` §3.30–3.31)

| Interaction type | Energy–distance dependence |
|---|---|
| Ion–dipole | $1/r^2$ |
| Dipole–dipole | $1/r^3$ |
| Ion–induced dipole | $1/r^4$ |
| Dipole–induced dipole | $1/r^6$ |
| London dispersion | $1/r^6$ |

All these interactions fall off far more steeply with distance than the ordinary ionic-lattice Coulombic attraction ($1/r$, §3.4) — a direct, quantitative confirmation of why van der Waals-type interactions are inherently short-range, only significant when molecules are already close together (as in condensed phases), unlike lattice-scale electrostatics, which (via the Madelung-constant summation of §3.4) meaningfully extends over the whole crystal.

### Part 11 Summary

- Intermolecular forces (collectively van der Waals: dipole–dipole/Keesom, dipole-induced dipole/Debye, and London dispersion) act between complete molecules and are always weaker than the covalent/ionic bonds within a molecule, but they control bulk physical properties.
- London dispersion, present in *every* system, depends on polarizability (electron count/molecular weight) and surface area — both variables are independently testable (Worked Examples 11.1, 11.2).
- Hydrogen bonding is mechanistically a special, unusually strong case of dipole–dipole interaction, unique to H because it has no inner shielding shell; intermolecular H-bonding raises melting/boiling point (linking separate molecules), while intramolecular H-bonding lowers it (satisfying bonding capacity internally) — the standing $o$/$p$-nitrophenol illustration.
- The anomalously high boiling points of HF, H₂O, and NH₃ within their respective hydride series reflect H-bonding dominating over the otherwise-expected London-dispersion trend specifically at the top of Groups 15–17 (Worked Example 11.3), not electronegativity alone.
- Ion–dipole and ion-induced dipole interactions extend the same framework to ion–molecule systems, directly underlying hydration enthalpy (Part 3) and polyhalide-ion stability, and all intermolecular/ion–molecule interactions fall off far more steeply with distance than lattice-scale Coulombic attraction.

---

## Source Traceability — Part 11

| Source PDF | Pages | Material found | Destination | Status |
|---|---|---|---|---|
| `cbvj.pdf` | pp.1–15 (originally logged as PENDING in the Part 1–2 matrix; now drafted here as planned) | Full dipole–dipole (Keesom)/dipole-induced dipole (Debye)/London dispersion definitions, clathrate hydrate formation and noble-gas solubility order, H-bonding mechanism ("special type of dipole-dipole interaction"), Group 15/16/17 hydride boiling-point anomaly data, branched-alkane boiling-point comparisons, halogen boiling/melting point trend | §11.2–11.4 | INCORPORATED (resolves the PENDING flag from the Part 1–2 matrix) |
| `CHEMICAL_BONDING.pdf` | §3.30–3.31 (Weak Forces; Interactions between Ions and Covalent Molecules, full text) | Energy–distance relationships for all five interaction types (Table 11.1), ion–dipole/ion-induced dipole mechanism, polyhalide ion stability order, Lennard-Jones potential context | §11.5, Table 11.1 | INCORPORATED |
| Independently derived | — | Worked Examples 11.1–11.3 organized and cross-checked against standard physical-property data | §11.2, 11.4 | INCORPORATED, independently verified |

---

*Part 11 complete. Continuing to Part 12 (Metallic Bonding).*
