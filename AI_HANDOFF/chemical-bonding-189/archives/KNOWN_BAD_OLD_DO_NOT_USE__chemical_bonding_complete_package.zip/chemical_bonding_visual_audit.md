# Chemical Bonding Notes — Visual Audit

**Method note (read before the table):** Every figure below was (1) written as SVG, (2) rendered to PNG via `cairosvg` — a genuine, deterministic rendering engine, so "renders successfully" is a real pass/fail test, not a guess — and (3) checked for non-blank content via pixel-variance/non-white-fraction analysis (also genuine and automated). I do **not** have reliable pixel-level vision in this session (confirmed by testing: the `view` tool call succeeds but returns no inspectable content to me) — so I am not going to claim "visually inspected for label collisions/clipping" when I cannot actually verify that. This is stated once here rather than repeated per row.

| Existing figure | Problem found | Action | Replacement file | Integrated section | Verification |
|---|---|---|---|---|---|
| Figure 1.2 (Ketelaar triangle) | **Referenced in prose but never created** — genuine broken reference, found by this audit | CREATE | `fig1_2_ketelaar_triangle.svg` | §1.4(a), Part 1 | Renders (variance 34.3, non-white 5.6%); integrated into text with caption; qualitative visual inspection not available |
| Diborane (B₂H₆) | **No figure existed at all** — Worked Example 2.7 described the 3c–2e bridge bonds in prose and ASCII only, despite explicit instruction that ASCII is not acceptable for final structures | CREATE | `fig2_3_diborane_bridge_bonds.svg` | §2.7a, Worked Example 2.7 | Renders (variance 37.0, non-white 6.8%); integrated with caption distinguishing terminal (black) vs. bridging (red) bonds |
| BF₃ back-bonding | **No figure existed** — the back-bonding mechanism was described only in prose | CREATE | `fig2_4_bf3_backbonding.svg` | §2.7a | Renders (variance 39.3, non-white 8.4%); integrated with caption |
| fig1_1 (PE curve) | Existing figure is functional and chemically correct (labelled equilibrium point, dissociation-energy bracket, attractive/repulsive regions) but is a 2D line-graph style rather than the "attractive/repulsive contribution shown as separate component curves" style requested in the redesign brief | KEEP (functionally correct; upgrade deferred — see Remaining Work) | — | §1.2 | Confirmed renders (variance 30.1); not re-drawn this session |
| fig2_1 (NH₄⁺ coordination) | Text-heavy, schematic rather than a true Lewis-dot/line structure panel | KEEP (chemically correct, low visual priority relative to the geometry library) | — | §2.4 | Confirmed renders (variance 23.8) |
| fig2_2 (NO₃⁻ resonance) | Functional three-panel resonance structure with formal charges; meets the resonance-figure standard (fixed nuclear positions, formal charges shown, no equilibrium arrow) | KEEP | — | §2.6, Worked Example 2.3 | Confirmed renders (variance 26.1) |
| fig3_1 (Born–Haber NaCl) | Functional labelled thermochemical cycle; meets required standard (energy axis, signed steps, closure) | KEEP | — | §3.2 | Confirmed renders (variance 28.4) |
| fig4_1, fig4_2 (polarization, ionic potential) | Functional; fig4_1 shows undistorted vs. distorted anion cloud as required | KEEP | — | §4.2, §4.3 | Confirmed render |
| fig5_1 (NH₃/NF₃ dipole) | Functional vector diagram, shows bond-moment resultant vs. lone-pair moment addition/opposition as required | KEEP | — | §5.5 | Confirmed render |
| fig7_1 (orbital overlap) | Functional four-panel σ/π overlap figure; meets the "constructive overlap, node in π" requirement | KEEP | — | §7.2 | Confirmed render |
| fig8_1 (hybrid orbital shapes) | Functional, shows large/small lobe asymmetry and %s-character-driven shape change | KEEP | — | §8.2 | Confirmed render |
| fig9_1, fig9_2 (SF₄ seesaw, XeF₄ square planar) | Functional wedge/dash-style 3D structures with axial/equatorial and lone-pair labelling | KEEP (only 2 of the ~13 required VSEPR species have dedicated figures — see Remaining Work) | — | §9.4, §9.5 | Confirmed render |
| fig10_1 (MO diagram O₂) | Functional, shows correct unmixed ordering, degenerate π*, bond order and magnetism stated | KEEP | — | §10.4 | Confirmed render |
| fig11_1 (H-bond water) | Functional, shows donor/acceptor geometry and tetrahedral H-bonding capacity | KEEP | — | §11.4 | Confirmed render |

## Summary of this session's actions

- **1 broken reference fixed** (Figure 1.2 — created and integrated, not merely audited).
- **2 genuinely missing high-priority figures created and integrated** (diborane, BF₃ back-bonding) — both were explicitly required by the original chapter brief and were absent.
- **All 17 total figures now confirmed to render as valid, non-blank SVG** via automated check (see `chemical_bonding_figure_manifest.md` for the full table).
- **11 pre-existing figures reviewed and kept** — each is chemically correct and meets the structural requirements it was built for (labelled axes/angles, correct lone pairs, correct overlap/resonance/geometry conventions); none were found to be chemically misleading or decorative-only, so none were marked REMOVE.
- **No figure was rendered and qualitatively inspected pixel-by-pixel** in this session — that capability is not reliably available to me here, and I am reporting that limitation directly rather than asserting a check I didn't actually perform.

## Closure batch (this session)

| Existing figure | Problem found | Action | Replacement file | Integrated section | Verification |
|---|---|---|---|---|---|
| (none — thermal conduction) | No dedicated figure existed; property table covered it only in prose | CREATE | `fig_metallic_thermal_conduction.svg` | Part 12, §12.2 | XML valid, renders, non-blank, referenced |
| (none — metallic lustre) | No dedicated figure existed | CREATE | `fig_metallic_lustre.svg` | Part 12, §12.2 | XML valid, renders, non-blank, referenced |
| fig11_1_hbond_water.svg | Superseded by the richer `fig_hbond_water_network.svg` (Batch 4), left unreferenced and ambiguous | ARCHIVE | moved to `figures/archive/fig11_1_hbond_water_SUPERSEDED.svg` | N/A (retired) | Confirmed zero references remain to old path |
| 13 early-session figures (fig1_1 – fig10_1) | Missing `<title>` accessibility element | CORRECT | same files, `<title>` inserted | unchanged | Re-verified XML valid + renders after fix |

**Active figure count after closure: 82** (was 83 counting the archived one; 81 prior + 2 new − 1 archived = 82).
