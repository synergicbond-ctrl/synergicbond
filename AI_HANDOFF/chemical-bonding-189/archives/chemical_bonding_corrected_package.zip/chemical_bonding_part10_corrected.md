## Part 10 — Molecular Orbital Theory

### 10.1 The LCAO Method

Molecular orbital theory (MOT) treats electrons as belonging to the **whole molecule**, not to individual atoms or localized bonds — a fundamentally different starting assumption from VBT's localized-overlap picture (Part 7). A molecular orbital wave function is constructed as a **linear combination of atomic orbitals (LCAO)**:

$$\psi_{\text{MO}} = c_1\psi_A + c_2\psi_B$$

For two atomic orbitals combining, exactly **two** molecular orbitals must result (conservation of the total number of orbitals, the same "in equals out" bookkeeping already used for hybridisation, §8.2):

$$\psi_{\text{bonding}} = N(\psi_A + \psi_B) \qquad \psi_{\text{antibonding}} = N'(\psi_A - \psi_B)$$

**Conditions for effective LCAO combination** (the MOT-level restatement of the constructive-overlap conditions already established in §7.1):
1. The combining atomic orbitals must be of **comparable energy**.
2. They must **overlap** effectively (sufficient spatial proximity and orientation).
3. They must have **matching symmetry** about the internuclear axis.

### 10.2 Bonding, Antibonding Orbitals, and Nodes

The **bonding** combination ($\psi_A + \psi_B$, same-sign addition) produces constructive interference, concentrating electron density between the nuclei — this is lower in energy than the separate atomic orbitals by a stabilization amount $\Delta$. The **antibonding** combination ($\psi_A - \psi_B$, opposite-sign combination) produces destructive interference, creating a **node** (a plane of exactly zero electron density) between the nuclei — this is higher in energy than the separate atomic orbitals by the same amount $\Delta$, since removing electron density from the internuclear region reduces the attraction holding the nuclei together.

Filling a bonding orbital **stabilizes** the molecule; filling an antibonding orbital (marked with an asterisk, e.g., $\sigma^*$, $\pi^*$) **destabilizes** it. Since both bonding and antibonding orbitals arise from the same starting pair of atomic orbitals, filling *both completely* (as in a hypothetical $\mathrm{He_2}$, §10.4) cancels the stabilization exactly, predicting **no net bond** — this is the direct MOT explanation for why $\mathrm{He_2}$ does not exist, succeeding exactly where the simple octet/Lewis picture gives no explanation at all (helium already has a complete valence shell in the Lewis picture, and Lewis theory has nothing further to say about why two complete-shell atoms fail to bond).

### 10.3 σ and π Molecular Orbitals

Exactly as in VBT (§7.2), MOs are classified by their symmetry about the internuclear axis: **σ** MOs (from head-on $s$–$s$, $s$–$p$, or $p$–$p$ combination) are cylindrically symmetric about the axis; **π** MOs (from lateral $p$–$p$ combination) have a nodal plane containing the internuclear axis. The bonding/antibonding distinction applies independently to each: $\sigma, \sigma^*, \pi, \pi^*$ are four distinct orbital types, each with its own energy level.

### 10.4 Homonuclear Diatomic Molecules — Building Up the Series

Following the Aufbau principle and Hund's rule (exactly as for atomic electron configurations), electrons fill the available MOs from lowest to highest energy. The **standard filling order** for light diatomics (Li₂ through N₂) places the $\pi 2p$ orbitals *below* $\sigma 2p_x$:

$$\sigma1s < \sigma^*1s < \sigma2s < \sigma^*2s < \pi2p_y{=}\pi2p_z < \sigma2p_x < \pi^*2p_y{=}\pi^*2p_z < \sigma^*2p_x$$

while for O₂ and F₂ (and, by extension, Ne₂), the order **reverses** for the $2p$-derived orbitals, placing $\sigma2p_x$ *below* $\pi2p_y{=}\pi2p_z$:

$$\sigma1s < \sigma^*1s < \sigma2s < \sigma^*2s < \sigma2p_x < \pi2p_y{=}\pi2p_z < \pi^*2p_y{=}\pi^*2p_z < \sigma^*2p_x$$

> **Why? (s–p mixing, the actual mechanism behind the order change — not just a memorized rule)**
> The $2s$ and $2p_x$ orbitals both have the correct symmetry to interact with each other directly (both are symmetric about the internuclear axis), and when the energy gap between the $2s$ and $2p$ atomic orbitals is **small enough**, this cross-interaction ("s–p mixing") pushes $\sigma2s$ and $\sigma2p_x$ further apart than they would be without mixing — lowering $\sigma2s$ (and $\sigma^*2s$) further and raising $\sigma2p_x$ (and $\sigma^*2p_x$) further, specifically because two orbitals of the same symmetry repel each other in energy (a general quantum-mechanical non-crossing-rule effect). This raises $\sigma2p_x$ high enough to sit *above* the (unaffected, different-symmetry) $\pi2p$ orbitals for Li through N. Across the period, the $2s$–$2p$ energy gap widens sharply (`CHEMICAL_BONDING.pdf` §3.11 gives the verified values: $\Delta E(2s-2p)$ in eV — Li 1.8, Be 2.8, B 4.5, C 5.3, N 6.0, **O 15.0**, F 20.5, Ne 26.7), and once the gap becomes large enough (O onward), s–p mixing becomes negligible, $\sigma2p_x$ drops back below $\pi2p$, and the "normal," unmixed ordering is restored.

**Table 10.1 — Complete homonuclear diatomic series, verified electron configurations, bond order, and magnetism**

| Species | Total e⁻ | Configuration (beyond core, mixed order where applicable) | Bond order | Magnetic character |
|---|---:|---|---:|---|
| $\mathrm{H_2^+}$ | 1 | $\sigma1s^1$ | 0.5 | Paramagnetic |
| $\mathrm{H_2}$ | 2 | $\sigma1s^2$ | 1 | Diamagnetic |
| $\mathrm{H_2^-}$ | 3 | $\sigma1s^2\sigma^*1s^1$ | 0.5 | Paramagnetic |
| $\mathrm{He_2^+}$ | 3 | $\sigma1s^2\sigma^*1s^1$ | 0.5 | Paramagnetic (exists, detected spectroscopically) |
| $\mathrm{He_2}$ | 4 | $\sigma1s^2\sigma^*1s^2$ | 0 | Does not exist (§10.2) |
| $\mathrm{Li_2}$ | 6 | KK, $\sigma2s^2$ | 1 | Diamagnetic |
| $\mathrm{Be_2}$ | 8 | KK, $\sigma2s^2\sigma^*2s^2$ | 0 | Does not exist as a stable diatomic |
| $\mathrm{B_2}$ | 10 | KK, $\sigma2s^2\sigma^*2s^2\pi2p_y^1\pi2p_z^1$ | 1 | **Paramagnetic** (Hund's rule fills the degenerate π orbitals singly first — correctly predicted only with the mixed s–p order) |
| $\mathrm{C_2}$ | 12 | KK, $\sigma2s^2\sigma^*2s^2\pi2p_y^2\pi2p_z^2$ | 2 | Diamagnetic |
| $\mathrm{N_2}$ | 14 | KK, $\sigma2s^2\sigma^*2s^2\pi2p_y^2\pi2p_z^2\sigma2p_x^2$ | 3 | Diamagnetic |
| $\mathrm{O_2}$ | 16 | KK, $\sigma2s^2\sigma^*2s^2\sigma2p_x^2\pi2p_y^2\pi2p_z^2\pi^*2p_y^1\pi^*2p_z^1$ | 2 | **Paramagnetic** |
| $\mathrm{O_2^+}$ | 15 | as O₂, remove one $\pi^*$ electron | 2.5 | Paramagnetic |
| $\mathrm{O_2^-}$ | 17 | as O₂, add one more $\pi^*$ electron | 1.5 | Paramagnetic |
| $\mathrm{O_2^{2-}}$ | 18 | as O₂, both $\pi^*$ orbitals filled | 1 | Diamagnetic |
| $\mathrm{F_2}$ | 18 | KK, $\sigma2s^2\sigma^*2s^2\sigma2p_x^2\pi2p_y^2\pi2p_z^2\pi^*2p_y^2\pi^*2p_z^2$ | 1 | Diamagnetic |
| $\mathrm{N_2^+}$ | 13 | as N₂, remove one $\sigma2p_x$ electron | 2.5 | Paramagnetic |
| $\mathrm{N_2^-}$ | 15 | as N₂, add one $\pi^*$ electron | 2.5 | Paramagnetic |

![Figure 10.2: B2 MO diagram](figures/mot/fig_mo_b2.svg)
![Figure 10.3: C2 MO diagram](figures/mot/fig_mo_c2.svg)
![Figure 10.4: N2 MO diagram](figures/mot/fig_mo_n2.svg)

**Figures 10.2–10.4.** The B₂–N₂ mixed-ordering template (π2p below σ2pz), with electron filling shown explicitly for each species. B₂'s two electrons split singly across the degenerate π2p pair (Hund's rule) — this is Worked Example 10.1's diagnostic case, visible directly here rather than only in the table.

![Figure 10.5: O2 MO diagram](figures/mot/fig_mo_o2_full.svg)
![Figure 10.6: F2 MO diagram](figures/mot/fig_mo_f2.svg)

**Figures 10.5–10.6.** The O₂–F₂ unmixed-ordering template (σ2pz below π2p) — note this is a *different* orbital ordering from Figures 10.2–10.4, not the same template relabelled. O₂'s two π*2p electrons occupy the degenerate pair singly (Hund's rule), directly producing the paramagnetism that neither the Lewis structure (§1.7) nor VBT (§7.4) can predict.

![Figure 10.7: Oxygen ion series comparison](figures/mot/fig_mo_oxygen_ion_series.svg)

**Figure 10.7.** The single most useful comparison panel in this Part: only the π* occupancy changes across the four-species series, and that one number alone determines bond order, relative bond length, relative bond strength, and magnetic character simultaneously — visible directly by counting arrows across the four panels rather than by re-deriving each species from scratch.

Bond order is calculated throughout as:

$$\text{Bond order} = \dfrac{N_b - N_a}{2}$$

where $N_b$ is the number of electrons in bonding orbitals and $N_a$ the number in antibonding orbitals — a direct, quantitative generalization of the qualitative "count the shared pairs" bond-order idea already used in §5.1 and §6.3, now made rigorous by explicitly weighing bonding contributions against antibonding ones rather than simply counting shared electrons.

![Figure 10.1: MO diagram of O2](figures/fig10_1_mo_o2.svg)

**Figure 10.1.** O₂ uses the *unmixed* ordering ($\sigma2p_x$ below $\pi2p$, since O's $2s$–$2p$ gap of 15.0 eV is too large for significant s–p mixing). Two electrons occupy the degenerate $\pi^*2p_y, \pi^*2p_z$ orbitals singly (Hund's rule) — this pair of unpaired electrons is the direct MOT explanation for paramagnetism that neither the simple Lewis structure (§1.7, §2.10) nor simple VBT (§7.4) can provide.

**Worked example 10.1 — Explaining the B₂ paramagnetism prediction, and why it requires the mixed ordering**

*Problem:* $\mathrm{B_2}$ is experimentally paramagnetic. Show that this is correctly predicted only by the *mixed* (s–p-mixed) MO ordering, not by the unmixed ordering.

*Reasoning:* B₂ has 6 valence electrons (beyond the $K$-shell core) to place in the $2s$/$2p$-derived MOs. Under the **mixed** ordering ($\pi2p$ below $\sigma2p_x$): after filling $\sigma2s^2\sigma^*2s^2$ (4 electrons), the remaining 2 electrons enter the degenerate $\pi2p_y, \pi2p_z$ pair — by Hund's rule, one electron in each, **unpaired**, correctly predicting paramagnetism. Under the (incorrect, for B₂) **unmixed** ordering ($\sigma2p_x$ below $\pi2p$): the remaining 2 electrons would instead fill $\sigma2p_x^2$ completely — **paired**, incorrectly predicting diamagnetism.

*Conclusion:* the experimentally observed paramagnetism of $\mathrm{B_2}$ is direct, decisive evidence for the s–p-mixed orbital ordering in light diatomics (Li₂–N₂) — this is a genuinely diagnostic worked example, not merely an illustrative one, since the two ordering models make different, experimentally distinguishable predictions for this specific molecule.

*Common mistake:* applying the O₂/F₂-family (unmixed) ordering uniformly to *all* homonuclear diatomics, including B₂, C₂, and N₂ — a very common error, since only the heavier half of the second-period series (O, F) actually uses the unmixed order.

### 10.5 Ions and Excited States — Electron Removal and Addition

Removing an electron from a bonding orbital *decreases* bond order (weakens, lengthens the bond); removing an electron from an antibonding orbital *increases* bond order (strengthens, shortens the bond) — the opposite-direction consequence of the bonding/antibonding energy-sign distinction (§10.2) applied to ionization specifically.

**Worked example 10.2 — Bond-order and bond-length change on ionizing N₂ vs. O₂**

*Problem:* Removing one electron from N₂ to form N₂⁺ *increases* the N–N bond length (110 pm → 112 pm). Removing one electron from O₂ to form O₂⁺ *decreases* the O–O bond length (121 pm → 112 pm). Explain the difference using MOT.

*Reasoning:* In N₂ (s–p-mixed ordering, §10.4; HOMO is $\sigma2p_x$, a **bonding** orbital), removing an electron from this bonding HOMO *lowers* bond order from 3 to 2.5 — bond order decreases, so bond length should increase and bond strength decrease on ionization. In O₂ (unmixed ordering, HOMO is $\pi^*2p$, an **antibonding** orbital), removing an electron from this antibonding HOMO *raises* bond order from 2 to 2.5 — bond order increases, so bond length should decrease and bond strength increase on ionization.

*Conclusion:* whether ionization strengthens or weakens a bond depends entirely on whether the electron removed came from a bonding or antibonding orbital — this is determined directly by which MO is the HOMO for that specific molecule, which in turn depends on the specific orbital-filling order (§10.4) for that molecule. This is a general, testable principle, not a pair of facts to memorize independently: **always identify the HOMO's bonding/antibonding character first**, and the bond-order (and hence bond-length) consequence of ionization follows immediately.

*Common mistake:* assuming ionization always weakens a bond (true for most main-group molecular cations formed by removing a bonding electron, but false whenever the HOMO is antibonding, as in O₂, F₂, and the superoxide/peroxide-type species of Table 10.1).

### 10.6 Heteronuclear Diatomics — NO and CO

**NO**: $5+6=11$ valence electrons (NO has 15 electrons *in total*, counting the two $1s^2$ cores — conflating the total count with the valence count is a genuine exam error worth guarding against; the valence configuration $\sigma2s^2\,\sigma^*2s^2\,\sigma2p^2\,\pi2p^4\,\pi^*2p^1$ uses exactly 11 electrons), filled using the same general ordering pattern as the homonuclear O₂/F₂-family (appropriate since N and O are adjacent, comparable-energy atoms), giving one unpaired electron in a $\pi^*$ orbital — **NO is paramagnetic**, and because this unpaired electron sits in a relatively high-energy, delocalized antibonding orbital (the HOMO), NO's first ionization energy (891 kJ mol⁻¹) is *lower* than either constituent atom's own ionization energy (N: 1402; O: 1314 kJ mol⁻¹) — removing an electron from an already-high-energy antibonding MO costs less than removing one from either atom's more tightly-bound orbitals. Ionizing NO to $\mathrm{NO^+}$ removes this antibonding electron, **raising** bond order from 2.5 to 3.0 and correspondingly **shortening** the bond (115 pm → 106 pm) — directly the same bonding-vs-antibonding-HOMO logic from Worked Example 10.2, now applied to a heteronuclear case.

**CO**: because C and O differ substantially in electronegativity (unlike the homonuclear cases), the simple symmetric LCAO combination is no longer strictly valid — the MOs are weighted more heavily toward the more electronegative O for bonding orbitals and more heavily toward C for the higher-energy orbitals, and the highest-occupied MO in CO is essentially a **non-bonding** orbital localized mostly on C. Ionizing CO (removing this largely non-bonding C-centred electron) causes only a small bond-length change (112.8 pm → 111.5 pm, a slight *decrease*, since even a "non-bonding" MO retains some bonding character in the real, non-idealized molecule) — consistent with CO's very high bond order (3, matching its Lewis-structure triple bond, §2.5's Worked Example 2.1) being only weakly perturbed by removing an electron from an orbital that is not strongly bonding or antibonding to begin with.

> **Important Conceptual Distinction — bonding, antibonding, and nonbonding orbitals.** A **nonbonding** MO (relevant specifically to heteronuclear cases like CO, and to lone pairs in polyatomic MO treatments beyond this Part's scope) is one that is essentially unchanged in energy from the parent atomic orbital — neither stabilized (bonding) nor destabilized (antibonding) by the LCAO combination, typically because the relevant atomic orbitals lack a symmetry-matched partner of comparable energy on the other atom to combine with constructively or destructively. This is distinct from a **lone pair** in the Lewis/VBT sense (§2.2) only in *framework* — both describe electron density essentially localized on one atom, but MOT's nonbonding-orbital language is the rigorous version of the same underlying physical idea.

### 10.7 Limitations of Elementary MO Diagrams

1. **The simple LCAO-based diagrams used here are qualitative**, giving correct orbital *ordering* and *bond-order* predictions for the second-period series and simple heteronuclear cases, but not exact, first-principles quantitative energies — a genuinely complete treatment requires solving the molecular Schrödinger equation numerically.
2. **They become substantially more complex for polyatomic molecules**, where MOs are delocalized over three or more atoms simultaneously (directly connecting back to the resonance/delocalization language of Part 6 — MOT provides the rigorous underlying picture that resonance theory approximates using multiple localized Lewis structures).
3. **The s–p mixing crossover point (§10.4) is itself an approximation** — the *exact* energy gap at which mixing becomes negligible is a matter of degree, not a sharp switch, and the O₂/F₂-vs-Li₂–N₂ split, while an extremely reliable rule at this level, is a simplified summary of a continuous underlying trend (the $\Delta E(2s\text{-}2p)$ values of §10.4 rise smoothly, not in a single step, across the period).

### Part 10 Summary

- MOT builds molecular orbitals as linear combinations of atomic orbitals over the whole molecule (not localized bonds, contrasting directly with VBT, Part 7); bonding combinations stabilize, antibonding combinations destabilize, and filling both completely (He₂) predicts — correctly — no net bond.
- The light (Li₂–N₂) and heavy (O₂–F₂) halves of the second-period series use *different* orbital fillings orders because of s–p mixing, whose strength is set by the $2s$–$2p$ energy gap; this is not an arbitrary memorized split but a direct, verifiable consequence (Worked Example 10.1, B₂'s paramagnetism) of a specific physical mechanism.
- Bond order $=(N_b-N_a)/2$ correctly predicts O₂'s paramagnetism (the historic first success of MOT over simple Lewis/VBT pictures) and correctly predicts, case by case, whether ionization strengthens or weakens a given bond depending on whether the HOMO removed is bonding, antibonding, or (for heteronuclear cases like CO) essentially nonbonding.
- MOT and VBT are complementary, not competing: VBT/hybridisation is more directly useful for local geometry (Parts 8–9); MOT is essential wherever magnetism, bond order in ions, or genuinely delocalized bonding must be predicted correctly.

---

## Source Traceability — Part 10

| Source PDF | Pages | Material found | Destination | Status |
|---|---|---|---|---|
| `CHEMICAL_BONDING.pdf` | §3.9–3.13 (Molecular Orbital Method, LCAO, homonuclear and heteronuclear worked treatment, full text) | LCAO derivation, bonding/antibonding energy-level diagrams, complete worked electron configurations H₂⁺ through F₂ and O₂⁻/O₂²⁻/N₂⁺/N₂⁻, ΔE(2s-2p) verified numerical table (Li 1.8 – Ne 26.7 eV), full NO and CO heteronuclear treatment with ionization-energy and bond-length data | §10.1–10.7, Table 10.1 | INCORPORATED |
| `cbvj.pdf`, `Chemical Bonding (E)/1–12.pdf` | existing OCR index re-queried (LCAO, molecular orbital, bond order, sigma star, pi star, paramagnetic, diamagnetic) | No new hits beyond what is already logged | — | IRRELEVANT TO PART 10 |
| Independently derived | — | Table 10.1 fully reconstructed and self-checked (bond order arithmetic verified for every entry); Worked Examples 10.1–10.2 constructed to specifically test the mixed-vs-unmixed ordering distinction | §10.4–10.5 | INCORPORATED, independently verified |

---

*Part 10 complete. Continuing to Part 11 (Hydrogen Bonding and Intermolecular Forces).*
