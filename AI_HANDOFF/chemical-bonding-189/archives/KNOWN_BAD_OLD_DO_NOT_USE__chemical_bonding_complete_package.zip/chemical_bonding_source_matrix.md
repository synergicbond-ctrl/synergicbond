# Chemical Bonding Notes — Source-to-Content Matrix (living document)

Method note, applies to every row below: `CHEMICAL_BONDING.pdf` and `Chemical_Bonding_Kohinoor_.pdf` are genuinely text-native (confirmed by direct extraction, not OCR) and were searched/read as real text. `cbvj.pdf` (177 pp.) and all twelve `Chemical Bonding (E)/1–12.pdf` files (245 pp.) are true image scans with no text layer; all 422 pages were rasterized and OCR'd once (this is the standing "screened" pass for every Part from here on — it is not repeated per-Part), and pages are individually opened and visually/OCR-cross-read whenever a Part's keyword sweep flags them. Kohinoor pages are read directly as extracted text, which is a reliable, non-probabilistic method (unlike OCR on handwriting).

| Part | Source PDF | Exact pages screened | Exact pages read closely | Material found | Destination section | Status |
|---|---|---:|---:|---|---|---|
| 1 | `CHEMICAL_BONDING.pdf` | §3.1–3.4 (full text) | §3.1–3.4 | Bond formation/energy, types of bonds, Ketelaar triangle, octet theory | §1.1–1.7 | INCORPORATED |
| 1 | `cbvj.pdf` | p.1 | p.1 | PE curve, bond formation point, exo/endothermic framing | §1.2 caption | INCORPORATED |
| 1 | `cbvj.pdf` | pp.2–15 | pp.2–15 | Dipole forces, London dispersion, H-bonding, clathrates | — | PENDING LATER PART (→ Part 11) |
| 1 | `Chemical Bonding (E)/1.pdf` | pp.1–11 | pp.1–4 | Attraction/repulsion, covalent 2c–2e sharing | §1.1, §2.2 (confirmatory) | DUPLICATE — already covered |
| 2 | `CHEMICAL_BONDING.pdf` | §3.3–3.4 | §3.3–3.4 | NaCl/CaCl₂ ionic formation, coordinate bonds, octet exceptions | §2.1–2.9 | INCORPORATED |
| 2 | `Chemical_Bonding_Kohinoor_.pdf` | pp.3,4,12,17,110,135,136 (of 261) | pp.3,4,12,17,110,135,136 | Octet/duplet, pseudo-noble-gas table, central-atom rule, BF₃ back-bonding, formal-charge rules 3–4 | §2.1, §2.6, §2.7a | INCORPORATED |
| 2 | `cbvj.pdf` | pp.16–177 (all) | pp.38,50,57–59,63,66,83,87,100,172 | Bridge bonding (BeCl₂/AlCl₃), odd-e⁻ paramagnetism, pseudo-noble-gas (corroborates Kohinoor p.4) | §2.7a, §2.7c, §2.1 | INCORPORATED (pp.38,50,57–59,63,66,100); PENDING/IRRELEVANT (pp.83→oxoacid part, p.87→Xe chem/Part 9, p.172→outside current scope) |
| 2 | `Chemical Bonding (E)/2–12.pdf` | all 234 pp. | pp. per prior matrix (2:p13; 3:p13; 12:p6,p27) | σ/π overlap types, expanded-octet terminology (confirmatory), VSEPR/steric-number method, odd-e⁻ (confirmatory) | §2.7b,c (confirmatory only) | INCORPORATED (confirmatory); IRRELEVANT (bulk — belongs to Parts 5,7,8,9) |
| 2 | `Topic Wise Questions/covalencyandlewisoctetstructure.pdf` | all 7 pp. | all 7 pp. | NF₅ non-existence, IF₇ boundary, octet exceptions | Worked Examples 2.4, 2.5 (rewritten) | INCORPORATED |
| 2 | `Topic Wise Questions/basicchemicalbondinglevel0.pdf` | all 65 pp. | qq.1–24 | Ionic bond formation conditions (confirmatory) | §2.1 | INCORPORATED (confirmatory) |
| 3 | `CHEMICAL_BONDING.pdf` | §3.15, 3.20, 3.23, 3.25–3.29 | same | Born–Haber, Born–Landé, lattice energy factors, solubility, thermal stability | §3.1–3.8 | INCORPORATED |
| 3 | `Chemical_Bonding_Kohinoor_.pdf` | pp.8,9,11,13,16 (keyword-flagged of 261) | pp.8,9,11,13,16 | Redox framing of ionic bond formation, Born–Landé (cross-check), dielectric-constant solvent table, isomorphism conditions | §3.1, §3.4, §3.6, §3.7 | INCORPORATED |
| 3 | `cbvj.pdf`, `Chemical Bonding (E)/1–12.pdf` | all 422 pp. (existing OCR index re-queried) | — | Zero hits for lattice/Born-Haber/Madelung/Fajans/Kapustinskii/radius-ratio/Schottky/Frenkel keyword set | — | IRRELEVANT TO PART 3 (verified by direct re-query, not assumed) |
| 4 | `CHEMICAL_BONDING.pdf` | §3.24–3.29 | same | Fajans' rules, melting point/solubility/colour/oxide-acidity tables | §4.2–4.7 | INCORPORATED |
| 4 | `Chemical_Bonding_Kohinoor_.pdf` | pp.216,217,219,220,230,237,238,239,240,241 (of 261) | same | Fajans mechanism, ionic potential, AgX solubility/colour, oxide thresholds, M.P. tables, Kapustinskii, bicarbonate exception | §4.2,4.3,4.6,4.7 | INCORPORATED; p.239 RESOLVED on re-rasterization at 250 DPI this session (2D MF4 / 3D ReO3-type bridged-octahedra structures) → incorporated into §4.7 |
| 4 | `cbvj.pdf` | all 177 pp. (re-screened, expanded keyword list) | pp.99,118,126 (of 12 flagged) | p.99 pseudo-noble-gas (duplicate); p.118 colour trends PbI₂/HgI₂/AgX (new); p.126 solubility-down-group for oxoanion salts (Part 3 scope) | §4.5 (p.118) | INCORPORATED (p.118); DUPLICATE (p.99); p.126 RESOLVED this session → retrofitted into Part 3 §3.6 as Worked Example 3.3 |
| 4 | `Chemical Bonding (E)/1–12.pdf` | all 245 pp. (re-screened, expanded keyword list) | — | 8 substring-only false positives ("lif"/"lii" inside unrelated OCR garble), individually opened and confirmed irrelevant | — | IRRELEVANT TO PART 4 (confirmed by opening each flagged page, not assumed from keyword match alone) |

## Outstanding items carried forward

- `Chemical_Bonding_Kohinoor_.pdf` p.239: RESOLVED this session (see Part 4 row above).
- `cbvj.pdf` p.126: RESOLVED this session — retrofitted into Part 3 §3.6 as Worked Example 3.3, resolving the PENDING flag.
- ~253 Kohinoor pages remain screened by keyword/text-search only (not individually opened) — this applies cumulatively across Parts 1–4, since the same full-text index is re-queried each time rather than re-read page by page.

## Parts 7–13 — additional matrix rows

| Part | Source PDF | Exact pages | Material found | Destination | Status |
|---|---|---|---|---|---|
| 7 | Chemical_Bonding_Kohinoor_.pdf | pp.33-34 | Overlap definition, bond energy components, Pauling-Slater rule | sec 7.1-7.2 | INCORPORATED |
| 8 | CHEMICAL_BONDING.pdf | sec 3.5 | Hybridisation motivation, %s/p/d table, steric number method | sec 8.1-8.4 | INCORPORATED |
| 8 | Chemical_Bonding_Kohinoor_.pdf | pp.95,97,102 | Bond angle vs %s character, CHF3/CH2F2 data | sec 8.3 | INCORPORATED |
| 9 | CHEMICAL_BONDING.pdf | sec 3.6 (full) | Full VSEPR treatment, all structures, Bent's rule, XeF6 anomaly | sec 9.1-9.9 | INCORPORATED |
| 10 | CHEMICAL_BONDING.pdf | sec 3.9-3.13 | Full MOT, LCAO, homonuclear/heteronuclear series, s-p mixing data | sec 10.1-10.7 | INCORPORATED |
| 11 | cbvj.pdf | pp.1-15 | IMF types, H-bonding, clathrates, hydride BP anomalies | sec 11.2-11.4 | INCORPORATED (resolves prior PENDING flag) |
| 11 | CHEMICAL_BONDING.pdf | sec 3.30-3.31 | Energy-distance table, ion-dipole/ion-induced dipole | sec 11.5 | INCORPORATED |
| 12 | CHEMICAL_BONDING.pdf | sec 3.32-3.34 | Electron sea model, band theory, conductor/insulator/semiconductor | sec 12.1-12.4 | INCORPORATED |
| 13 | Independently constructed | - | 11 cross-referencing integrated questions | sec 13.1-13.6 | INCORPORATED, independently constructed |

## Cumulative outstanding items (unchanged from Parts 1-6, still open)

- Chemical_Bonding_Kohinoor_.pdf p.239: RESOLVED this session.
- cbvj.pdf p.126: RESOLVED this session, retrofitted into Part 3 sec 3.6 as Worked Example 3.3.
- ~253 Kohinoor pages remain screened by keyword/text search only, not individually opened one-by-one
- Chemical Bonding (E)/2-4,6,7,9,10,11.pdf: fully OCR'd and keyword-screened across all parts to date; no part-specific content found in these particular files beyond what is already logged (they cluster around VSEPR/bond-parameter/overlap-type confirmatory material already covered from cleaner sources)
