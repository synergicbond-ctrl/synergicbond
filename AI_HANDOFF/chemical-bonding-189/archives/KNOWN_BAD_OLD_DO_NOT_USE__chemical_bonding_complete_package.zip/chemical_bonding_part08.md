## Part 8 — Hybridisation

### 8.1 Why Hybridisation Was Introduced

Consider methane, $\mathrm{CH_4}$. Carbon's ground-state configuration is $1s^22s^22p^2$ — only **two** unpaired $2p$ electrons, which would predict a maximum covalency of 2, not the observed 4. Even granting that one $2s$ electron can be promoted to the empty $2p_z$ orbital (giving an excited-state configuration $2s^12p_x^12p_y^12p_z^1$, four unpaired electrons, consistent with covalency 4), pure unhybridized orbitals still fail: three C–H bonds would form by $2p$–$1s$ overlap and the fourth by $2s$–$1s$ overlap. These are geometrically and energetically different overlaps (§7.2's overlap-effectiveness ordering: $s$–$p$ overlap is more effective than $s$–$s$ overlap), which would predict **three C–H bonds of one strength and length, and a fourth of a different strength and length, at unpredictable, non-tetrahedral angles**.

Experimentally, all four C–H bonds in methane are identical in length and strength, and all six H–C–H angles equal $109.5°$. Pure atomic orbitals cannot explain this; **hybridisation** — the mathematical mixing of atomic orbitals of comparable energy on the same atom to produce a new set of equivalent hybrid orbitals — resolves the discrepancy by construction: mixing one $2s$ and three $2p$ orbitals produces four **equivalent** $sp^3$ hybrid orbitals, each with identical shape, energy, and (25% $s$ + 75% $p$) character, oriented tetrahedrally by the mathematics of the mixing itself.

> **Why? (what "equivalent" actually means here)**
> The four $sp^3$ hybrid orbitals are not four different orbitals that happen to look similar — they are four mathematically identical linear combinations of the same starting $2s, 2p_x, 2p_y, 2p_z$ orbitals, differing from each other only in the *sign combination* used in the mixing, which is exactly what forces them to point in four different, symmetric (tetrahedral) directions while remaining otherwise identical. This is why all four resulting C–H bonds must be identical: they are formed from four *provably* identical hybrid orbitals overlapping with four identical H $1s$ orbitals.

### 8.2 Features of Hybrid Orbitals

1. **The number of hybrid orbitals produced equals the number of atomic orbitals mixed** — mixing one $s$ and three $p$ orbitals gives exactly four $sp^3$ hybrids, never more or fewer; this is a direct consequence of hybrid orbitals being linear combinations (a basis-set-preserving transformation), not new orbitals created from nothing.
2. **Each hybrid orbital has one large lobe and one small lobe** — the large lobe, pointing away from the other hybrid orbitals, is used for bonding (or holds a lone pair); the small lobe on the opposite side is generally not involved in bonding.
3. **%s character controls orbital shape, energy, and bond consequences** (Table 8.1) — as %s character rises, the orbital becomes more compact/bulkier and lower in energy (since $s$ orbitals are, on average, closer to and more strongly attracted by the nucleus than $p$ orbitals of the same shell); as %p character rises, the orbital becomes longer and thinner and higher in energy.

| Hybridisation | %s | %p | %d |
|---|---:|---:|---:|
| $sp$ | 50 | 50 | — |
| $sp^2$ | 33.3 | 66.7 | — |
| $sp^3$ | 25 | 75 | — |
| $sp^3d$ | 20 | 60 | 20 |
| $sp^3d^2$ | 16.7 | 50 | 33.3 |

**Table 8.1.** Percentage $s$, $p$, $d$ character by hybridisation type (verified against `CHEMICAL_BONDING.pdf` §3.5, Table 3.2).

![Figure 8.1: Hybrid orbital shapes vs %s character](figures/fig8_1_hybrid_orbital_shapes.svg)

### 8.3 Consequences of %s Character — Bond Length, Bond Strength, Bond Angle

**Bond length and strength.** Higher %s character means the bonding electron pair, on average, sits closer to the nucleus (more "s-like"), which shortens the resulting bond and — because closer, more concentrated overlap is generally more effective (§7.2) — also strengthens it.

**Bond angle.** Higher %s character in the hybrid orbitals used for bonding corresponds to larger inter-orbital angles: $sp$ (50% s) gives $180°$, $sp^2$ (33.3% s) gives $120°$, $sp^3$ (25% s) gives $109.5°$. This is not a coincidence but a mathematical consequence of how many equivalent directions a given mixture of orbitals can be split into while remaining maximally separated (minimizing electron-pair repulsion, the same qualitative logic developed fully as VSEPR in Part 9) — more $p$ character (which is directional and repulsion-sensitive) forces the hybrid orbitals into a geometry with *smaller* angles between them, while more $s$ character (non-directional) permits *larger* angles.

**Worked example 8.1 — Bond-angle/bond-length correlation in CHF₃ vs CH₂F₂** (cross-checked against `Chemical_Bonding_Kohinoor_.pdf` p.95, 102)

*Problem:* In $\mathrm{CHF_3}$, the H–C–F angle is smaller than the corresponding H–C–F angle in $\mathrm{CH_2F_2}$. Explain using Bent's rule (§8.5 below) and %s-character reasoning together.

*Reasoning:* Fluorine, highly electronegative, preferentially withdraws electron density through the C–F bond, which (Bent's rule) causes carbon to direct **more p-character** toward the more electronegative F substituents and correspondingly **more s-character** toward the less electronegative H substituent(s). $\mathrm{CHF_3}$ has three C–F bonds competing for p-character (leaving relatively little for each), while $\mathrm{CH_2F_2}$ has only two — meaning each C–F bond in $\mathrm{CHF_3}$ carries a *higher* share of p-character than in $\mathrm{CH_2F_2}$.

*Conclusion:* higher p-character between the two F-containing bonds in $\mathrm{CHF_3}$ compresses the F–C–F angle (and correspondingly opens the H–C–F angle less than in $\mathrm{CH_2F_2}$, where less p-character is concentrated on the fewer C–F bonds) — this bond-angle distortion is a direct, worked illustration of Bent's rule operating through the %s-character mechanism established in this section.

*Common mistake:* attributing this angle difference to electronegativity alone via the simple VSEPR argument ("more electronegative substituent, smaller angle at that substituent, larger elsewhere") without connecting it to the underlying %s-character redistribution mechanism — the VSEPR-level statement and the Bent's-rule/hybridisation-level explanation are describing the *same* phenomenon at two different levels of depth, and JEE Advanced increasingly expects the deeper (Bent's rule) explanation.

### 8.4 The Conventional Hybridisation Types

| Type | Steric number | Geometry | Example |
|---|---:|---|---|
| $sp$ | 2 | Linear | $\mathrm{BeCl_2}$, $\mathrm{CO_2}$ |
| $sp^2$ | 3 | Trigonal planar | $\mathrm{BF_3}$, $\mathrm{CO_3^{2-}}$ |
| $sp^3$ | 4 | Tetrahedral | $\mathrm{CH_4}$, $\mathrm{NH_4^+}$ |
| $sp^3d$ | 5 | Trigonal bipyramidal | $\mathrm{PCl_5}$ |
| $sp^3d^2$ | 6 | Octahedral | $\mathrm{SF_6}$ |
| $sp^3d^3$ | 7 | Pentagonal bipyramidal | $\mathrm{IF_7}$ |
| $dsp^2$ | 4 | Square planar | (transition-metal complexes, conventional treatment) |

![Figure 8.2: sp hybridisation](figures/orbitals/fig_hybrid_sp.svg)
![Figure 8.3: sp2 hybridisation](figures/orbitals/fig_hybrid_sp2.svg)
![Figure 8.4: sp3 hybridisation](figures/orbitals/fig_hybrid_sp3.svg)

**Figures 8.2–8.4.** Each shows the parent orbitals mixing into the resulting hybrid set, with the leftover unhybridized $p$ orbital(s) marked explicitly for $sp$ and $sp^2$ (these are exactly the orbitals used for π bonding in Part 7's overlap language) — and each carries the same model-status reminder, because this point cannot be overstated: hybridisation constructs directed orbitals mathematically; it is not a literal sequence of physical reshaping.

![Figure 8.5: dsp2 conventional model](figures/orbitals/fig_hybrid_dsp2.svg)
![Figure 8.6: sp3d conventional model](figures/orbitals/fig_hybrid_sp3d.svg)
![Figure 8.7: sp3d2 conventional model](figures/orbitals/fig_hybrid_sp3d2.svg)
![Figure 8.8: d2sp3 conventional model](figures/orbitals/fig_hybrid_d2sp3.svg)

**Figures 8.5–8.8.** The four $d$-orbital-involving conventional types, each explicitly boxed with the same qualification: these are examination/geometry bookkeeping tools (§2.7b's hypervalency caveat applies identically here), not literal descriptions of which orbitals are "really" used. Figure 8.8 makes the point sharpest — $d^2sp^3$ and $sp^3d^2$ predict the *identical* octahedral geometry, and are distinguished from each other only within the conventional inner-/outer-orbital coordination-complex framework, never by geometry alone.

The **steric number** — number of atoms bonded to the central atom plus number of lone pairs on it — is calculated by the systematic electron-counting method already introduced implicitly through valence-electron counting (§2.6): total valence electrons of the central atom and all attached atoms (adjusted for charge) are divided among σ-bond pairs and central-atom lone pairs; the sum of (bonded atoms) + (lone pairs) gives the steric number, which fixes the hybridisation directly via the table above. This is developed into a complete geometric framework, with lone-pair placement rules for each steric number, in Part 9.

### 8.5 Bent's Rule

**Bent's rule:** the more electronegative substituent on a central atom preferentially bonds through the hybrid orbital with **less s-character** (more p-character), while a lone pair preferentially occupies the hybrid orbital with **more s-character**.

> **Why? (the underlying reason, not just the statement)**
> A more electronegative substituent pulls the shared bonding electron density toward itself, away from the central atom. The central atom therefore "loses less" by directing that particular bond through an orbital with a high energy cost per unit of s-character retained (i.e., a low-s-character, p-rich orbital) — since s-character is precisely the "expensive," strongly-nucleus-attracted character that is most wasted on a bond where the electron density is being pulled away regardless. Conversely, a lone pair — entirely retained by the central atom, attracted only by its own nucleus — benefits maximally from being placed in the most s-rich (most tightly, favourably held) orbital available.

This is the same physical reasoning already used quantitatively in §8.3 (Worked Example 8.1) and is the general principle underlying the trigonal-bipyramidal axial/equatorial electronegativity preferences developed fully in Part 9.

### 8.6 Non-Equivalent Hybrid Orbitals

Not every set of hybrid orbitals on a given atom is equivalent. In $sp^3d$ hybridisation (trigonal bipyramidal electron geometry), the two axial orbitals and three equatorial orbitals are **not** equivalent to each other — the axial set is better described as having more $p$/$d$ character and the equatorial set more $s$/$p$ character, which is the direct structural basis of Bent's rule's application to trigonal-bipyramidal molecules (more electronegative substituents preferring the axial positions, lone pairs preferring equatorial) — developed with full worked structures in Part 9.

> **Important Conceptual Distinction — hybridisation model vs. actual molecular-orbital description.** Hybridisation is a **mathematical model** constructed specifically to rationalize observed bond equivalence and geometry using a valence-bond-theory framework; it is not a directly observable physical process, and the "hybridized state" of an atom cannot be detected spectroscopically as an intermediate stage on the way from atom to molecule (it never actually exists as a separate physical state). A more complete, first-principles description of the same molecules is available through molecular orbital theory (Part 10), which does not require the hybridisation concept at all — the two frameworks are complementary tools suited to different questions (hybridisation for predicting local geometry and comparing bond-parameter trends; MOT for predicting bond order, magnetism, and overall electronic structure), not competing claims about which one is "really" happening inside the molecule.

### 8.7 Limitations and Traps in Hybridisation Assignment

1. **Third-period-and-beyond central atoms with small, weakly-electronegative attached atoms may show little or no real hybridisation**, even when the conventional geometry-matching hybridisation label is still assigned for exam purposes. $\mathrm{PH_3}$, $\mathrm{AsH_3}$, $\mathrm{SbH_3}$, $\mathrm{H_2S}$, $\mathrm{H_2Se}$, and $\mathrm{H_2Te}$ show bond angles very close to $90°$ rather than the $\sim107$–$109°$ expected from $sp^3$ hybridisation — because the energy cost of promoting and mixing orbitals for a heavier central atom is not repaid by sufficiently strong bonds to a weakly-electronegative substituent like H, so the central atom bonds using nearly pure $p$ orbitals instead (bond angle close to the un-hybridized $p$-orbital angle of $90°$), with the lone pair sinking into an almost pure, non-hybridized $s$ orbital.
2. **Assigning "the" hybridisation of an atom in a resonance-stabilized or odd-electron species can be genuinely ambiguous** — different canonical resonance structures may formally suggest slightly different local hybridisation, and the real, delocalized structure (Part 6) is not perfectly captured by assigning one single hybridisation label.
3. **Hybridisation is a *local*, central-atom-centred model — it says nothing directly about overall molecular symmetry, magnetism, or bond order** beyond the geometry it predicts; conflating "I have assigned a hybridisation" with "I have fully described the bonding" is a common but incomplete habit this Part is specifically written to correct, given §8.6's explicit caveat above.

### Part 8 Summary

- Hybridisation is a mathematical mixing model introduced specifically to explain observed bond equivalence and geometry that pure, unhybridized atomic orbitals cannot account for (methane's four identical C–H bonds, Worked motivating example, §8.1).
- %s character systematically controls hybrid-orbital shape, bond length, bond strength, and the angle between hybrid orbitals — higher %s gives shorter/stronger bonds and larger inter-orbital angles.
- Bent's rule (more electronegative substituent → less s-character orbital; lone pair → more s-character orbital) is the mechanistic explanation underlying many bond-angle distortion and trigonal-bipyramidal axial/equatorial preference questions, worked explicitly for CHF₃ vs. CH₂F₂.
- Hybridisation is explicitly a model, not a directly observable physical state — real molecules do not pass through a detectable "hybridized atom" stage, and heavier central atoms bonded to weakly electronegative substituents (PH₃, H₂S, etc.) show bond angles indicating essentially *no* real hybridisation despite the conventional label still being assigned.

---

## Source Traceability — Part 8

| Source PDF | Pages | Material found | Destination | Status |
|---|---|---|---|---|
| `CHEMICAL_BONDING.pdf` | §3.5 (Valence Bond Theory / hybridisation subsection, full text) | Motivating methane example, features of hybrid orbitals, %s/%p/%d character table (Table 3.2, reproduced as Table 8.1), steric-number calculation method | §8.1–8.4 | INCORPORATED |
| `Chemical_Bonding_Kohinoor_.pdf` | p.95, p.97, p.102 (of 261) | Bond-angle-vs-%s-character worked data, CH₃Cl/CH₃F bond-strength comparison, CHF₃/CH₂F₂ angle data used for Worked Example 8.1 | §8.3 | INCORPORATED |
| `CHEMICAL_BONDING.pdf` | §3.6 (Bent's rule statement within the VSEPR section) | Bent's rule statement and axial/equatorial %s-character mechanism (already partially used in Part 2's back-bonding discussion; full geometric application reserved for Part 9) | §8.5, §8.6 | INCORPORATED (mechanism); PENDING LATER PART (full geometric worked structures → Part 9) |
| `cbvj.pdf` | p.40 (previously logged in Parts 1–2 matrix) | PH₃/AsH₃/PF₃ back-bonding and Lewis-base-order data, Drago's rule context (no-hybridisation heavier-central-atom case) | §8.7 | INCORPORATED (confirmatory, cross-referencing already-logged content) |

---

*Part 8 complete. Continuing to Part 9 (VSEPR Theory and Molecular Geometry).*
