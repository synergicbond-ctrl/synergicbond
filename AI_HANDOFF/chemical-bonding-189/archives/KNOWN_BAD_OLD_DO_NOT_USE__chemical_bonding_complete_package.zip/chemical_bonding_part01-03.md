# Chemical Bonding and Molecular Structure
### JEE Advanced Reference Chapter — Synergic Bond Chemistry

---

## Part 1 — Fundamental Ideas of Chemical Bonding

### 1.1 Why Do Atoms Form Bonds?

Isolated atoms are, in almost every case, higher in energy than the same atoms joined together in a molecule or a lattice. A chemical bond forms **only when the resulting arrangement has lower total energy than the separated atoms** — nothing more mystical than that. "Stability" in chemistry is not a vague virtue; it is a quantitative statement about energy: a bonded system is stable relative to the free atoms if

$$E_{\text{molecule}} < E_{\text{atom A}} + E_{\text{atom B}}$$

and the amount by which the molecule's energy is lower is released to the surroundings as the **bond dissociation energy**. If no arrangement of two approaching atoms can lower the total energy, no bond forms — this is why, for instance, two helium atoms do not combine (Part 10 will show exactly why, in molecular-orbital terms).

**Why energy actually drops.** As two atoms approach, two effects compete:

- **Attraction**: each nucleus is attracted to the *other* atom's electron cloud, and the two electron clouds can rearrange to concentrate charge density between the nuclei, which simultaneously attracts both nuclei toward that region.
- **Repulsion**: the two positively charged nuclei repel each other, and, as the electron clouds begin to overlap, electron–electron repulsion also rises.

At large separation, attraction dominates and the potential energy of the system falls as the atoms approach. At very short separation, repulsion (nuclear–nuclear, and Pauli-principle electron–electron repulsion as filled orbitals begin to overlap) rises steeply and dominates. Bond formation is simply the statement that there exists an intermediate separation at which the net energy is at a **minimum** — lower than at infinite separation.

> **Why? (physical reason, not just a label)**
> A covalent bond lowers energy specifically because concentrating electron density in the internuclear region allows *both* nuclei to be attracted to the same electrons simultaneously — this is a genuine quantum mechanical lowering of kinetic and potential energy relative to each electron being localized on a single atom (formalized later as the bonding molecular orbital, Part 10). It is not correct to say "atoms bond to complete their octet" as a causal mechanism — octet completion is a bookkeeping *pattern* seen in stable molecules, not the physical driving force. The driving force is always energy lowering; the octet rule is a useful empirical shortcut for predicting *when* that lowering typically occurs for second-period elements (Part 1.7 below).

### 1.2 The Potential Energy Curve

Plotting potential energy of the two-atom system against internuclear distance $r$ produces a curve with a characteristic shape (illustrated below for a diatomic molecule such as H₂):


![Figure 1.1: Potential energy vs internuclear distance for a diatomic molecule](figures/fig1_1_pe_curve.svg)

**Figure 1.1.** Potential energy of a two-atom system as a function of internuclear distance $r$. At large $r$, $E \to 0$ (free atoms, taken as the reference). As the atoms approach, attractive interactions (nucleus–electron) lower the energy until a minimum is reached at $r = r_0$. At separations smaller than $r_0$, nucleus–nucleus repulsion and electron-cloud (Pauli) repulsion rise steeply, so $E$ increases sharply. This handwritten-source diagram (confirmed against `cbvj.pdf`, p. 1) labels the same three features — attractive branch, bond-formation point, and dissociation limit — using the shorthand "attraction > repulsion" for the descending branch and "B.L." (bond length) at the minimum; the terminology used throughout this chapter (E₀, r₀, Dₑ) is the standard JEE-Advanced notation for the same quantities.

Key quantities read off this curve:

| Symbol | Name | Meaning |
|---|---|---|
| $r_0$ | Equilibrium bond length | Internuclear distance at the energy minimum; the experimentally measured bond length |
| $E_0$ | Bond energy (well depth) | Energy of the molecule at $r_0$ relative to free atoms (negative — the molecule is lower in energy) |
| $D_e$ | Bond dissociation energy | Magnitude of energy required to separate the bonded atoms back to $r = \infty$; numerically $D_e = -E_0$ measured from the minimum to the zero-energy asymptote |

**Why the curve has exactly this shape — cause and effect, not just description:**

- *Descending branch (large to intermediate $r$):* As $r$ decreases from infinity, the electron of one atom begins to feel the attraction of the other nucleus. This attractive potential energy term scales approximately as $-1/r$ at long range, so energy falls continuously as the atoms approach — this is the region where "attraction exceeds repulsion."
- *Rising branch (small $r$):* Once the electron clouds begin to interpenetrate significantly, two repulsive effects switch on and grow much faster than the attractive term: (i) direct nucleus–nucleus Coulomb repulsion, which scales as $+1/r$ and diverges as $r \to 0$, and (ii) Pauli exclusion-driven repulsion between electrons of like spin in overlapping filled orbitals, which rises exponentially at short range. Because these repulsive terms grow faster than the attractive term as $r$ decreases, there must be some $r_0$ at which the net force (the slope of the curve) is zero — this is the equilibrium bond length, and it is a genuine energy minimum, not an arbitrary "resting point."
- *At $r = r_0$ exactly:* $\dfrac{dE}{dr} = 0$. This is the mathematical statement of mechanical equilibrium — the attractive and repulsive forces exactly balance. Any small displacement from $r_0$ (compression or stretching) raises the energy, which is why bonds resist both compression and extension and why molecules vibrate about $r_0$ rather than sitting statically at it (at any $T > 0$ K, thermal energy populates vibrational levels above the bottom of the well).

> **JEE Advanced Insight**
> A stronger bond (larger $|D_e|$) is associated with a *narrower, deeper* well and, generally, a *shorter* $r_0$ — because greater orbital overlap simultaneously increases the attractive stabilization and requires the repulsive wall to be encountered at smaller $r$. This is why bond order, bond length, and bond enthalpy are correlated quantities used together in ordering questions (Part 5 and Part 13): higher bond order ⇒ shorter bond length ⇒ higher bond dissociation energy, for a given pair of atoms.

> **Common Trap**
> Do not say a molecule forms "because atoms want to be stable." Atoms have no intent. Always cite the actual energy comparison: *this* arrangement has lower potential energy than free atoms because of *this* specific attractive interaction, so energy is released (bond formation is exothermic) and the reverse process (bond breaking) requires that same amount of energy to be supplied (endothermic). This bond-formation/bond-breaking energy sign convention — exothermic formation, endothermic dissociation — is worth fixing early, since sign errors here propagate into Born–Haber cycle problems in Part 3.

### 1.3 Conditions Required for Bond Formation

For two atoms (or ions) to form a stable bond, the following must hold simultaneously:

1. **Net energy lowering.** As shown above, there must exist some $r_0$ at which total energy is below the separated-atom reference.
2. **Symmetry/orbital compatibility** (developed fully in Part 7 and Part 10): the interacting orbitals must be able to overlap constructively — they must have appropriate relative orientation and comparable energy. Two atoms can approach to short range and still fail to bond if no orbital combination gives net stabilization (this is exactly the He–He case, Part 10.12).
3. **Correct electron count in the interacting orbitals.** A bonding interaction is only net-stabilizing if bonding orbitals are preferentially filled over antibonding ones — this becomes quantitative via bond order in Part 10, but qualitatively it is why filled-shell atoms (noble gases) resist bonding: any stabilization from a bonding combination is cancelled by destabilization from the antibonding combination that must also be filled.

### 1.4 Classification of Chemical Interactions

Bonding interactions are conventionally divided by the *mechanism* through which the attractive, energy-lowering interaction is achieved. It is essential to see these not as unrelated categories memorised separately, but as different strategies for solving the same underlying problem — how to arrange electrons and nuclei so that electron density sits where it can attract multiple nuclei at once, or how ions can be held in a lattice by pure electrostatics.

| Interaction | Mechanism | Typical partners | Order of magnitude (strength) |
|---|---|---|---|
| **Ionic (electrovalent)** | Complete transfer of one or more electrons from an electropositive atom to an electronegative atom; resulting ions held by electrostatic (Coulombic) attraction | Metal + non-metal, large electronegativity difference | Strong (100s of kJ mol⁻¹, lattice energy) |
| **Covalent** | Sharing of an electron pair between two nuclei, with electron density concentrated between them | Non-metal + non-metal, similar electronegativity | Strong (typically 150–950 kJ mol⁻¹ per bond) |
| **Coordinate (dative)** | Sharing of an electron pair contributed entirely by one atom (the donor) to an empty orbital on the other (the acceptor) | Lewis base + Lewis acid | Comparable to an ordinary covalent bond once formed |
| **Metallic** | Delocalisation of valence electrons over a lattice of positive ion cores; electrons are not localized to any one atom or bond | Metal + metal (or one metal) | Variable — from weak (alkali metals) to very strong (transition metals, e.g., W) |
| **Hydrogen bond** | Electrostatic + partial covalent attraction between a H atom covalently bonded to a highly electronegative atom (N, O, F) and a lone pair on another electronegative atom | H–N, H–O, H–F donors; N, O, F, and occasionally Cl acceptors | Intermediate (10–40 kJ mol⁻¹) — much weaker than covalent/ionic, much stronger than van der Waals |
| **van der Waals (intermolecular)** | Dipole–dipole, dipole–induced dipole, and instantaneous dipole–induced dipole (London dispersion) attractions between otherwise complete molecules | Any molecules, polar or non-polar | Weak (0.4–40 kJ mol⁻¹) |

Three points about this table deserve explicit emphasis, because JEE Advanced regularly tests them:

**(a) These are idealized extremes, not watertight boxes.** Ketelaar's triangle (Figure 1.2) is the classical way of representing this: place ionic, covalent, and metallic bonding at the three corners of a triangle. Compounds with bonding predominantly of one type sit near a corner; compounds intermediate between two types lie along an edge; compounds with some character of all three lie inside the triangle.

![Figure 1.2: Ketelaar's triangle](figures/fig1_2_ketelaar_triangle.svg)

**Figure 1.2.** The three idealized bond types sit at the corners; real compounds occupy the interior or edges according to their actual electron distribution. This is a qualitative classification device, not a quantitative scale — position within the triangle is not read off a numeric axis, only compared relatively (e.g., "closer to the ionic corner than X" is a meaningful statement; "at coordinate (0.3, 0.5)" is not, at this level of treatment).

Lithium chloride, for example, is conventionally classified as ionic, yet its solubility in ethanol (a non-polar-ish organic solvent) is evidence of appreciable covalent character — a purely ionic solid would not dissolve appreciably in a non-aqueous, low-polarity solvent. This graded, not binary, character of bonding is the conceptual basis for Fajans' rules in Part 4.

**(b) The three "pure" categories arise from the electropositive/electronegative character of the participating atoms.**
- If one atom is strongly electropositive (tends to lose electrons) and the other strongly electronegative (tends to gain electrons), electron transfer is favourable → ionic bond.
- If both atoms are electronegative (both want to gain, neither wants to lose), electrons are shared rather than transferred → covalent bond.
- If both atoms are electropositive (neither wants to hold electrons tightly), valence electrons delocalize over the whole assembly of atoms rather than localizing on any one atom or bond → metallic bond.

**(c) Hydrogen bonding and van der Waals forces are *intermolecular*, not primary bonds.** They act *between* already-complete molecules (or between separate parts of one large molecule) rather than holding a single molecule's own atoms together, and they are treated in full generality in Part 11. They are listed here only to complete the classification picture — a common JEE trap is to describe hydrogen bonding as a "type of covalent bond," which is imprecise: it is predominantly electrostatic in character with a partial covalent/orbital-overlap contribution, and it is categorically weaker than a normal covalent bond (roughly one-tenth the energy).

> **Exam Method**
> When a question asks you to classify the bonding in an unfamiliar compound, do not guess from the compound's name. Check (i) the electronegativity difference between the constituent atoms (large gap → ionic character is significant); (ii) whether both atoms are non-metals of comparable electronegativity (→ covalent); (iii) whether the species is a metal or alloy (→ metallic); and only then, if the compound is molecular, ask whether hydrogen bonding or van der Waals forces are relevant to its *physical* properties (melting/boiling point, solubility) as distinct from the *primary* bonding holding each molecule together.

### 1.5 Electronic Theories of Valency — Historical and Conceptual Basis

Before quantum mechanics offered a rigorous account of bonding, chemists built increasingly refined **electronic theories** to rationalize why atoms combine in fixed, predictable ratios. The unifying insight behind all of them is that **valency is an electronic phenomenon**: the number of bonds an atom forms, and the type of bond it forms, is governed by the number and arrangement of electrons in its outermost (valence) shell — not by any property of the nucleus directly.

The progression of these ideas (detailed with full worked treatment in Part 2) is:

1. **Kossel's electrostatic (ionic) theory (1916)** — explains bond formation between markedly electropositive and electronegative atoms via complete electron transfer, driven by both atoms attaining a noble-gas electron configuration.
2. **Lewis's electron-pair (covalent) theory (1916)** — explains bond formation between atoms of similar electronegativity via *sharing* rather than transfer of an electron pair, again typically resulting in a noble-gas-like outer shell for each atom.
3. **Sidgwick–Powell theory (1940)** and its refinement, **Gillespie's VSEPR theory (1957)** — extend the electron-counting idea from *how many* bonds form to *what shape* the resulting molecule adopts, based on the number of electron pairs (bonding and lone) around the central atom (Part 9).
4. **Valence bond theory** and **molecular orbital theory** (Parts 7, 8, 10) — the quantum-mechanical treatments that explain *why* electron sharing lowers energy in the first place, and that correctly predict properties (such as the paramagnetism of O₂) that purely electron-counting theories cannot.

### 1.6 The Octet Concept — Origin and Physical Meaning

**Observation:** The noble gases (He, Ne, Ar, Kr, Xe, Rn) exist as stable, monatomic, chemically inert species under ordinary conditions. Every other main-group element, left to itself, is reactive.

**Physical reason:** The noble gases (other than He) have a filled outer $ns^2np^6$ configuration — eight electrons in the valence shell. A filled valence shell corresponds to a particularly low-energy, high-symmetry electron distribution: all the orbitals of that principal shell accessible at moderate energy are completely occupied, so there is no accessible orbital of comparable energy into which an electron could be promoted to form a new bond, and no partially filled orbital available to accept a shared pair either. This is why noble gases are largely unreactive — not because "eight is a magic number," but because a filled shell leaves no low-energy pathway for further orbital overlap to lower the system's energy.

**Consequence — the octet rule as a predictive heuristic:** Main-group atoms other than noble gases tend to gain, lose, or share electrons until they too attain eight electrons in the valence shell (a share of eight, some "owned" outright and some "borrowed" via bonding), because doing so mimics the low-energy, filled-shell arrangement of the nearest noble gas. Hydrogen and helium are the standard exception even within this rule — they are stable with only **two** electrons (a filled $1s$ shell), so H is said to obey a **duplet rule** rather than an octet rule.

$$\text{Na} \rightarrow \text{Na}^+ + e^- \qquad (\text{Na}^+: 1s^22s^22p^6, \text{ same configuration as Ne})$$
$$\text{Cl} + e^- \rightarrow \text{Cl}^- \qquad (\text{Cl}^-: 1s^22s^22p^63s^23p^6, \text{ same configuration as Ar})$$

> **Why? (going one level deeper)**
> It would be circular to say "Na loses an electron because it wants to look like Ne." The real reason is energetic: removing the single loosely-held $3s^1$ electron from Na costs a *first* ionization energy of only 496 kJ mol⁻¹ (this electron is well-shielded from the nucleus by the filled $n=1,2$ shells and sits in a higher shell), whereas removing a *second* electron from Na⁺ would mean breaking into the full $2p^6$ shell — an enormously higher ionization energy (~4560 kJ mol⁻¹) because that electron is both closer to the nucleus and no longer shielded by an outer electron. The "octet" outcome is simply what falls out of this large jump in successive ionization energies at shell boundaries; it is the ionization-energy data, not an abstract preference for eight electrons, that is the underlying cause.

### 1.7 Limitations of the Octet Rule

The octet rule is a highly useful first approximation but is broken in several well-defined classes of compounds — each of which is a standing JEE Advanced topic in its own right, developed fully in Part 2.7–2.9 and Part 8:

1. **Electron-deficient species** — central atoms with fewer than four valence electrons (e.g., Be, B) cannot reach an octet even using all available electrons for bonding: $\mathrm{BeCl_2}$ has only 4 electrons around Be; $\mathrm{BF_3}$ has only 6 around B.
2. **Expanded-octet (hypervalent) species** — elements of period 3 and beyond can accommodate more than eight electrons around the central atom, because an energetically accessible extra orbital set becomes available once the atom carries partial positive charge in a bond (the modern explanation, avoiding uncritical reliance on 3d-orbital participation, is developed in Part 2.9 and Part 12): $\mathrm{PF_5}$ (10 electrons around P), $\mathrm{SF_6}$ (12 around S).
3. **Odd-electron (free-radical) species** — molecules with an odd total electron count cannot possibly pair all electrons into octets: $\mathrm{NO}$ (11 valence electrons), $\mathrm{ClO_2}$, $\mathrm{NO_2}$.
4. **Species whose ground-state bonding is not well described by simple electron pairing at all** — $\mathrm{O_2}$ is the classic case: the Lewis structure $\mathrm{O=O}$ (all electrons paired) predicts diamagnetism, but $\mathrm{O_2}$ is experimentally **paramagnetic**, with two unpaired electrons. This single fact was historically decisive evidence that a more complete theory (molecular orbital theory, Part 10) was required beyond simple electron-pair counting — this is developed fully in Part 10.12, where it is shown that MOT correctly predicts two unpaired electrons in degenerate $\pi^*$ orbitals.

> **Exception**
> Even though the octet rule fails in the cases above, it remains the *correct default assumption* for second-period elements C, N, O, F when they are not otherwise electron-deficient or odd-electron species — the failures above are the identifiable exceptions, not evidence that the rule is generally unreliable. A working rule for JEE: expanded octets are essentially never seen for strictly second-period central atoms (C, N, O, F) bonded only to ordinary substituents, precisely because period-2 atoms have no accessible 3-level orbitals to expand into.

### 1.8 Part 1 Summary

- A bond forms when, and only when, some internuclear separation gives lower total energy than infinitely separated atoms; this is captured completely by the potential-energy curve (Figure 1.1), whose minimum defines $r_0$ (bond length) and whose depth defines $D_e$ (bond dissociation energy).
- Bonding interactions are classified by mechanism (ionic, covalent, coordinate, metallic, hydrogen-bonding, van der Waals) but form a continuum (Ketelaar's triangle), not sharply separated categories.
- The octet rule is an energetically-grounded heuristic — rooted in the very large jump in ionization/electron-gain energies at filled-shell boundaries — not an independent law of nature, and it has well-characterized, systematically explainable exceptions (electron-deficient, expanded-octet, odd-electron, and O₂-type paramagnetic species).

---


## Part 2 — The Lewis–Kossel Approach and Lewis Structures

### 2.1 Kossel's Electrostatic (Ionic) Theory

Walther Kossel (1916) proposed the first systematic electronic account of ionic bonding: atoms of markedly electropositive elements lose electrons, atoms of markedly electronegative elements gain electrons, and the two resulting ions are held together purely by **electrostatic (Coulombic) attraction**, with both ions attaining a stable noble-gas electron configuration in the process.

**Worked illustration — NaCl formation** (verified against `CHEMICAL_BONDING.pdf`, §3.3):

$$\text{Na} \; (1s^22s^22p^63s^1) \longrightarrow \text{Na}^+ \; (1s^22s^22p^6) + e^-$$
$$\text{Cl} \; (1s^22s^22p^63s^23p^5) + e^- \longrightarrow \text{Cl}^- \; (1s^22s^22p^63s^23p^6)$$

Na⁺ now has the electron configuration of Ne; Cl⁻ now has the configuration of Ar.

**True noble-gas configuration vs. pseudo-noble-gas configuration.** Na⁺ (electron count 2,8) and Cl⁻ (2,8,8) attain a genuine noble-gas configuration — the outermost shell has the $ns^2np^6$ pattern of an actual noble gas (Ne and Ar respectively). This is not the only way a cation can reach a filled-subshell outer shell, however. Post-transition-metal cations such as Zn²⁺, Cd²⁺, Hg²⁺, and Cu⁺ instead attain a **pseudo-noble-gas configuration**: an outermost shell of the form $(n-1)d^{10}$ — 18 electrons rather than 8 — because the $d$ subshell fills before ionization removes only the outer $s$ electrons. For example, Cu⁺ (2,8,18) and Zn²⁺ (2,8,18) both have an outer 18-electron shell, structurally analogous to Na⁺'s outer 8-electron shell but *not identical to any actual noble gas's electron count*.

> **Why this distinction matters (not just terminology)**
> A filled $d^{10}$ shell shields the nuclear charge far less effectively than a filled $p^6$ shell does, because $d$ orbitals are more diffuse and penetrate less toward the nucleus. Consequently, a cation with a pseudo-noble-gas configuration has a **higher effective nuclear charge felt at its surface** than a same-charge, similar-size cation with a true noble-gas configuration — which makes it a **more strongly polarizing** ion (Fajans' rules, Part 4). This is the direct explanation for an experimentally observed and frequently tested trend: covalent character increases sharply down the sequence $\mathrm{ZnCl_2 < CdCl_2 < HgCl_2}$ even though ionic radius is also increasing (which by itself, per Fajans' rules, ought to *decrease* polarizing power) — the pseudo-noble-gas shielding effect dominates over the simple size trend. The same reasoning explains why $\mathrm{AgCl}$, $\mathrm{AgBr}$, and $\mathrm{AgI}$ (Ag⁺: pseudo-noble-gas, 2,8,18,18) show markedly more covalent character than the corresponding alkali-metal halides. The electrostatic attraction between Na⁺ and Cl⁻ is the "bond." Extended over a crystal, every Na⁺ is surrounded by six Cl⁻ and vice versa (developed fully with radius-ratio rules and lattice energy in Part 3).

**Worked illustration — CaCl₂ formation:** Ca (outer configuration $4s^2$) is electropositive and loses *two* electrons — one to each of two separate Cl atoms — because a single Cl atom can accept only one electron (it needs only one more electron to complete its octet):

$$\text{Ca} \longrightarrow \text{Ca}^{2+} + 2e^- \qquad 2\,\text{Cl} + 2e^- \longrightarrow 2\,\text{Cl}^-$$

giving the ionic formula unit $\mathrm{Ca^{2+}(Cl^-)_2}$.

> **Why? (going deeper on "why lose electrons at all")**
> Kossel's theory only *works* when the energy released by the electron-gaining atom (electron-gain enthalpy, favourable/exothermic for most non-metals) plus the electrostatic lattice-formation energy exceeds the energy that must be *supplied* to strip the electron off the electropositive atom (ionization energy, always endothermic). The theory itself does not derive this energy balance — that derivation is the Born–Haber cycle, covered fully in Part 3.9 — but Kossel's contribution was to correctly identify *which* electron configuration each ion should end up with (the noble-gas configuration) and *why* that configuration is preferred (Part 1.6).

### 2.2 Lewis's Electron-Pair (Covalent) Theory

G. N. Lewis (1916) extended electronic bonding theory to atoms of similar electronegativity, where neither atom has a strong enough pull on electrons to justify complete transfer. Instead, **a pair of electrons is shared between the two atoms**, with each atom contributing one electron to the shared pair (for an ordinary covalent bond) — the shared pair is simultaneously attracted to both nuclei, which is the source of the bonding stabilization (Part 1.1, and rigorously in Part 7 and Part 10).

**Lewis symbols.** In a Lewis symbol, only the *valence* (outermost-shell) electrons of an atom are shown, as dots arranged around the elemental symbol — core electrons are omitted because they do not participate in ordinary bond formation.

```
   H·          ·N·         :O:          :F:
                  ··          ··          ···
                                             ·
(1 valence e⁻) (5 valence e⁻, N)  (6 valence e⁻, O)  (7 valence e⁻, F)
```

**Formation of Cl₂ (single covalent bond):**

$$:\!\overset{\displaystyle ..}{\text{Cl}}\!\cdot \;+\; \cdot\!\overset{\displaystyle ..}{\text{Cl}}\!: \;\longrightarrow\; :\!\overset{\displaystyle ..}{\text{Cl}}\!:\!\overset{\displaystyle ..}{\text{Cl}}\!:$$

Each Cl atom starts with seven valence electrons (one unpaired). By sharing one electron each, the shared pair is counted toward *both* atoms' octets, so each Cl atom now has access to eight electrons (six as three lone pairs it owns outright, plus a share of the bonding pair) — both atoms simultaneously attain an argon-like outer-shell electron count. In valence-bond line notation this is written $\mathrm{Cl-Cl}$, where the line represents the shared electron pair.

**Formation of CCl₄ (four single bonds):** Carbon has four valence electrons, one short of... actually four short of an octet; each Cl is one electron short. Carbon shares one electron with each of four Cl atoms, forming four C–Cl bonds; carbon attains an octet (4 bonding pairs, fully "shared-in"), and each Cl attains an octet (3 lone pairs + 1 bonding pair).

**Formation of NH₃ — and the origin of the lone pair.** Nitrogen has five valence electrons; three are used to form three N–H bonds (each H contributing its one electron), and **two electrons remain on N, unshared** — this pair is called a **lone pair**. The existence of this "left-over," non-bonding pair on N is the single most important structural fact about ammonia: it is precisely the presence of this lone pair that (a) is available for coordinate bond donation (Section 2.4) and (b) distorts the H–N–H bond angle away from the ideal tetrahedral value, as developed quantitatively in Part 9.

**Double and triple bonds.** When four electrons (two pairs) are shared between one pair of atoms, the result is a **double bond**; when six electrons (three pairs) are shared, a **triple bond**:

$$\mathrm{O=C=O} \quad (\text{CO}_2,\ \text{two C=O double bonds}) \qquad \mathrm{N \equiv N} \quad (\text{N}_2,\ \text{one triple bond})$$

> **Why more shared pairs = shorter, stronger bond**
> Each additional shared pair adds further electron density concentrated in the internuclear region, which increases the net nucleus–electron attraction pulling the two nuclei together. This is why bond order (Part 5, Part 10) correlates directly with bond length (shorter with higher order) and bond enthalpy (higher with higher order) for a given pair of atoms — it is not a separate empirical fact but a direct consequence of "more shared electron density between the nuclei → more attraction → shorter equilibrium separation and deeper energy well."

### 2.3 Comparing Kossel and Lewis: One Underlying Idea

Both theories are driven by the *same* underlying principle — atoms rearrange their valence electrons to approach a noble-gas-like configuration, because (Part 1.6) a filled valence shell is a low-energy electron arrangement. They differ only in *mechanism*:

| | Kossel (ionic) | Lewis (covalent) |
|---|---|---|
| Electron movement | Complete transfer, one atom to another | Sharing, pair remains associated with both atoms |
| Driving asymmetry | Large electronegativity difference | Small/no electronegativity difference |
| Resulting species | Discrete cations and anions, held by long-range electrostatics | Discrete molecules, held by short-range, directional shared pairs |
| Physical state consequence | High-melting crystalline lattices | Often low-melting molecular solids, liquids, or gases |

### 2.4 The Coordinate (Dative) Covalent Bond

An ordinary covalent bond has each atom contributing one electron to the shared pair. A **coordinate (dative) bond** is a covalent bond in which **both** electrons of the shared pair originate from a single atom (the **donor**, which must possess a lone pair) while the other atom (the **acceptor**) contributes an empty orbital.

**Once formed, a coordinate bond is indistinguishable from an ordinary covalent bond** — it differs only in its *origin*, not in its final electronic character, bond length, or bond strength. This point is worth stating explicitly because it is a frequently tested conceptual distinction (see the "Important Conceptual Distinctions" note at the end of this Part).

**Worked illustration — NH₄⁺ formation** (Figure 2.1):

$$\mathrm{NH_3} + \mathrm{H^+} \longrightarrow \mathrm{NH_4^+}$$

![Figure 2.1: Coordinate bond formation in NH4+](figures/fig2_1_nh4_coordinate_bond.svg)

**Figure 2.1.** Ammonia already possesses a complete octet on N (three N–H bonds + one lone pair). When it reacts with H⁺ (which has an empty $1s$ orbital and no electrons of its own to contribute), the lone pair on N is donated wholesale into that empty orbital, forming a new N–H bond. **All four N–H bonds in NH₄⁺ are experimentally identical** in length and strength — there is no way to distinguish, in the product ion, which N–H bond was "formed by sharing" and which was "formed by donation." This is the clearest possible demonstration that coordinate and ordinary covalent bonds are the *same kind of bond* once formed.

**Worked illustration — NH₃·BF₃ adduct.** BF₃ has only six electrons around B (electron-deficient, Section 2.7) and therefore an empty $2p$ orbital on B. Ammonia's lone pair on N is donated into this empty orbital:

$$\mathrm{H_3N:} + \mathrm{BF_3} \longrightarrow \mathrm{H_3N \to BF_3}$$

The arrow notation $\mathrm{N \to B}$ (rather than a plain line) is conventionally used specifically to flag the *donor–acceptor origin* of a bond where it is pedagogically useful to do so (for instance, to track formal charge — N becomes formally $+1$ and B formally $-1$ in this adduct) — but the arrow is a notational convenience, not a statement that the resulting bond is physically different from a normal covalent bond.

**Further coordinate-bond examples** (all confirmed structurally consistent with `CHEMICAL_BONDING.pdf`, §3.3):

$$\mathrm{PCl_5 + Cl^- \longrightarrow [PCl_6]^-} \qquad \mathrm{SbF_5 + F^- \longrightarrow [SbF_6]^-} \qquad \mathrm{H_2O + H^+ \longrightarrow H_3O^+} \qquad \mathrm{F^- + BF_3 \longrightarrow [BF_4]^-}$$

In each case, a species with a lone pair (Cl⁻, F⁻, H₂O) donates that pair into an empty/expandable orbital on an electron-deficient or hypervalent-capable acceptor.

> **JEE Advanced Insight**
> The requirement for coordinate bonding is *not* "one atom must be a metal" — it is simply: one participant needs an available lone pair (Lewis base) and the other needs an accessible empty orbital (Lewis acid). This is exactly the Lewis acid–base framework, and every coordinate-bond example above is a Lewis acid–base reaction. Recognizing a species as electron-deficient (BF₃, AlCl₃) or as possessing accessible empty $d$-type orbitals in an expandable valence shell (PCl₅, SbF₅) immediately tells you it can act as a Lewis acid and accept a coordinate bond.

### 2.5 Formal Charge

**Definition and derivation.** When a Lewis structure is drawn, it is useful to check how the electron count around each atom compares to that atom's *original* number of valence electrons as a free atom — this bookkeeping quantity is the **formal charge**:

$$\text{Formal charge} = V - N - \frac{B}{2}$$

where $V$ = number of valence electrons in the free (neutral) atom, $N$ = number of non-bonding (lone-pair) electrons on that atom *in the structure as drawn*, and $B$ = number of bonding electrons around that atom (i.e., 2 × number of bonds to that atom) *in the structure as drawn*.

**Physical meaning.** Formal charge answers the question: *if bonding electrons were shared exactly equally between the two bonded atoms (ignoring real electronegativity differences), what net charge would be left on this atom?* It is explicitly **not** the same as the real, physically measured partial charge on an atom (which depends on the actual electronegativity difference and is always smaller in magnitude than a full formal-charge unit for typical covalent bonds), and it is **not** the same as oxidation number (which assigns *all* bonding electrons to the more electronegative atom, the opposite extreme assumption). All three — formal charge, oxidation number, and real partial charge — are different bookkeeping conventions for the same electrons, useful for different purposes; conflating them is a common and heavily tested error (see the Important Conceptual Distinctions note below).

**Worked example 2.1 — Formal charges in CO**

*Problem:* Determine the formal charge on each atom in carbon monoxide, CO, given the correct Lewis structure has a C≡O triple bond with one lone pair on each atom.

*Concept tested:* Formal charge calculation combined with correct multiple-bond/lone-pair placement to satisfy total valence electron count.

*Reasoning:* Total valence electrons = C(4) + O(6) = 10. A single bond plus two lone pairs on each atom would only use $2 + 6 + 6 = 14$... let's count properly. If C and O were joined by a triple bond (6 bonding electrons) with one lone pair on each (2 + 2 = 4 non-bonding electrons), total = $6 + 4 = 10$ ✓, matching the valence electron count exactly, and giving both atoms an octet (C: 1 lone pair (2e⁻) + share of 6 bonding e⁻ = 8; O: same).

*Structure:* $:\!\mathrm{C}\!\equiv\!\mathrm{O}\!:$ — one lone pair on C, one lone pair on O, connected by a triple bond.

*Formal charge on C:* $V = 4$ (C is in Group 14), $N = 2$ (one lone pair), $B = 6$ (triple bond = 6 bonding electrons around C). FC(C) $= 4 - 2 - 6/2 = 4 - 2 - 3 = -1$.

*Formal charge on O:* $V = 6$, $N = 2$ (one lone pair), $B = 6$. FC(O) $= 6 - 2 - 3 = +1$.

*Verification:* Sum of formal charges $= -1 + 1 = 0$, correctly matching the overall neutral charge on the CO molecule. ✓

*Conclusion:* CO carries formal charges of $-1$ on C and $+1$ on O — despite oxygen being the more electronegative atom. This is chemically unusual (formal negative charge is normally expected on the more electronegative atom, see below) and is exactly why CO's dipole moment is anomalously small (0.112 D, far smaller than expected from the C–O electronegativity difference): the electronegativity-driven bond dipole (pointing C→O, i.e., negative end toward O) is substantially cancelled by the formal-charge-driven contribution (negative end toward C), as detailed quantitatively in Part 5.

*Common mistake:* Students frequently draw CO with a double bond ($\mathrm{O=C}$, mimicking CO₂) and two lone pairs on O, one on C. This uses only $4 + 4 + 4 = ...$ let's check: double bond = 4 bonding e⁻, O has 2 lone pairs (4 e⁻), C has 1 lone pair (2e⁻); total $= 4+4+2 = 10$ ✓ electron count also works, and both atoms reach an octet in *this* structure too (C: 2 lone e⁻ + share of 4 = 6... **this does not give C an octet** — C would only have 6 electrons around it, violating the octet rule on carbon). This structure is therefore incorrect, and checking octet completion on *every* atom (not just electron count matching) is the necessary second check.

**Worked example 2.2 — Formal charges and structure selection for SO₄²⁻**

*Problem:* Sulfate has two common candidate Lewis structures — one with all four S–O bonds as single bonds (giving S a formal charge of $+2$ and each O a formal charge of $-1.5$ on average is impossible per-atom, so more precisely: all-single-bond structure gives each O formal charge $-1$ and S formal charge $+2$), and one with two S=O double bonds and two S–O single bonds (giving lower formal charges). Which is preferred, and why does this matter?

*Reasoning:* All-single-bond structure: S has 4 bonds, 0 lone pairs → $B=8, N=0, V=6$ → FC(S) $= 6-0-4 = +2$. Each O (singly bonded, 3 lone pairs) → $B=2,N=6,V=6$ → FC(O) $=6-6-1=-1$. Sum $= +2 + 4(-1) = -2$ ✓ matches overall charge.

Two-double-bond structure: S now has 6 bonds' worth of bonding electrons ($2\times2 + 2\times1$ pairs $=$ 4 bonds, 2 of which are double) — S: $B = 12$ (4 bonds, 2 double + 2 single $= 2+2+1+1=6$ bond pairs $\times 2 = 12$ electrons), $N=0$ → FC(S) $=6-0-6=0$. The two doubly-bonded O: $B=4,N=4$ → FC $=6-4-2=0$. The two singly-bonded O: FC $=-1$ as before. Sum $= 0+0+0-1-1=-2$ ✓.

*Which is "more reasonable"?* The general guideline (not an absolute rule) is that **the structure with formal charges closest to zero, and with any negative formal charge residing on the most electronegative atom, is generally the lower-energy, more representative structure.** By this guideline the two-double-bond structure (S formal charge 0, only two O atoms bearing $-1$) looks preferable to the all-single-bond structure (S formal charge $+2$).

*Exception — where formal-charge minimization alone is insufficient:* Modern bonding descriptions of sulfate (and phosphate, perchlorate, and similar oxoanions of period-3 central atoms) show that invoking S=O double bonds via naive $d$-orbital participation over-emphasizes covalent double-bond character; the S–O bonds are better described as strongly polarized, largely single bonds with significant ionic/electrostatic character, and the experimentally observed S–O bond length in $\mathrm{SO_4^{2-}}$ (all four bonds equal by resonance/symmetry, ~149 pm) is shorter than a "pure" single S–O bond would be, but this shortening is now attributed more to electrostatic contraction and $\pi$-type delocalization without requiring literal $d$-orbital hybrid participation (developed fully in Part 12, Hypervalency). **The correct practical takeaway for structure-drawing purposes:** minimizing formal charge is a good heuristic for choosing among candidate Lewis structures, but it is a bookkeeping tool, not proof of the literal bonding picture — Part 12 draws this distinction explicitly.

> **Common Trap**
> "Minimize formal charge" is not the same as "always maximize bond multiplicity." For period-2 central atoms (C, N, O), you cannot exceed an octet regardless of what formal-charge minimization might suggest — the octet ceiling is a harder constraint than formal-charge minimization, because no accessible low-energy orbital exists beyond the octet for these atoms (Part 1.7). Formal-charge minimization is only used to choose *among structures that already satisfy the octet/valence rules appropriate to that atom*.

### 2.6 Rules for Drawing a Correct Lewis Structure

Followed in this fixed order, these rules reliably generate the correct structure for the great majority of species:

1. **Count total valence electrons.** Sum the group-valence-electron count of every atom; for a polyatomic ion, **add** one electron per unit of negative charge, or **subtract** one electron per unit of positive charge.
2. **Identify the skeletal (connectivity) framework.** The least electronegative atom is usually central (except H, which is never central, since it can form only one bond); atoms are arranged around it, generally as symmetrically as the formula allows. **Tie-break rule:** if two candidate atoms have the same electronegativity, the atom capable of the **higher valency** (more bonds) is taken as central, since it can accommodate more surrounding atoms.
3. **Place a single bond (shared pair) between every pair of connected atoms**, and subtract these electrons from the total.
4. **Complete octets on terminal atoms first** (using the remaining electrons as lone pairs), then place any leftover electrons on the central atom.
5. **If the central atom does not yet have an octet, convert one or more terminal-atom lone pairs into an additional shared pair** (forming a double or triple bond) so that the central atom's octet is completed without violating any terminal atom's octet.
6. **Calculate formal charges** on every atom and check that they sum to the overall charge on the species.
7. **Where more than one valid structure is possible, select the structure(s) with formal charges closest to zero, with negative formal charge preferentially on the more electronegative atom(s)** — and where multiple equally valid structures exist that differ only in the position of a multiple bond or lone pair, recognize this as **resonance** (developed fully in Part 6) rather than treating one structure as uniquely "correct."
8. **Two further formal-charge preference rules, beyond simple magnitude minimization:** (i) a structure with unlike formal charges on *adjacent* (bonded) atoms is generally more favourable than one with the same-magnitude charges held far apart, because opposite charges close together provide additional electrostatic stabilization; (ii) a structure with **like formal charges on adjacent atoms is strongly disfavoured**, since it places two centres of the same-sign charge directly next to one another, which is electrostatically destabilizing.

**Worked example 2.6 — Applying the full formal-charge hierarchy to SCN⁻ (thiocyanate)**

*Problem:* Three candidate skeletal arrangements/bond patterns are possible for the linear thiocyanate ion, $\mathrm{SCN^-}$: (a) $\mathrm{[S=C=N]^-}$, (b) $\mathrm{[S-C\equiv N]^{2-}}$-type single-bond-heavy placement, (c) $\mathrm{[S\equiv C-N]}$ triple-bond-on-S placement. Which is the best representation?

*Reasoning — apply the rules in order:*

Total valence electrons $= \mathrm{S}(6)+\mathrm{C}(4)+\mathrm{N}(5)+1\ (\text{for the } -1\text{ charge}) = 16$. Two charge-balanced candidate structures survive an initial octet/electron-count check:

| Structure | S | C | N | Formal charges (S, C, N) | Sum |
|---|---|---|---|---|---|
| (a) $\mathrm{S=C=N}$, S with 2 lone pairs, N with 2 lone pairs | double bond, 2 lone pairs | 2 double bonds, no lone pair | double bond, 2 lone pairs | $(0,\ 0,\ -1)$ | $-1$ ✓ |
| (b) $\mathrm{S-C \equiv N}$, S with 3 lone pairs, N with 1 lone pair | single bond, 3 lone pairs | 1 single + 1 triple bond, no lone pair | triple bond, 1 lone pair | $(-1,\ 0,\ 0)$ | $-1$ ✓ |

(A third candidate, $\mathrm{S \equiv C - N}$ with a triple bond on S, gives formal charges $(+1, 0, -2)$ — already ruled out at the magnitude-minimization step, rule 7, since $\pm 2$ is larger than the $\pm 1$ achieved by (a) and (b).)

*Applying the hierarchy:* Structures (a) and (b) are tied on formal-charge magnitude (both have one atom at $\pm1$, the rest at $0$), so the decision falls to **placement**: rule 7 requires the negative formal charge to sit on the more electronegative atom. Nitrogen (EN $\approx 3.0$) is more electronegative than sulfur (EN $\approx 2.6$), so structure (a) — with the $-1$ formal charge on N rather than S — is the better-motivated, lower-energy structure.

*Conclusion:* $\mathrm{[S=C=N]^-}$, with formal charges S(0), C(0), N($-1$), is the dominant contributing resonance structure of thiocyanate. This matches thiocyanate's well-established coordination chemistry, in which it binds metal centres through *both* S and N depending on the metal ("ambidentate" behaviour), but with electron density concentrated more on the N end, consistent with structure (a) being the major contributor.

*Common mistake:* Stopping as soon as *a* charge-balanced structure is found, without checking whether an alternative placement of the same bond pattern lowers the energy further by putting negative formal charge on the more electronegative atom.

**Worked example 2.3 — Full structure derivation for NO₃⁻**

*Problem:* Derive the Lewis structure of the nitrate ion.

*Step 1:* Valence electrons $= \mathrm{N}(5) + 3\times\mathrm{O}(6) + 1 (\text{for the } -1 \text{ charge}) = 5+18+1=24$.

*Step 2:* N is central (less electronegative, and there is only one N to be "the center" of three O atoms).

*Step 3:* Three N–O single bonds use $3\times2=6$ electrons; $24-6=18$ remain.

*Step 4:* Distribute the remaining 18 electrons as lone pairs on the three O atoms: 3 lone pairs (6 electrons) on each O, using all 18. Each O now has an octet (2 bonding + 6 non-bonding). N, however, has only 3 bonding pairs $=6$ electrons around it — short of an octet.

*Step 5:* Convert one O lone pair into a second N–O bond (making one N=O double bond) to complete N's octet: N now has 4 bonding pairs $= 8$ electrons ✓.

*Step 6 — formal charges:* N ($V=5,N=0,B=8$): FC $=5-0-4=+1$. Doubly-bonded O ($V=6,N=4,B=4$): FC$=6-4-2=0$. Each singly-bonded O ($V=6,N=6,B=2$): FC$=6-6-1=-1$. Sum $=+1+0-1-1=-1$ ✓ matches overall charge.

*Step 7 — resonance:* Because any one of the three O atoms could equally well be the doubly-bonded one, there are **three equivalent canonical structures** (Figure 2.2), and the true structure is the resonance hybrid of all three — **not** any single one of them, and **not** a molecule that "rapidly flips" between the three (Part 6 makes this distinction rigorous). Experimentally, all three N–O bonds in $\mathrm{NO_3^-}$ are equal in length (~124 pm, intermediate between a typical N–O single bond ~140 pm and N=O double bond ~120 pm), consistent with a bond order of $4/3$ for each N–O bond — direct structural evidence for the resonance-hybrid picture over any single canonical form.

![Figure 2.2: Resonance structures of NO3-](figures/fig2_2_no3_resonance.svg)

*Common mistake:* Drawing all three N–O bonds as double bonds "to be safe" — this would put 10 electrons around N ($4\times2$ bonding), violating the octet rule, and is a frequent JEE error caused by not tracking the total valence-electron count rigorously against rule 1.

### 2.7 Exceptions to the Octet Rule — Full Structural Treatment

**(a) Electron-deficient species (incomplete octet).** Atoms with fewer than four valence electrons cannot reach eight even when all are used for bonding.

- **BeCl₂:** Be has 2 valence electrons, forms 2 bonds, 0 lone pairs → only 4 electrons around Be. Linear, $\mathrm{Cl-Be-Cl}$.
- **BF₃:** B has 3 valence electrons, forms 3 bonds → only 6 electrons around B. Trigonal planar. Because B has an empty $2p$ orbital, BF₃ is a strong Lewis acid and readily accepts a coordinate bond (Section 2.4).
- **AlCl₃:** analogous to BF₃ in the monomer, though it dimerizes to $\mathrm{Al_2Cl_6}$ via bridging chlorine coordinate bonds to satisfy Al's octet (developed in Part 12, electron-deficient/multicentre bonding).

> **Exception — electron-deficient monomers are frequently not the isolated form found in practice.** A genuinely electron-deficient species will often dimerize or polymerize specifically to relieve that deficiency, using a bridging atom's lone pair to form a coordinate bond back to the deficient centre. $\mathrm{BeH_2}$ and $\mathrm{BeCl_2}$ are monomeric, linear, $sp$-hybridized only in the gas phase at high temperature; $\mathrm{Be_2H_4}$ and $\mathrm{Be_2Cl_4}$ dimers, and eventually polymeric chain $(\mathrm{BeH_2})_n$ / $(\mathrm{BeCl_2})_n$ in the solid state, use bridging H or Cl atoms whose lone pair (or, for the 3-centre–2-electron H bridge, whose bonding electron pair) is shared with the electron-deficient Be centre so that Be's local octet is completed. $\mathrm{AlCl_3}$ behaves identically, forming $\mathrm{Al_2Cl_6}$. **This bridge-bonding structural detail is developed rigorously — including the distinct 3-centre–2-electron and 3-centre–4-electron bonding pictures — in Part 12 (Electron-Deficient Bonding)**; it is flagged here only so that "BeCl₂/AlCl₃ are electron-deficient" is not mistaken for "BeCl₂/AlCl₃ exist as isolated electron-deficient monomers under ordinary conditions," which they generally do not.
>
> A related, subtler refinement applies to BF₃ itself: although the simple Lewis picture shows an empty $2p$ orbital on B with three ordinary B–F single bonds, each F atom in fact partially donates a lone pair into that empty orbital (**back bonding**, $2p_\pi\text{–}2p_\pi$), giving the B–F bonds partial double-bond character and *reducing* — without eliminating — B's real electron deficiency.

![Figure 2.4: BF3 back bonding](figures/fig2_4_bf3_backbonding.svg)

**Figure 2.4.** One fluorine's filled $2p$ orbital (green) donates sideways into boron's empty $2p$ orbital (dashed outline), a $2p_\pi\text{–}2p_\pi$ interaction identical in geometric character to the lateral $\pi$ overlap developed fully in Part 7. This happens, to a smaller extent, at all three B–F bonds simultaneously (only one is highlighted here for clarity) — the effect is real and measurable (shortened B–F bonds relative to a pure-single-bond estimate) but partial, not a complete conversion to a fixed double bond.

B remains a genuine Lewis acid (it still readily accepts a fourth, fully dative bond from F⁻ to give $\mathrm{BF_4^-}$, Section 2.4); back bonding only means the *pure*, textbook-simple electron-deficiency picture slightly overstates how reactive/acidic B truly is, not that BF₃ should be redrawn as an ordinary complete-octet molecule. This is precisely why the Lewis-acid strength of the boron trihalides follows $\mathrm{BF_3 < BCl_3 < BBr_3 < BI_3}$ — the *opposite* order to what electronegativity of the halogen alone would predict — because back-bonding is strongest for the best-matched, most compact donor orbital (F's $2p$, matching B's $2p$ almost exactly in size) and weakens down the halogen group as the donor orbital becomes larger and more poorly matched in size to B's $2p$ orbital ($2p_\pi\text{–}3p_\pi$ for Cl, $2p_\pi\text{–}4p_\pi$ for Br, $2p_\pi\text{–}5p_\pi$ for I). Back bonding and its structural consequences are treated in full generality in Part 9.

**Worked example 2.7 — Diborane, B₂H₆: electron deficiency resolved by 3-centre–2-electron bridge bonds**

*Problem:* $\mathrm{B_2H_6}$ has the molecular formula suggesting six ordinary B–H bonds, yet boron (3 valence electrons each) and hydrogen (1 valence electron each) together supply only $2(3) + 6(1) = 12$ valence electrons — enough for only **six** ordinary two-electron bonds' worth of *electron pairs*, while the observed structure requires each B to be surrounded by **four** H atoms (tetrahedral, $sp^3$). A conventional 2-centre–2-electron Lewis structure cannot represent this molecule at all; drawing $\mathrm{H_3B{-}BH_3}$ with an ordinary B–B bond is chemically wrong (no such bond exists in diborane) and still leaves both B atoms short of an octet.

*Structure:* Diborane has **four terminal B–H bonds** (two on each B, ordinary 2-centre–2-electron bonds, ordinary line notation, using $4 \times 2 = 8$ electrons) and **two bridging B–H–B bonds**, in which a single hydrogen atom sits between the two boron atoms and bonds to *both simultaneously*. Each bridge is a genuine **three-centre–two-electron (3c–2e) bond**: only **2 electrons total** are delocalized over the three nuclei (B, H, B) of that bridge — not 2 electrons per B–H contact, which would require 4. The two bridges together therefore use only $2 \times 2 = 4$ electrons. Total: $8+4=12$ electrons ✓, matching the valence-electron count exactly, with **no ordinary B–B bond anywhere in the structure**.

```
        H   H   H
         \  |  /
          B---B
         /  |  \
        H   H   H
```
*(schematic only — the two centre hydrogens are bridging, each simultaneously bonded to both B atoms via a 3c–2e bond; the four outer H atoms are ordinary terminal 2c–2e bonds, two per boron)*

![Figure 2.3: Diborane bridge bonding](figures/fig2_3_diborane_bridge_bonds.svg)

**Figure 2.3.** The four terminal B–H bonds (black) are ordinary 2c–2e bonds; the two bridging B–H–B linkages (red, drawn as curved "banana bonds") are each a single 3c–2e bond in which 2 electrons are delocalized over three nuclei simultaneously — not two separate 2c–2e bonds, which the total electron count (12 valence electrons) could not support.

Each boron is tetrahedrally ($sp^3$) surrounded by four H atoms (two terminal, two bridging) and, through participation in the delocalized bridge bonds, achieves a locally complete octet — even though the *electron count* available is insufficient to have built that same connectivity from ordinary 2-centre bonds alone. This is exactly what "electron-deficient" means for diborane: **not** that any atom is left with an incomplete octet in the final structure, but that the total electron supply is insufficient to construct the observed B–H connectivity using only ordinary two-centre bonds, which is why the non-classical 3c–2e bridge bond is *required*, not optional.

*Bond-length consequence (verifiable structural signature):* the bridging B–H bonds are experimentally longer and weaker than the terminal B–H bonds, consistent with each bridging bond's electron pair being shared over three nuclei rather than concentrated between two — direct structural evidence for the 3c–2e picture over any ordinary-bond alternative.

*Scope note:* this Part gives the 3c–2e bridge-bond picture in the depth needed to resolve diborane's octet/electron-deficiency status correctly. The full molecular-orbital treatment of 3-centre bonding (constructing the bonding/non-bonding/antibonding combination explicitly), the related $\mathrm{Al_2Cl_6}$ and $\mathrm{Be}$-halide bridging structures introduced qualitatively in the Exception box above, and general electron-counting rules for multicentre boranes are developed in full in **Part 12 (Electron-Deficient Bonding)** — nothing about the present treatment is provisional or to be revised there, it is simply extended to more complex cages and clusters.

*Common mistake:* Describing diborane as "two BH₃ units joined by a B–B bond," or drawing six ordinary 2c–2e B–H bonds without acknowledging the bridge — both misrepresent the actual bonding and both fail a valence-electron count check (six ordinary bonds would require 12 electrons *for the terminal+naive-bridge bonds combined only if each bridge were also ordinary*, which over-draws the true connectivity and is inconsistent with the experimentally distinct terminal/bridging B–H bond lengths).

**(b) Expanded-octet (hypervalent) species.** Period-3-and-beyond central atoms can be surrounded by more than eight electrons.

- **PCl₅:** P contributes 5 valence electrons, forms 5 P–Cl bonds → 10 electrons around P.
- **SF₆:** S forms 6 S–F bonds → 12 electrons around S.
- **ClF₃, XeF₂, XeF₄, IF₅, IF₇** — all expanded-octet species whose shapes are developed fully with lone-pair placement in Part 9 (VSEPR); their existence is noted here only to establish that the octet rule does not apply to these central atoms, and the modern caveat about *why* expansion is possible (charge-driven orbital contraction rather than routine literal $d$-orbital hybridization) is deferred to Part 12, per the "Hypervalency" treatment required there. Electron counts around the central atom, verified directly for each: PCl₅ (5 bonds → 10 e⁻), SF₆ (6 bonds → 12 e⁻), ClF₃ (3 bonds + 2 lone pairs → 6 + 4 = 10 e⁻), IF₅ (5 bonds + 1 lone pair → 10+2=12 e⁻), IF₇ (7 bonds → 14 e⁻).

> **Worked example 2.4 — Why does NF₅ not exist, but PF₅ does?**
> *Problem:* Nitrogen and phosphorus are both Group 15 elements, yet $\mathrm{PF_5}$ is a well-known, stable compound while $\mathrm{NF_5}$ does not exist under any ordinary conditions. Explain.
> *Reasoning:* Both N and P have five valence electrons and, in principle, five unpaired electrons could be made available for bonding by promoting one electron. The difference is not in *electron count* but in **orbital availability**. Nitrogen is a period-2 element: its valence shell is $n=2$, which contains only $2s$ and $2p$ orbitals — there is no $2d$ subshell at all, at any energy, for nitrogen to draw on. Phosphorus is a period-3 element, whose valence shell is $n=3$; the $3d$ subshell, while empty in the ground state, becomes energetically accessible once P is bonded to strongly electronegative atoms (via the charge-induced orbital-contraction mechanism detailed in Part 12), permitting expansion beyond an octet.
> *Conclusion:* $\mathrm{NF_5}$ cannot exist because there is no physically available orbital set for N to expand into — this is an absolute prohibition rooted in the periodic table's shell structure, not a matter of degree. This is the single cleanest illustration available that expanded octets are fundamentally restricted to period 3 and beyond.
> *Common mistake:* Attributing the non-existence of NF₅ to "nitrogen's small size" alone. Size is a contributing factor in some hypervalency boundary cases (see next example) but is not the primary reason here — the primary reason is the complete absence of an $n=2$ $d$-subshell, a hard quantum-mechanical constraint independent of size.

> **Worked example 2.5 — Why does IF₇ exist, but ClF₇ and BrF₇ do not?**
> *Problem:* Iodine forms the heptafluoride $\mathrm{IF_7}$, yet chlorine and bromine — also period-3-and-beyond halogens with accessible $d$ orbitals — form only pentafluorides ($\mathrm{ClF_5}$, $\mathrm{BrF_5}$) at most, never heptafluorides. Why?
> *Reasoning:* Unlike the N-vs-P case above, Cl and Br **do** have accessible $d$ orbitals in principle (Cl is period 3, Br is period 4), so orbital availability is not the limiting factor here. The limitation is **steric** — a purely geometric packing constraint: seven fluorine atoms must be packed around the central halogen without excessive F···F repulsion. Iodine, being the largest of the halogens, has a large enough covalent/ionic radius to accommodate seven F atoms at a tolerable F–I–F separation (giving the pentagonal-bipyramidal geometry of Part 9). Chlorine and bromine are too small to accommodate seven fluorine atoms without prohibitive non-bonded repulsion between adjacent F atoms.
> *Conclusion:* Two genuinely distinct constraints govern expanded-octet formation, and JEE Advanced regularly tests the ability to distinguish them: **(i) electronic accessibility** of an appropriate empty orbital set (the N-vs-P boundary, a period-based, essentially absolute constraint) and **(ii) steric/size accommodation** of the required number of surrounding atoms (the Cl/Br-vs-I boundary, a size-based, comparative constraint). A structure can fail for either reason independently, and correctly identifying *which* reason applies is what distinguishes a strong answer from a superficial "it just doesn't exist" response.

**(c) Odd-electron (free-radical) species.** A molecule or ion with an odd total valence-electron count *cannot* have every electron paired.

- **NO:** valence electrons $= 5+6=11$ (odd). Best Lewis structure: $\mathrm{:N=O\cdot}$ with the unpaired electron formally on N (consistent with NO's known reactivity as a radical) — total: N has 1 lone pair + double bond (2+4=6) + 1 unpaired electron $=7$; O has 2 lone pairs + double bond $=4+4=8$. NO is paramagnetic (one unpaired electron), confirmed by both simple electron counting and MOT (Part 10.13).
- **NO₂:** valence electrons $=5+12=17$ (odd); N carries the unpaired electron, consistent with NO₂'s tendency to dimerize (N–N bond formation via the two odd electrons pairing up) to $\mathrm{N_2O_4}$.
- **ClO₂:** valence electrons $=7+12=19$ (odd); a well-known free radical, industrially used precisely because of its radical reactivity.

**General rule:** every odd-electron species is necessarily paramagnetic, because an odd total electron count makes it structurally impossible to pair every electron — at least one electron must remain unpaired regardless of how the Lewis structure is drawn, and an unpaired electron is precisely the condition for paramagnetism. This is a direct, unavoidable consequence of parity (odd vs. even electron count), not an empirical correlation that happens to hold for the examples above.

> **Exception (within the exception)**
> Odd-electron species are one of the few genuine, unavoidable failures of the octet rule — there is no way to redraw NO, NO₂, or ClO₂ with every atom obeying an octet, because the total electron count is fundamentally odd. This is different in character from the electron-deficient and expanded-octet cases above, which are failures of the *rule's applicability* to certain atoms, not arithmetic impossibilities.

### 2.8 Selecting the Most Reasonable Lewis Structure — Summary Procedure

When more than one structure satisfies the basic valence-electron count:

1. Prefer the structure that **satisfies the octet rule for every atom that is capable of an octet** (i.e., period-2 atoms), reserving expanded octets only for period-3-and-beyond central atoms where a valid octet structure genuinely cannot be drawn without leaving formal charges unreasonably large.
2. Among remaining candidates, prefer **minimum formal charges overall** (as close to zero as possible on each atom).
3. Where formal charge cannot be reduced to zero everywhere, place **negative formal charge on the more electronegative atom(s)** and positive formal charge on the less electronegative atom(s) — this matches the real direction of electron density polarization and is the physically better-motivated (lower-energy) structure. Additionally, prefer placing unlike formal charges on adjacent (bonded) atoms over separating them, and strongly avoid any structure that places like formal charges on adjacent atoms (Section 2.6, rule 8; Worked Example 2.6).
4. If two or more structures are equally valid by criteria 1–3 and differ only in which equivalent atom bears a double bond, they are **resonance structures**, not competing candidates — all must be drawn, and the true structure is their hybrid (Part 6).

### 2.9 Limitations of Lewis Structures

Lewis structures, for all their utility, have well-defined limitations that more advanced theories are needed to resolve:

- They give **no information about molecular shape** — $\mathrm{CH_4}$ and a hypothetical square-planar $\mathrm{CH_4}$ have identical Lewis structures; shape requires VSEPR (Part 9).
- They treat bonds as localized, two-centre, two-electron entities, which **fails for delocalized/resonance-stabilized systems** (Part 6) and for genuinely multicentre bonds such as the 3-centre–2-electron bridge bonds in $\mathrm{B_2H_6}$ (Part 12).
- They give **no quantitative account of relative bond strength, bond order in fractional cases, or magnetic behaviour** — $\mathrm{O_2}$'s paramagnetism (Section 1.7) is invisible to a Lewis structure and requires MOT (Part 10).
- Formal charge, which Lewis structures rely on for structure-selection, is a **bookkeeping convention**, not a measurement of real charge distribution (Section 2.5) — real (partial) charges are always smaller in magnitude and are governed by actual electronegativity differences, not by the equal-sharing assumption formal charge makes.

### 2.10 Structure Verification Panel — Every Required Species

The species below were named in earlier sections but not all were given an explicit, checkable structure. This panel corrects that: every species has its valence-electron count, bonding skeleton, lone pairs, atom-wise formal charges, checked charge sum, and octet status shown explicitly. (CO, NO₃⁻, and SCN⁻ are fully derived above as Worked Examples 2.1, 2.3, 2.6 and are not repeated here; B₂H₆ is fully derived as Worked Example 2.7 and is not repeated here.)

**Simple molecules (duplet/octet satisfied, no exceptions):**

| Species | Valence e⁻ | Skeleton | Lone pairs | Formal charges | ΣFC | Octet/duplet status |
|---|---:|---|---|---|---:|---|
| $\mathrm{H_2}$ | 2 | H–H | none | H: 0, H: 0 | 0 | Both H: duplet (2e) ✓ |
| $\mathrm{Cl_2}$ | 14 | Cl–Cl | 3 per Cl | Cl: 0, Cl: 0 | 0 | Both octet (8e) ✓ |
| $\mathrm{O_2}$ | 12 | O=O | 2 per O | O: 0, O: 0 | 0 | Both octet (8e) ✓ — **but see Common Trap below** |
| $\mathrm{N_2}$ | 10 | N≡N | 1 per N | N: 0, N: 0 | 0 | Both octet (8e) ✓ |
| $\mathrm{HCl}$ | 8 | H–Cl | 3 on Cl | H: 0, Cl: 0 | 0 | H duplet, Cl octet ✓ |
| $\mathrm{H_2O}$ | 8 | H–O–H | 2 on O | O: 0, H: 0 (×2) | 0 | O octet, H duplet (×2) ✓ |
| $\mathrm{NH_3}$ | 8 | N bonded to 3 H | 1 on N | N: 0, H: 0 (×3) | 0 | N octet, H duplet (×3) ✓ |
| $\mathrm{CH_4}$ | 8 | C bonded to 4 H | none | C: 0, H: 0 (×4) | 0 | C octet, H duplet (×4) ✓ |

> **Common Trap** — $\mathrm{O_2}$'s Lewis structure ($\mathrm{O=O}$, all electrons paired, both O with octet and FC $=0$) is entirely self-consistent as a piece of electron bookkeeping, and is not "wrong" in the sense of violating any counting rule. It is nonetheless an **incomplete physical description**: this structure predicts a diamagnetic molecule (no unpaired electrons anywhere), while $\mathrm{O_2}$ is experimentally paramagnetic. This is the standing example (first raised in §1.7) of a case where a perfectly valid Lewis structure still fails to capture real molecular behaviour — resolved only by molecular orbital theory in Part 10.

**Coordinate-bonded cations:**

| Species | Valence e⁻ | Skeleton | Lone pairs | Formal charges | ΣFC | Overall charge | Octet status |
|---|---:|---|---|---|---:|---:|---|
| $\mathrm{NH_4^+}$ | 8 | N bonded to 4 H (Figure 2.1) | none | N: $+1$, H: 0 (×4) | $+1$ | $+1$ ✓ | N octet ✓ |
| $\mathrm{H_3O^+}$ | 8 | O bonded to 3 H | 1 on O | O: $+1$, H: 0 (×3) | $+1$ | $+1$ ✓ | O octet ✓ |

**Carbon/nitrogen-oxide family (extending the CO and NO₃⁻ worked examples):**

| Species | Valence e⁻ | Skeleton | Lone pairs | Formal charges | ΣFC | Overall charge | Octet status |
|---|---:|---|---|---|---:|---:|---|
| $\mathrm{CO_2}$ | 16 | O=C=O | 2 per O, none on C | C: 0, O: 0 (×2) | 0 | 0 ✓ | All octet ✓ |
| $\mathrm{CN^-}$ | 10 | $[\mathrm{C{\equiv}N}]^-$ | 1 on C, 1 on N | C: $-1$, N: 0 | $-1$ | $-1$ ✓ | Both octet ✓ |
| $\mathrm{NO}$ | 11 (odd) | N=O, unpaired e⁻ on N | 1 pair on N, 2 on O | N: 0, O: 0 | 0 | 0 ✓ | N: 7e⁻ (odd-electron exception, §2.7c); O octet ✓ |
| $\mathrm{NO_2}$ | 17 (odd) | O=N(·)–O (resonance) | 2 on double-bond O, 3 on single-bond O | N: $+1$, O(=): 0, O(–): $-1$ | 0 | 0 ✓ | N: 7e⁻ (odd-electron exception); both O octet ✓ |
| $\mathrm{NO_2^+}$ | 16 | O=N=O (linear, isoelectronic with CO₂) | 2 per O | N: $+1$, O: 0 (×2) | $+1$ | $+1$ ✓ | All octet ✓ |
| $\mathrm{NO_2^-}$ | 18 | O=N–O (bent, resonance) | 1 on N, 2 on double-bond O, 3 on single-bond O | N: 0, O(=): 0, O(–): $-1$ | $-1$ | $-1$ ✓ | All octet ✓ |

> **Exception worth flagging explicitly (CN⁻):** the formal-charge preference rule (§2.6, rule 7) would, taken alone, suggest placing the $-1$ formal charge on N rather than C, since N is more electronegative. But redistributing the two non-bonding lone pairs to put both on N (rather than one on each atom) leaves **C with only 6 electrons — an incomplete octet** — which is not permissible for a period-2 atom with no other stabilizing exception at play (§1.7). The octet-completion requirement is a **harder constraint** than the electronegativity-placement heuristic, and overrides it here: this is exactly the point already made in §2.6's rule ordering (octet satisfaction is checked *before* formal-charge placement is used as a tiebreaker), and CN⁻ is the cleanest worked illustration of that ordering actually mattering.

**Electron-deficient (incomplete-octet) species:**

| Species | Valence e⁻ | Skeleton | Lone pairs | Formal charges | ΣFC | Electrons around central atom |
|---|---:|---|---|---|---:|---|
| $\mathrm{BF_3}$ | 24 | B bonded to 3 F | 3 per F, none on B | B: 0, F: 0 (×3) | 0 | 6 (incomplete octet — see back-bonding refinement, §2.7a) |
| $\mathrm{BeCl_2}$ | 16 | Cl–Be–Cl (linear) | 3 per Cl, none on Be | Be: 0, Cl: 0 (×2) | 0 | 4 (incomplete octet) |
| $\mathrm{AlCl_3}$ | 24 | Al bonded to 3 Cl | 3 per Cl, none on Al | Al: 0, Cl: 0 (×3) | 0 | 6 (incomplete octet; dimerizes to $\mathrm{Al_2Cl_6}$, §2.7a) |

**Coordinate-bond-completed anion:**

| Species | Valence e⁻ | Skeleton | Lone pairs | Formal charges | ΣFC | Overall charge | Electrons around B |
|---|---:|---|---|---|---:|---:|---|
| $\mathrm{BF_4^-}$ | 32 | B bonded to 4 F | 3 per F, none on B | B: $-1$, F: 0 (×4) | $-1$ | $-1$ ✓ | 8 (octet now complete via the coordinate bond from F⁻, §2.4) |

**Expanded-octet (hypervalent) species — period 3 and beyond:**

| Species | Valence e⁻ | Skeleton | Lone pairs on central atom | Formal charges | ΣFC | Electrons around central atom |
|---|---:|---|---|---|---:|---|
| $\mathrm{PCl_5}$ | 40 | P bonded to 5 Cl | none | P: 0, Cl: 0 (×5) | 0 | 10 |
| $\mathrm{SF_4}$ | 34 | S bonded to 4 F | 1 | S: 0, F: 0 (×4) | 0 | 10 |
| $\mathrm{SF_6}$ | 48 | S bonded to 6 F | none | S: 0, F: 0 (×6) | 0 | 12 |
| $\mathrm{ClF_3}$ | 28 | Cl bonded to 3 F | 2 | Cl: 0, F: 0 (×3) | 0 | 10 |
| $\mathrm{XeF_2}$ | 22 | F–Xe–F (linear) | 3 | Xe: 0, F: 0 (×2) | 0 | 10 |
| $\mathrm{XeF_4}$ | 36 | Xe bonded to 4 F | 2 | Xe: 0, F: 0 (×4) | 0 | 12 |
| $\mathrm{IF_5}$ | 42 | I bonded to 5 F | 1 | I: 0, F: 0 (×5) | 0 | 12 |
| $\mathrm{IF_7}$ | 56 | I bonded to 7 F | none | I: 0, F: 0 (×7) | 0 | 14 |

All electron counts above are around the **central atom only** — not the total molecular valence-electron count shown in the second column, which is a distinct quantity (total molecular valence electrons includes every terminal-atom electron too; the "electrons around central atom" figure is just the central atom's own local bonding+lone-pair count, which is what determines whether the octet rule is satisfied or exceeded at that atom). Conflating these two counts is a frequent source of error and is worth checking explicitly on every hypervalent species: e.g. $\mathrm{SF_6}$ has 48 total molecular valence electrons, but only 12 of them are "around" S in the sense relevant to octet-counting.

> **Exception — not every species that can be formally drawn with an expanded octet is chemically real or stable.** Nothing about correctly balancing an electron count and drawing a symmetric structure guarantees the compound exists — $\mathrm{NF_5}$, discussed in Worked Example 2.4, is formally impossible to draw at all (no accessible orbital), which is different from, say, a hypothetical $\mathrm{ClF_7}$, which *can* be drawn on paper with a balanced electron count but does not exist because the central Cl atom is sterically too small to accommodate seven F atoms (Worked Example 2.5). A correct, charge-balanced Lewis structure is a **necessary** check, not a **sufficient** one, for a species' real existence — stability additionally depends on steric accommodation, thermodynamic favourability, and (for the heavier hypervalent species) the specific nature of the bonding beyond the simple octet-expansion picture, which is why Part 12 revisits hypervalency with the multicentre/delocalized-bonding model rather than resting on formal electron counting alone.

### Important Conceptual Distinctions (Part 1–2)

| Distinction | Clarification |
|---|---|
| **Formal charge vs. oxidation number** | Formal charge assumes bonding electrons are shared *exactly equally* regardless of real electronegativity; oxidation number assumes bonding electrons belong *entirely* to the more electronegative atom. They are opposite bookkeeping extremes of the same electron pair and will generally give different numbers for the same atom in the same molecule. |
| **Formal charge vs. actual (partial) charge** | Actual partial charge, measurable via dipole moment and other experimental methods (Part 5), reflects the *real* unequal sharing driven by electronegativity difference, and its magnitude is almost always smaller than a full formal-charge unit for typical covalent bonds. |
| **Coordinate bond formation vs. the nature of the bond after formation** | The *origin* of the electron pair (one atom vs. two atoms contributing) is a historical/formation-mechanism distinction only; the *resulting bond* is physically identical to an ordinary covalent bond of the same order (Section 2.4, NH₄⁺ example). |
| **Octet rule vs. duplet rule** | Only H (and He) are stable with 2 valence electrons; all other main-group atoms discussed in this Part follow the 8-electron octet target where applicable. |

### Part 2 Summary

- Kossel's and Lewis's theories are two mechanisms (transfer vs. sharing) serving the same underlying goal: valence electron rearrangement toward a low-energy, noble-gas-like configuration.
- A coordinate bond differs from an ordinary covalent bond only in electron-pair origin, never in the resulting bond's physical character.
- Formal charge, $FC = V - N - B/2$, is the essential quantitative tool for selecting among candidate Lewis structures and for explaining otherwise-puzzling properties (e.g., CO's small dipole moment); it must not be confused with oxidation number or real partial charge.
- The octet rule fails in three systematically distinct, well-characterized ways — electron deficiency, expanded octets, and odd-electron count — each of which is developed into full structural and theoretical treatment later in this chapter (Parts 8, 9, 10, 12).

---

## Mandatory Coverage Audit — Source-to-Content Matrix (Parts 1–2)

**Inspection method, stated plainly:** `CHEMICAL_BONDING.pdf` and `Chemical_Bonding_Kohinoor_.pdf` have genuine, machine-extractable text layers (Kohinoor confirmed on this pass — it is a digitally produced document, not a scan, despite stylized fonts) and were read as text directly. `cbvj.pdf` (177 pp.) and all twelve `Chemical Bonding (E)/1–12.pdf` files (245 pp.) are true image scans of handwriting with no text layer. Every one of these 422 pages was rasterized and OCR'd in full this session; every page was then checked for topic relevance from its OCR output, and every page flagged as relevant was individually re-examined against its OCR text before being written into the notes above. Handwriting OCR remains imperfect — where a flagged page's content could not be resolved with confidence, it is marked `UNCLEAR` below rather than guessed at, per your instruction.

| Source PDF | Pages inspected for Parts 1–2 | Relevant topics found | Examples/figures found | Exact destination in notes | Status |
|---|---:|---|---|---|---|
| `CHEMICAL_BONDING.pdf` | Full text, §3.1–3.4 (pp. correspond to source §3.1–§3.4) | Bond formation/energy, types of bonds, Ketelaar triangle, Lewis octet theory, Sidgwick–Powell | NaCl/CaCl₂ ionic formation, Cl₂/CCl₄/NH₃ covalent formation, NH₄⁺/BF₃ coordinate bond, BeF₂/BF₃ incomplete octet, PF₅ expanded octet, NO/ClO₂/O₂ odd-electron & paramagnetism | §1.1–1.7, §2.1–2.2, §2.7 | INCORPORATED |
| `CB_Guha.pdf` | pp. 1–20 sampled | Identical opening (Ketelaar triangle, watermark) to `CHEMICAL_BONDING.pdf` | none beyond duplicate | — | DUPLICATE — already covered via `CHEMICAL_BONDING.pdf` |
| `Chemical_Bonding_Kohinoor_.pdf` | **All 261 extracted text-pages searched by keyword; pp. 3, 4, 12, 17, 110, 135, 136 opened and read in full** | p.3–4: octet/duplet definitions, incomplete/expanded octet, odd-e⁻ molecules, pseudo-inert-gas vs inert-gas configuration table; p.12: Lewis-structure electron-counting method; p.17: central-atom selection rule (EN tie-break → max valency); p.110: BF₃ Lewis-acidity order via back bonding, N(CH₃)₃ vs N(SiH₃)₃; pp.135–136: formal charge definition and four structure-selection rules, worked on SCN⁻/OCN⁻-type species | Na⁺/Cu⁺ pseudo-noble-gas comparison; BF₃>BCl₃>BBr₃>BI₃ Lewis acidity order; SCN⁻ formal-charge worked case | §2.1 (pseudo-noble-gas subsection), §2.6 rule 2 (tie-break), §2.6 rule 8 + Worked Example 2.6, §2.7(a) (back-bonding note) | INCORPORATED |
| `Chemical_Bonding_Kohinoor_.pdf`, remainder (~253 pages not flagged by keyword search) | Searched by keyword only, not opened individually | Keyword search (octet, lewis, formal charge, coordinate, kossel, valence, expanded, odd e⁻, hypervalent, deficient, bond energy/length, dissociation, radical, incomplete octet) returned no further hits | — | — | IRRELEVANT TO PARTS 1–2 *(by keyword search only — see limitation note below)* |
| `cbvj.pdf`, p. 1 | p. 1 | Bond formation, potential-energy curve, attraction/repulsion, bond-formation point, exothermic formation/endothermic dissociation | HClO<HClO₂<HClO₃<HClO₄ thermal-stability aside (not used — belongs to a later oxoacid-comparison part) | Figure 1.1 caption; §1.2 "Common Trap" box | INCORPORATED |
| `cbvj.pdf`, pp. 2–15 | pp. 2–15 | Dipole–dipole, London dispersion, H-bonding, clathrates | Ar·6H₂O etc. | — | IRRELEVANT TO PARTS 1–2 (confirmed Part 11 material) |
| `cbvj.pdf`, pp. 16–177 | **All rasterized and OCR'd; OCR text keyword-searched in full** | pp. 38, 50, 57–59: back bonding / bridge bonding in BF₃, AlCl₃/Al₂Cl₆, BeH₂/BeCl₂ dimers (3c–2e, 3c–4e bonds); pp. 63, 66: odd-electron molecules NO, NO₂, ClO₂, paramagnetism generalization; p. 83: oxoacid formation reactions; p. 87: XeFₙ hydrolysis; p. 100: pseudo-inert-gas configuration (Zn²⁺/Cd²⁺/Hg²⁺, ZnCl₂<CdCl₂<HgCl₂ covalent-character order — corroborates the Kohinoor p.4 finding independently); p. 172: fullerene/graphite/diamond bonding, dangling bonds | Bridge-bond electron-deficient dimer structures; pseudo-noble-gas covalent-character order (cross-confirms Kohinoor) | §2.7(a) bridge-bonding cross-reference note (pp.38,50,57–59); §2.7(c) paramagnetism generalization (pp.63,66); §2.1 pseudo-noble-gas subsection (p.100, corroborating) | INCORPORATED (pp.38,50,57–59,63,66,100); IRRELEVANT TO PARTS 1–2 — belongs to later Parts as noted (pp.83 → oxoacid comparison part; p.87 → Xe chemistry, Part 9/13; p.172 → allotrope/solid-state bonding, outside current 18-part scope) |
| `Chemical Bonding (E)/1.pdf` | **All 11 pages rasterized, OCR'd, and checked** | pp. 1–2: attraction/repulsion, chemical bond definition, covalent bond as 2c–2e sharing | — | §1.1, §2.2 (already-consistent confirmation, no new content) | INCORPORATED (confirmatory only) |
| `Chemical Bonding (E)/2.pdf` | **All 21 pages rasterized, OCR'd, and checked** | p.13: types of covalent bond overlap (σ/π/δ) | — | Belongs to Part 7/8 (Valence Bond Theory, Sigma/Pi bonds) | IRRELEVANT TO PARTS 1–2 |
| `Chemical Bonding (E)/3.pdf` | **All 16 pages rasterized, OCR'd, and checked** | p.13: expanded octet/hypervalent/hypovalent terminology (confirmatory only, no new fact beyond existing §2.7(b)) | — | §2.7(b) (confirmatory) | INCORPORATED (confirmatory only) |
| `Chemical Bonding (E)/4.pdf` | **All 13 pages rasterized and OCR'd** | No Part 1–2 keyword hits | — | — | IRRELEVANT TO PARTS 1–2 |
| `Chemical Bonding (E)/5.pdf` | **All 15 pages rasterized and OCR'd** | pp.9–12: VSEPR/steric-number method (Sidgwick–Powell-adjacent but developed as full VSEPR, not basic Lewis) | — | Belongs to Part 9 | IRRELEVANT TO PARTS 1–2 |
| `Chemical Bonding (E)/6.pdf` | **All 24 pages rasterized and OCR'd** | No Part 1–2 keyword hits | — | — | IRRELEVANT TO PARTS 1–2 |
| `Chemical Bonding (E)/7.pdf` | **All 19 pages rasterized and OCR'd** | No Part 1–2 keyword hits | — | — | IRRELEVANT TO PARTS 1–2 |
| `Chemical Bonding (E)/8.pdf` | **All 24 pages rasterized and OCR'd** | p.10: bond-length keyword hit only, context = bond-parameter comparison table | — | Belongs to Part 5 (Covalent Bond Parameters) | IRRELEVANT TO PARTS 1–2 |
| `Chemical Bonding (E)/9.pdf` | **All 20 pages rasterized and OCR'd** | No Part 1–2 keyword hits | — | — | IRRELEVANT TO PARTS 1–2 |
| `Chemical Bonding (E)/10.pdf` | **All 19 pages rasterized and OCR'd** | No Part 1–2 keyword hits | — | — | IRRELEVANT TO PARTS 1–2 |
| `Chemical Bonding (E)/11.pdf` | **All 34 pages rasterized and OCR'd** | No Part 1–2 keyword hits | — | — | IRRELEVANT TO PARTS 1–2 |
| `Chemical Bonding (E)/12.pdf` | **All 29 pages rasterized and OCR'd** | p.6: odd-electron species (confirmatory only); p.27: bond-length (Part 5 context) | — | §2.7(c) (confirmatory) | INCORPORATED (confirmatory only) |
| `Topic Wise Questions/covalencyandlewisoctetstructure.pdf` | Full 7 pages, text-native, read directly | NF₅ non-existence (no accessible d-orbital), IF₇-vs-ClF₇/BrF₇ boundary (steric limit), electron-deficiency, octet-rule exceptions, energy release on bond formation | Used as the basis for two newly written worked examples | Worked Examples 2.4 and 2.5 (rewritten originally, not pasted from source) | INCORPORATED |
| `Topic Wise Questions/basicchemicalbondinglevel0.pdf` | Full 65 pages, text-native; qq.1–24 read in full, remainder scanned by heading | qq.1–11, 19–24: ionic bond formation conditions, energy release; qq.5–18: lattice energy comparisons | Confirms existing §2.1 framing; no new Part 1–2 fact beyond what was already present | §2.1 (confirmatory) | INCORPORATED (confirmatory only); remainder (lattice-energy questions) → IRRELEVANT TO PARTS 1–2, belongs to Part 3 |
| `Topic Wise Questions/Overlappingtheorylevel0.pdf`, `level0vseprt.pdf`, `planarandnonplanarlevel0.pdf` | Headings/opening text-extracted | Orbital overlap types, VSEPR, planar/non-planar geometry | — | Belong to Parts 7, 9 | IRRELEVANT TO PARTS 1–2 |

**Explicit limitation on the "IRRELEVANT" calls for `Kohinoor` pp. not individually opened:** the ~253 unflagged Kohinoor pages were screened by keyword match against the extracted text only, not opened and read individually one-by-one. Keyword search on clean, genuinely-extracted text (unlike OCR on handwriting) is a reliable method for *locating* relevant material — a real word match is a real word match, not a probabilistic guess — so I am confident this did not miss Part 1–2 content that uses standard terminology. It could in principle miss a passage that discusses, say, formal charge or octet exceptions without ever using those words. I am flagging this explicitly rather than silently treating full-page-by-page reading and keyword search as equivalent.

## Exact Additions Made After the Missing-Source Review

1. **Pseudo-noble-gas configuration** (new subsection in §2.1) — Zn²⁺/Cd²⁺/Cu⁺/Hg²⁺ vs. true noble-gas Na⁺/Cl⁻; explanation via d-shell shielding; ZnCl₂<CdCl₂<HgCl₂ covalent-character consequence. *Source: Kohinoor p.4, independently corroborated by cbvj p.100.*
2. **Central-atom selection tie-break rule** (added to §2.6, rule 2) — when two candidate central atoms have equal electronegativity, the one with higher valency is chosen. *Source: Kohinoor p.17.*
3. **Two additional formal-charge structure-selection rules** (added to §2.6 as rule 8, and to the §2.8 summary) — preference for unlike adjacent charges over separated charges; strong disfavouring of like adjacent charges — plus a full new **Worked Example 2.6** applying the complete rule hierarchy to SCN⁻. *Source: Kohinoor pp.135–136.*
4. **Bridge-bonding cross-reference note** (added to §2.7(a)) — flags that BeCl₂/AlCl₃/BeH₂ do not persist as isolated electron-deficient monomers but dimerize/polymerize via 3-centre bonds, with full treatment correctly deferred to Part 12. *Source: cbvj pp.38, 50, 57–59.*
5. **Back-bonding note on BF₃ Lewis acidity** (added to §2.7(a)) — BF₃<BCl₃<BBr₃<BI₃ order and the 2p–np orbital-mismatch explanation. *Source: Kohinoor p.110.*
6. **Explicit paramagnetism generalization** for odd-electron species (added to §2.7(c)) — parity-based, not merely empirical. *Source: cbvj pp.63, 66.*
7. **Worked Example 2.4** (NF₅ non-existence, period-2 vs period-3 orbital accessibility) — newly written, grounded in `basicchemicalbondinglevel0.pdf` Q4/Q6.
8. **Worked Example 2.5** (IF₇ vs ClF₇/BrF₇, steric vs electronic limits on octet expansion) — newly written, grounded in `covalencyandlewisoctetstructure.pdf` Q30.
9. **Electron counts made explicit** for every expanded-octet example in §2.7(b) (PCl₅=10, SF₆=12, ClF₃=10, IF₅=12, IF₇=14 electrons around the central atom) — independently verified by direct counting, not sourced from any single PDF, to correct the earlier draft's incompleteness on this point.

## Final Chemistry Validation Report

Every Lewis structure and worked example above was independently re-checked against the following criteria immediately before this submission:

| Check | Result |
|---|---|
| Total valence-electron counts (all worked examples: CO, SO₄²⁻, NO₃⁻, SCN⁻) | Verified arithmetically; shown explicitly in each worked example |
| Octet/duplet completion on every atom | Verified for H₂, Cl₂, CCl₄, NH₃, NH₄⁺, CO, NO₃⁻, SCN⁻; exceptions (BeCl₂, BF₃, PCl₅, SF₆, NO, NO₂, ClO₂) explicitly identified and classified by type |
| Formal charges — atom-by-atom and summed against overall charge | Verified for CO ($-1,+1$; Σ=0), SO₄²⁻ (both candidate structures; Σ=$-2$ in both), NO₃⁻ ($+1,0,0,-1,-1$... i.e. N:+1, one O:0, two O:−1; Σ=−1), SCN⁻ (both candidate structures; Σ=$-1$ in both) |
| Overall ionic charge shown correctly in brackets | NH₄⁺, NO₃⁻, SO₄²⁻, SCN⁻ all shown with correct bracket/charge notation |
| Lone pairs shown explicitly | Shown in every worked Lewis structure and in Figures 2.1–2.2 |
| Bond multiplicities | Single/double/triple bonds verified against total electron count in every example |
| Coordinate-bond representation | NH₄⁺ and NH₃·BF₃ shown with correct donor/acceptor framing; explicitly stated that the resulting bond is physically identical to an ordinary covalent bond post-formation |
| Resonance notation | NO₃⁻ shown with three canonical structures and a double-headed resonance arrow (↔), explicitly *not* an equilibrium arrow; the "hybrid, not oscillation" caveat is stated explicitly |
| Terminology (formal charge vs. oxidation number vs. partial charge; coordinate vs. ordinary covalent bond; octet vs. duplet) | Addressed explicitly in the Important Conceptual Distinctions table |
| Mathematical notation | KaTeX-compatible throughout; units, subscripts, superscripts, and charges checked |
| Diagram labels | Figures 1.1, 2.1, 2.2 captioned with figure numbers and explanatory text |
| JEE Advanced depth | Insight/Trap/Exception boxes present in both Parts; two new fully-worked boundary-case examples (2.4, 2.5) added specifically to raise depth beyond NCERT level |
| Coverage of all relevant uploaded-source examples located in this pass | All examples listed in "Exact Additions" above are incorporated; no located Part 1–2-relevant example was left out |

No chemistry errors were identified in the pre-existing Part 1–2 content during this re-check; the corrections made were additions (new content found) and one presentational cleanup (Worked Example 2.6's derivation, which originally contained a visible false start and has been rewritten as a clean table-based derivation).

---

*End of Parts 1–2, revised. Awaiting instruction before Part 3.*

## Part 3 — Ionic Bonding and Energetics

### 3.1 Formation of Ionic Compounds — Conditions and the Redox Framing

Ionic bond formation is, at its core, a **redox process**: the electropositive atom is oxidized (loses electrons) and the electronegative atom is reduced (gains electrons), and the two resulting ions are held together by the entirely separate, subsequent electrostatic attraction between them.

$$\mathrm{Na \to Na^+ + e^-} \quad (\text{oxidation}) \qquad \mathrm{\tfrac{1}{2}Cl_2 + e^- \to Cl^-} \quad (\text{reduction})$$
$$\mathrm{Na + \tfrac{1}{2}Cl_2 \to NaCl} \quad (\text{overall redox reaction})$$

Four conditions must hold simultaneously for ionic bonding to be favourable — not merely present, but favourable enough that the ionic route outcompetes covalent sharing:

1. **The reaction must occur between a metal and a non-metal** (or, more precisely, between a strongly electropositive species and a strongly electronegative one).
2. **The metal's ionization energy must be low enough** that electron removal is not prohibitively costly.
3. **The non-metal's electron-gain enthalpy must be sufficiently favourable (exothermic)** to offset at least part of the ionization cost.
4. **The electronegativity difference between the two atoms must be large.** A large gap is what makes electron *transfer* more energetically sensible than electron *sharing* — this is the same underlying comparison introduced qualitatively in §1.4, now made quantitative.
5. **The resulting lattice energy must be large enough (highly exothermic)** to make the overall process favourable — this is frequently the *decisive* term, since ionization energy is always endothermic and often substantial, and it is lattice energy that must supply enough stabilization to overcome it. This is the direct link to §3.2–3.3 below: ionic bonding is not simply "electron transfer," it is electron transfer *followed by* a large electrostatic stabilization that makes the whole multi-step process net exothermic.

> **Why? (the conceptual bridge to what follows)**
> It is easy to mis-state ionic bond formation as "sodium gives its electron to chlorine because chlorine wants it more." This confuses electron-gain enthalpy (a real, quantifiable, exothermic step) with the *complete* energy picture. In fact, ionizing Na costs energy (endothermic, $+496\text{ kJ mol}^{-1}$) and even Cl's electron-gain enthalpy alone doesn't fully repay that cost ($-349\text{ kJ mol}^{-1}$; net so far: $+147\text{ kJ mol}^{-1}$, unfavourable). The reaction is only overall exothermic because of the large additional energy released when the gaseous ions condense into a solid lattice — the electrostatic attraction summed over the *entire* crystal, not just one ion pair. This is precisely why lattice energy — not ionization energy or electron-gain enthalpy alone — deserves the detailed quantitative treatment that follows.

### 3.2 The Born–Haber Cycle

The **Born–Haber cycle** (Born and Haber, 1919) is an application of Hess's Law that breaks the overall formation of an ionic solid from its elements into a sequence of individually measurable (or calculable) steps, allowing any *one* unmeasurable quantity in the sequence to be found if all the others are known.

**Worked example 3.1 — Full Born–Haber cycle for NaCl(s), with correct sign convention**

*Problem:* Given the enthalpy of sublimation of Na, the bond dissociation enthalpy of Cl₂, the ionization enthalpy of Na, the electron-gain enthalpy of Cl, and the lattice enthalpy of NaCl, verify the standard enthalpy of formation of NaCl(s).

*Data (standard literature values):* $\Delta H_{\mathrm{sub}}(\mathrm{Na}) = +108\text{ kJ mol}^{-1}$; $D(\mathrm{Cl_2}) = +242\text{ kJ mol}^{-1}$ (so $\tfrac{1}{2}D = +121\text{ kJ mol}^{-1}$); $IE_1(\mathrm{Na}) = +496\text{ kJ mol}^{-1}$; $\Delta H_{\mathrm{eg}}(\mathrm{Cl}) = -349\text{ kJ mol}^{-1}$; $U(\mathrm{NaCl}) = -788\text{ kJ mol}^{-1}$ (lattice enthalpy **of formation**, i.e., $\mathrm{Na^+(g) + Cl^-(g) \to NaCl(s)}$).

*Reasoning — build the cycle step by step, tracking signs:*

$$\mathrm{Na(s) + \tfrac{1}{2}Cl_2(g) \xrightarrow{\Delta H_f^\circ} NaCl(s)}$$

By Hess's Law, this direct path must equal the sum of the indirect path via gaseous atoms and ions:

$$\Delta H_f^\circ = \Delta H_{\mathrm{sub}}(\mathrm{Na}) + \tfrac{1}{2}D(\mathrm{Cl_2}) + IE_1(\mathrm{Na}) + \Delta H_{\mathrm{eg}}(\mathrm{Cl}) + U$$

$$\Delta H_f^\circ = (+108) + (+121) + (+496) + (-349) + (-788) = -412\text{ kJ mol}^{-1}$$

*Verification:* the accepted experimental $\Delta H_f^\circ(\mathrm{NaCl}) = -411\text{ kJ mol}^{-1}$ — the cycle closes correctly within rounding. ✓

*Conclusion:* every endothermic step (sublimation, dissociation, ionization — energy must be *supplied* to create gaseous, separated cations) is more than repaid by the two exothermic steps (electron gain, and overwhelmingly, lattice formation), and it is specifically the **lattice term** that dominates the exothermic side and makes the overall reaction favourable.

*Common mistake:* mixing up the sign of the lattice term by forgetting whether it is defined as *formation* ($\mathrm{ions(g) \to solid}$, exothermic, negative) or *dissociation* ($\mathrm{solid \to ions(g)}$, endothermic, positive) — these are numerically equal in magnitude but **opposite in sign**, and every Born–Haber cycle calculation must state explicitly which convention is being used before substituting a value. This distinction is elaborated fully in §3.3.

![Figure 3.1: Born-Haber cycle for NaCl](figures/fig3_1_born_haber_nacl.svg)

**Figure 3.1.** Each arrow represents one measurable enthalpy step; the diagonal (green, dashed) is the single-step overall formation enthalpy, equal by Hess's Law to the sum of all the smaller steps taken together. Endothermic steps (blue) raise the energy; exothermic steps (red) lower it; the lattice-formation step is by far the largest single contribution and is what pulls the overall diagonal downward into strongly exothermic territory.

> **Exam Method**
> When a Born–Haber question gives you every quantity except one, set up the full signed equation first (as above), substitute every known value with its correct sign, and solve for the unknown **algebraically** — do not try to "guess" the unknown quantity's sign from intuition. A very common trap is being given the lattice **dissociation** enthalpy (positive) when the cycle as drawn requires the lattice **formation** enthalpy (negative) for that same numerical magnitude — always re-check which direction the arrow in your specific cycle diagram is pointing before substituting.

### 3.3 Lattice Enthalpy — Definition and the Formation/Dissociation Distinction

**Lattice enthalpy** is the enthalpy change associated with the formation or breaking apart of one mole of an ionic solid into (or from) its gaseous ions.

$$\mathrm{Na^+(g) + Cl^-(g) \longrightarrow NaCl(s)} \qquad \Delta H = U_{\text{formation}} = -788\text{ kJ mol}^{-1} \quad (\text{exothermic})$$
$$\mathrm{NaCl(s) \longrightarrow Na^+(g) + Cl^-(g)} \qquad \Delta H = U_{\text{dissociation}} = +788\text{ kJ mol}^{-1} \quad (\text{endothermic})$$

These are the **same physical process run in opposite directions**, and therefore have exactly the same magnitude but opposite sign — treating them as interchangeable without flipping the sign is one of the most common numerical errors in this topic, worth restating from §3.2's Common Trap box.

### 3.4 The Born–Landé Equation

The lattice energy can be calculated from first principles by treating ions as point charges held together by Coulombic attraction, opposed at short range by a repulsive term arising from the overlap of filled electron shells (the same attractive/repulsive competition that produces the general potential-energy curve of §1.2, now applied specifically to an extended ionic lattice rather than a single bond).

$$U = -N_0 \dfrac{A z^+ z^- e^2}{4\pi\varepsilon_0 r_0}\left(1 - \dfrac{1}{n}\right)$$

where: $N_0$ = Avogadro's constant; $A$ = **Madelung constant** (a purely geometric factor depending on the crystal structure, summing the electrostatic contributions of every ion in the lattice, not just nearest neighbours); $z^+, z^-$ = the numerical charges on the cation and anion; $e$ = electronic charge; $\varepsilon_0$ = permittivity of free space; $r_0$ = equilibrium inter-ionic distance; $n$ = the **Born exponent**, an empirical number (typically 5–12) reflecting how steeply the short-range repulsive term rises as the ions are compressed together — larger $n$ corresponds to a "harder," less compressible ion (Table 3.2).

| Electronic structure of ion | Born exponent $n$ | Example ions |
|---|---:|---|
| He-like | 5 | Li⁺, Be²⁺ |
| Ne-like | 7 | Na⁺, Mg²⁺, O²⁻, F⁻ |
| Ar-like | 9 | K⁺, Ca²⁺, S²⁻, Cl⁻, Cu⁺ |
| Kr-like | 10 | Rb⁺, Br⁻, Ag⁺ |
| Xe-like | 12 | Cs⁺, I⁻, Au⁺ |

For a compound of two different ions, the average of the two individual $n$ values is used (e.g., for LiCl, $n = (5+9)/2 = 7$).

| Crystal structure type | Madelung constant $A$ |
|---|---:|
| Zinc blende (ZnS) | 1.638 |
| Wurtzite (ZnS) | 1.641 |
| Rock salt (NaCl) | 1.748 |
| Caesium chloride (CsCl) | 1.763 |
| Rutile (TiO₂) | 2.408 |
| Fluorite (CaF₂) | 2.519 |
| Corundum (Al₂O₃) | 4.172 |

**Reading the equation physically, term by term:**
- The $\dfrac{z^+z^-}{r_0}$ factor is the ordinary Coulomb's-law statement that attraction is stronger for higher ionic charges and shorter inter-ionic distance — this alone would predict an *infinite* energy release as $r_0 \to 0$, which is unphysical.
- The $\left(1 - \dfrac{1}{n}\right)$ correction factor is what prevents that unphysical divergence: it accounts for the short-range repulsion that switches on once electron clouds begin to overlap (exactly the repulsive branch of the general potential-energy curve, §1.2), capping the lattice energy at a finite, physically sensible value corresponding to the true equilibrium separation.

> **Model Limitation**
> The close numerical agreement typically seen between Born–Landé-calculated lattice energies and Born–Haber-cycle experimental values (often within 1–3% for alkali halides) does **not** by itself prove that the underlying assumption — that the ions behave as perfect point charges with 100% ionic bonding — is correct. The equation is, in a specific sense, self-compensating: increasing the inter-ionic distance $r_0$ (e.g., by changing coordination number) *reduces* the calculated lattice energy, but a coordination-number change is nearly always accompanied by a *change in crystal structure*, and hence in the Madelung constant $A$, which *increases* the calculated lattice energy in partial compensation. The two effects substantially cancel, which can mask genuine errors in the underlying point-charge assumption. Large disagreement between calculated and experimental lattice energy (seen, for example, in $\mathrm{CdI_2}$, which shows roughly 20%+ deviation) is itself useful evidence that a compound has **significant covalent character** and is not well described as a simple ionic point-charge lattice — this is the direct bridge into Part 4 (Fajans' rules, polarization, and covalent character).

### 3.5 Factors Affecting Lattice Enthalpy

Lattice enthalpy magnitude is governed by exactly the two variables that appear explicitly in the Born–Landé equation's dominant Coulombic term:

**(a) Ionic charge.** Lattice energy is directly proportional to the product $z^+z^-$. Doubling either ionic charge roughly doubles the numerator of the dominant Coulombic term, so lattice energy rises sharply with charge — this is why oxides and nitrides of a given cation (with $\mathrm{O^{2-}}$ or $\mathrm{N^{3-}}$) have dramatically higher lattice energies than the corresponding halides (with singly-charged $\mathrm{X^-}$) of the same cation, even at comparable ionic size.

**(b) Ionic size (inter-ionic distance).** Lattice energy is inversely proportional to $r_0$. Smaller ions can approach more closely, concentrating the Coulombic attraction over a shorter distance, so lattice energy decreases smoothly down a group as ionic radius increases (for a fixed charge type): $\mathrm{LiF > NaF > KF > RbF > CsF}$ in lattice energy.

**Worked example 3.2 — Ordering lattice energies by combining both factors**

*Problem:* Arrange $\mathrm{NaF}$, $\mathrm{MgO}$, and $\mathrm{ScN}$ in order of increasing lattice energy, given all three have essentially the same rock-salt crystal structure and comparable inter-ionic distances.

*Reasoning:* Since $r_0$ and $A$ are held roughly constant across this series, lattice energy is controlled almost entirely by the charge product $z^+z^-$: $\mathrm{NaF}$ ($1\times1=1$), $\mathrm{MgO}$ ($2\times2=4$), $\mathrm{ScN}$ ($3\times3=9$).

*Conclusion:* $\mathrm{NaF < MgO < ScN}$ — and because lattice energy correlates directly with melting point and hardness (both reflect the energy needed to disrupt the lattice), the same order holds for melting point and Mohs hardness across this series, which is a frequently tested cross-property ordering question.

*Common mistake:* trying to order these by ionic radius alone (which would be a much weaker, secondary effect here) instead of recognizing that the charge-product term dominates so heavily ($9\times$ difference between NaF and ScN) that it alone determines the ranking.

### 3.6 Hydration Enthalpy, Solution Enthalpy, and Solubility

When an ionic solid dissolves, two competing energetic processes occur: the lattice must be broken apart (always endothermic, requiring input equal to the lattice dissociation enthalpy) and the resulting free ions become surrounded and stabilized by solvent molecules — for water, this is **hydration enthalpy**, always exothermic, since ion–dipole attraction between the ion and the polar water molecules releases energy.

$$\Delta H_{\text{solution}} = \Delta H_{\text{lattice dissociation}} + \Delta H_{\text{hydration}}$$

A salt is soluble when $\Delta H_{\text{solution}}$ is sufficiently favourable (or, more completely, when $\Delta G_{\text{solution}} = \Delta H_{\text{solution}} - T\Delta S_{\text{solution}}$ is negative — dissolution always increases entropy, since ions become free to move in solution rather than fixed in a lattice, so even a mildly endothermic $\Delta H_{\text{solution}}$ can still be spontaneous if the entropy term is large enough at a given temperature).

**Why water is such an effective solvent for ionic solids — and why not universally.** Water's very high **dielectric constant** ($\varepsilon_r \approx 80$) means that once ions are separated in solution, the electrostatic attraction *between* those ions (which would otherwise pull them back together) is reduced by a factor of $\sim 80$ relative to their attraction in a vacuum or in a low-polarity solvent — this is the direct, quantitative reason polar solvents dissolve ionic solids far more effectively than non-polar ones ("like dissolves like" restated with its actual physical mechanism, not just as a slogan).

| Solvent | Dielectric constant $\varepsilon_r$ (approx.) |
|---|---:|
| Water | 80 |
| Methanol | 33 |
| Ethanol | 24 |
| Diethyl ether | 4.3 |

**Solubility-down-a-group ordering for oxoanion salts** (source-verified, `cbvj.pdf` p.126): when the lattice-energy and hydration-energy competition of §3.6 favours the *larger* cation (the size-matched-packing case already established for thermal stability in §3.8, and applying by the identical logic here), solubility for a fixed oxoanion **increases** down the alkali-metal group:

$$\mathrm{LiClO_4 < NaClO_4 < KClO_4 < RbClO_4 < CsClO_4} \qquad \mathrm{Li_2CO_3 < Na_2CO_3 < K_2CO_3 < Rb_2CO_3 < Cs_2CO_3}$$

and, extending the same reasoning to alkaline-earth oxoanion salts of decreasing lattice stability down the group:

$$\mathrm{BeSO_4 > MgSO_4 > CaSO_4 > SrSO_4 > BaSO_4} \qquad (\text{decreasing solubility down the group})$$

> **Compare** — this is the same size-matching principle already used for thermal stability (§3.8) now applied to solubility, and it is worth explicitly noting that the *direction* of the trend depends on which effect dominates for a given salt family: for simple halides of a fixed small cation (§3.6's main worked material), solubility trends are typically dominated by hydration-enthalpy loss down the group (decreasing solubility, e.g. LiF<NaF<KF<RbF<CsF is actually an *increasing* trend driven by lattice energy falling faster than hydration energy for this specific small-anion case — see the full alkali-halide solubility discussion in §3.6). Alkaline-earth sulfates show the *opposite* direction (BeSO₄ most soluble, decreasing down the group) because, for these larger, polyatomic-anion, higher-charge-density combinations, lattice energy dominates hydration energy across the whole series rather than only for the lightest member. **The controlling physical variable is always the same (relative size of the lattice-energy and hydration-energy terms in §3.6's equation) — only which term wins, and therefore which direction the trend runs, changes from series to series**, which is exactly why this class of ordering question cannot be answered by memorizing a single universal direction.

**Worked example 3.3 — Predicting the solubility-trend direction from first principles**

*Problem:* Without memorizing the specific direction, predict whether $\mathrm{Li_2CO_3}$ or $\mathrm{Cs_2CO_3}$ is more soluble in water.

*Reasoning:* $\mathrm{CO_3^{2-}}$ is a relatively large, polyatomic, doubly-charged anion (§6.5's structure). Li⁺ is by far the smallest alkali cation — pairing a very small cation with a large anion gives poor size-matched packing (§3.8's "rattling in an oversized site" mechanism), which *weakens* the lattice more than it weakens the hydration enthalpy (Li⁺, being small and highly charged-dense, is itself very strongly hydrated regardless of its anion partner). A weaker lattice, competing against a still-strong hydration term, favours dissolution.

*Conclusion:* $\mathrm{Li_2CO_3}$ is *less* soluble than $\mathrm{Cs_2CO_3}$ — matching the verified order above — because Cs⁺, despite being weakly hydrated on its own, forms a comparatively weaker lattice with the large $\mathrm{CO_3^{2-}}$ anion than the size-mismatch-penalized Li⁺ lattice does, and lattice-energy loss (not hydration-energy gain) is the term that dominates this specific large-anion series.

*Common mistake:* assuming "smaller cation = more strongly hydrated = more soluble" as a universal rule — this is true only when the *anion* is also small enough for good size-matched packing (the simple-halide case); for a large polyatomic anion, the size-mismatch penalty on lattice packing can dominate and reverse the naive hydration-only prediction, exactly as demonstrated here.

> **Exception** — water is sometimes called the "universal solvent," but it is not used as a solvent for reactive metal salts or in redox-sensitive contexts, because water itself can act as **both an oxidizing and a reducing agent** depending on the other species present (it can be reduced at the cathode to $\mathrm{H_2}$, or oxidized at the anode to $\mathrm{O_2}$, in electrolysis, for example) — a genuine limitation on treating "polar solvent" and "water" as interchangeable in every context.

### 3.7 Physical Properties of Ionic Compounds — Summary Table

| Property | Typical behaviour | Physical reason |
|---|---|---|
| Physical state | Crystalline solids at room temperature | Long-range, non-directional electrostatic ordering favours a regular repeating lattice |
| Melting/boiling point | High | Breaking the lattice requires overcoming the full lattice enthalpy, which is large (§3.4–3.5) |
| Hardness/brittleness | Hard but brittle | A shearing stress that shifts one ionic layer relative to another brings like-charged ions into direct contact, producing strong repulsion and fracture — not gradual deformation (contrast with metallic bonding, Part 12) |
| Directionality | Non-directional | Coulombic attraction acts equally in all directions around an ion, unlike the directional orbital overlap of covalent bonds |
| Solubility | Generally soluble in polar solvents, insoluble in non-polar solvents | High dielectric constant of polar solvents reduces inter-ionic attraction after dissolution (§3.6) |
| Electrical conductivity | Poor as solids; good when molten or dissolved | Ions are fixed in the solid lattice (cannot migrate to carry current) but become mobile once the lattice is broken (melting) or the ions are solvated (dissolution) |
| Isomorphism | Ionic compounds with comparable ionic size, charge, and crystal structure can co-crystallize (isomorphism) | Requires comparable size of corresponding constituent units, comparable polarizing power/polarizability, comparable molar volume, and the same crystal structure type — e.g., $\mathrm{KMnO_4}$ and $\mathrm{BaSO_4}$, or $\mathrm{K_2SO_4 \cdot Al_2(SO_4)_3 \cdot 24H_2O}$ and $\mathrm{(NH_4)_2SO_4 \cdot Al_2(SO_4)_3 \cdot 24H_2O}$ (isomorphous alums) |

### 3.8 Thermal Stability of Ionic Compounds

For simple binary ionic compounds, thermal stability tracks lattice enthalpy directly: a larger inter-ionic distance gives a lower lattice enthalpy, which in turn gives lower thermal stability (the compound decomposes more readily on heating, since less energy is needed to disrupt a weaker lattice).

$$\mathrm{Li_2O > Na_2O > K_2O > Rb_2O > Cs_2O} \qquad \mathrm{LiX > NaX > KX > RbX > CsX \; (X = F, Cl, Br, I)}$$

For ionic compounds with a **polyatomic anion**, the trend can invert: thermal stability then *increases* down a group, because efficient packing between a large cation and a large polyatomic anion (both of comparable size) gives a more stable lattice than a size-mismatched pairing of a small cation with a large anion.

$$\mathrm{LiNO_3 < NaNO_3 < KNO_3 < RbNO_3 < CsNO_3} \qquad \mathrm{Li_2CO_3 < Na_2CO_3 < K_2CO_3 < Rb_2CO_3 < Cs_2CO_3}$$

> **Compare** — This is a genuinely tested reversal, and the reasoning matters more than memorizing the direction: for a *simple* anion (F⁻, O²⁻, N³⁻), a small, high-charge-density cation packs closely and gives a strong lattice → small cations favour stability with simple anions. For a *large, polyatomic* anion, a small cation "rattles" in an oversized site and packs poorly, giving a *weaker* lattice than a size-matched large cation would → large cations favour stability with large polyatomic anions. The controlling factor in both cases is the same (efficient close packing maximizes lattice enthalpy) — only the direction of the resulting trend differs, because what counts as "size-matched" is different in the two cases.

### Part 3 Summary

- Ionic bond formation is a redox process whose overall favourability depends on the full multi-step energy balance (sublimation + ionization + dissociation + electron gain + lattice formation), captured completely and quantitatively by the Born–Haber cycle (Worked Example 3.1, Figure 3.1).
- Lattice enthalpy of formation and dissociation are numerically equal but oppositely signed — the single most common sign error in this topic.
- The Born–Landé equation quantifies lattice energy from ionic charge, inter-ionic distance, crystal geometry (Madelung constant), and short-range repulsion (Born exponent); its close fit to experiment is not, by itself, proof of purely ionic bonding, and large deviations (e.g., $\mathrm{CdI_2}$) are direct evidence of covalent character — the conceptual bridge into Part 4.
- Solubility is governed by the competition between lattice dissociation enthalpy (endothermic) and hydration enthalpy (exothermic), mediated by solvent dielectric constant.
- Thermal stability tracks lattice enthalpy for simple anions (small cation favours stability) but *inverts* for large polyatomic anions (large cation favours stability), with size-matching as the single unifying physical explanation for both directions.

---

