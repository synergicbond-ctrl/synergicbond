## Part 12 — Metallic Bonding and Related Solid-State Ideas

### 12.1 The Electron-Sea Model

Metals consist of a regular lattice of positive metal-ion cores immersed in a "sea" of delocalized valence electrons that belong to the crystal as a whole, not to any individual atom or bond — the direct structural extension of the delocalization concept already developed for resonance (Part 6) and MOT (Part 10), now applied across an entire macroscopic lattice rather than one small molecule. Metallic bonding arises from the electrostatic attraction between this mobile electron sea and the fixed positive ion cores.

![Figure 12.1: Electron-sea model](figures/metallic/fig_metallic_electron_sea.svg)

**Figure 12.1.** A qualitative schematic only — the electron positions shown are illustrative of delocalization, not a literal count or exact instantaneous position of every valence electron.

> **Why? (why electrons delocalize across the whole lattice rather than localizing in bonds)**
> Metal atoms are electropositive with relatively few valence electrons and, often, several empty valence-shell orbitals available at accessible energy (§1.4's classification: neither atom in a metal-metal contact wants to hold electrons tightly). Rather than forming a large number of ordinary two-centre bonds (which each localized bond would only weakly stabilize, given how few electrons are available per atom), the valence electrons spread over the *entire* lattice, occupying a continuum of very closely-spaced molecular-orbital-like energy levels (§12.3) — this maximizes the total stabilization achievable from a limited electron supply, exactly analogous to how a resonance-delocalized structure (Part 6) is more stable than any single localized contributor, now scaled up from one molecule to an entire crystal.

### 12.2 Metallic Properties Explained by the Electron Sea

| Property | Explanation |
|---|---|
| High electrical conductivity | Delocalized electrons are free to move throughout the lattice; applying a potential difference causes a net drift of these mobile electrons, constituting a current |
| High thermal conductivity | The same mobile electrons carry kinetic energy rapidly through the lattice when one region is heated |
| Metallic lustre | Mobile electrons readily absorb photons across a broad range of visible wavelengths and immediately re-emit them as the electron falls back to its original level, giving the characteristic reflective sheen (at all viewing angles, unlike the shininess of some non-metals visible only at grazing angles) |

![Figure 12.6: Thermal conduction](figures/metallic/fig_metallic_thermal_conduction.svg)

**Figure 12.6.** Two carriers of thermal energy shown distinctly: mobile electrons (blue dots, net transport hot → cold) and lattice vibrations (red marks, larger amplitude at the hot end). Electrons scatter constantly — not ballistic, unimpeded travel — and the relative electron/lattice-vibration contribution genuinely varies between metals and with temperature.

![Figure 12.7: Metallic lustre](figures/metallic/fig_metallic_lustre.svg)

**Figure 12.7.** Incident light (gold arrows) absorbed and re-emitted (blue arrows) by the collective response of mobile/band electrons, not a single isolated-atom transition. Real optical behaviour (why copper is reddish, why gold is golden) depends on band structure, frequency response, and surface condition beyond this simple qualitative picture.
| Malleability and ductility | Because metallic bonding is **non-directional** (unlike covalent bonds), one layer of metal ions can slide past another under stress without breaking specific bonds — the electron sea simply re-adjusts around the new ion positions, in sharp contrast to an ionic lattice (§3.7), where shifting one layer brings like-charged ions into direct, strongly repulsive contact and causes brittle fracture rather than deformation |

![Figure 12.2: Electrical conduction, net drift](figures/metallic/fig_metallic_electrical_conduction.svg)

**Figure 12.2.** Individual electrons move randomly and scatter constantly off the vibrating lattice (the microscopic origin of electrical resistance) — an applied field superimposes only a small *net* drift on that much larger random motion, not unimpeded free flow.

**Worked example 12.1 — Contrasting the mechanical failure modes of metallic and ionic solids**

*Problem:* A metal can be hammered into a sheet (malleable) without shattering, while an ionic crystal shatters when struck. Explain the structural origin of this difference.

*Reasoning:* In a metal, applying shear stress shifts one plane of metal-ion cores relative to its neighbour; since the delocalized electron sea has no fixed directional preference (it simply redistributes to maintain overall attraction to whichever ion is nearby), the shifted structure remains bonded, just slightly deformed — bonding is preserved through the deformation. In an ionic crystal (§3.7), the same shear shift brings previously-alternating +/− ions into direct like-charge contact (+ next to +, or − next to −), which is strongly repulsive rather than attractive, and the crystal fractures cleanly along that plane rather than deforming.

*Conclusion:* the malleable-vs-brittle distinction is a direct structural consequence of *directionality*: metallic bonding's non-directional electron sea tolerates layer-sliding; ionic bonding's fixed, alternating-charge lattice does not.

![Figure 12.4: Malleability vs ionic brittleness](figures/metallic/fig_metallic_malleability_ductility.svg)

**Figure 12.4.** Side-by-side under identical applied stress: the metal's electron sea readjusts around the shifted ion positions (still bonded); the ionic crystal's shift brings like charges into direct contact (repulsion, fracture) — the visual counterpart to the reasoning above.

### 12.3 From Molecular Orbitals to Bands

Extending the MOT logic of Part 10 from a two-atom diatomic to a chain of $n$ metal atoms: combining $n$ atomic orbitals of the same type produces $n$ molecular orbitals, spanning a range from strongly bonding to strongly antibonding, with (for large $n$) the energy spacing between adjacent orbitals becoming vanishingly small — effectively a continuous **band** of allowed energy levels rather than a set of discrete, separated levels.

![Figure 12.3: Band formation from 1 to N atoms](figures/metallic/fig_band_formation.svg)

**Figure 12.3.** The same orbital-splitting logic already used for H₂, He₂, Li₂, etc. (Part 10), scaled up: 1 atom → 1 level; 2 atoms → 2 levels (bonding + antibonding); 4 atoms → 4 closely-spaced levels; N atoms (a real crystal) → an effectively continuous band. This is not a new phenomenon, only MOT applied at macroscopic scale.

For a metal like lithium (one valence electron per atom, $2s^1$), only the lower half of this band (the bonding half) is filled — leaving the upper half of the same band **empty and immediately accessible**, so that only a negligible amount of energy is needed to promote an electron into an unoccupied, mobile level. This is the direct band-theory explanation for metallic conduction: **conduction requires an accessible empty level essentially adjacent in energy to the highest filled level.**

### 12.4 Conductors, Insulators, and Semiconductors

| Category | Band structure | Conductivity behaviour |
|---|---|---|
| Conductor (metal) | Partially filled band, or filled and empty bands overlap | High conductivity; decreases slightly with increasing temperature (lattice vibrations increasingly scatter the mobile electrons) |
| Insulator | Full valence band, large energy gap to the next (empty) band | Essentially no conduction; the gap is too large for any practical fraction of electrons to be thermally promoted |
| Intrinsic semiconductor | Full valence band, but a **small** energy gap to the next band | Small, temperature-*increasing* conductivity, as thermal energy promotes a growing (though still small) fraction of electrons across the gap |

![Figure 12.5: Conductor, semiconductor, insulator band comparison](figures/metallic/fig_band_conductor_semiconductor_insulator.svg)

**Figure 12.5.** The three cases side by side in one consistent visual language: conductor bands overlap (no gap at all); semiconductor has a small gap crossable by ordinary thermal energy; insulator has a large gap that ordinary thermal energy cannot practically cross. No numerical band-gap values are asserted — only the qualitative small/large distinction this chapter's depth requires.

Beryllium ($2s^2$, a filled sub-band if treated as an isolated $2s$ band) is a metal, not an insulator, specifically because its $2s$-derived band **overlaps in energy** with the otherwise-empty $2p$-derived band — this overlap is what supplies the essential "accessible empty level adjacent to the highest filled level" condition, even though the simple electron-count argument (2 electrons, a "complete" $2s$ shell) would naively suggest an insulator.

> **Model Limitation** — This Part deliberately stops at the qualitative band picture sufficient to explain metallic bonding's core properties (conductivity, malleability, lustre) and the conductor/insulator/semiconductor distinction at the depth this chapter requires; the detailed treatment of doping, p-type/n-type semiconductors, and specific defect-driven conduction mechanisms belongs to the dedicated Solid State chapter and is not duplicated here.

### Part 12 Summary

- Metallic bonding is delocalization scaled up from the molecule (resonance, Part 6; MOT, Part 10) to the entire crystal lattice: mobile valence electrons throughout, attracted to fixed positive ion cores.
- Conductivity, thermal conductivity, and lustre all trace directly to the electron sea's mobility; malleability and ductility trace to metallic bonding's non-directional character, contrasted explicitly with ionic bonding's brittle, directional-repulsion failure mode (Worked Example 12.1).
- Scaling MOT to $n$ atoms produces continuous energy bands rather than discrete levels; metallic conduction requires an empty level immediately accessible in energy above the highest filled level — satisfied either by a partially-filled band (alkali metals) or by band overlap (Be).

---

## Source Traceability — Part 12

| Source PDF | Pages | Material found | Destination | Status |
|---|---|---|---|---|
| `CHEMICAL_BONDING.pdf` | §3.32–3.34 (The Metallic Bond, Theories of Bonding in Metals, Conductors/Insulators/Semiconductors, full text) | Electron-sea model, free-electron theory (Drude/Lorentz), VB-theory-of-metals resonance treatment, MO/band theory buildup from Li₂ to Liₙ, Be band-overlap explanation, conductor/insulator/semiconductor band comparison | §12.1–12.4 | INCORPORATED |
| Independently derived | — | Worked Example 12.1 (metallic vs. ionic mechanical failure mode) constructed to directly cross-reference §3.7's existing ionic-brittleness material | §12.2 | INCORPORATED, independently verified |

---

*Part 12 complete. Continuing to Part 13 (Integrated JEE Advanced Applications).*
