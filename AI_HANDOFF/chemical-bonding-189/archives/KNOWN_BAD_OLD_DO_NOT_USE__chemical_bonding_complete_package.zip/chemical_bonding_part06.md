## Part 6 — Resonance and Delocalisation

### 6.1 Why a Single Lewis Structure Becomes Insufficient

The Lewis-structure rules of §2.6 sometimes generate **more than one equally valid structure** for the same molecule or ion — same skeleton, same total electron count, same (minimal, correctly-placed) formal charges — differing only in *which* atom bears a double bond or an extra lone pair. $\mathrm{NO_3^-}$ (Worked Example 2.3) was the first example: any one of its three oxygen atoms could equally well be the doubly-bonded one.

When this happens, choosing any *single* one of these structures as "the" structure is actively misleading, because the real, experimentally observed molecule does not match any single candidate — $\mathrm{NO_3^-}$'s three N–O bonds are all experimentally identical in length (§2.6, Worked Example 2.3), not two short and one long as any individual canonical structure would suggest. **Resonance** is the recognition that the true electronic structure is a single, unique hybrid of all such valid contributing structures simultaneously, not a molecule that switches between them.

> **Why? (what resonance actually is, mechanistically)**
> A single Lewis structure localizes each bonding electron pair between one specific pair of atoms. In a resonance-stabilized species, the real electron distribution is **delocalized** — spread out over more than two atoms at once — which is a genuinely lower-energy arrangement than any single localized structure would achieve, precisely because delocalized electrons occupy a larger region of space and are attracted to *more* nuclei simultaneously (the same core stabilization logic as ordinary bond formation, §1.1, now extended from two nuclei to three or more). The energy by which the true delocalized structure is more stable than the *most stable single contributing structure* is called the **resonance energy** (or delocalisation energy).

### 6.2 Rules for Valid Resonance Contributors

Not every structure sharing a molecular formula with another is a valid resonance contributor. Valid canonical structures must satisfy all of the following simultaneously:

1. **Identical arrangement of atomic nuclei (fixed skeleton).** Only the placement of electrons (bonding pairs, lone pairs) may differ between contributors — no atom may move. This is the single most important rule, and the one most often violated by beginners: moving an atom, even slightly, does not generate a resonance structure, it generates a *different compound* (or, if the same formula, a structural isomer, not a resonance form).
2. **Identical number of paired and unpaired electrons.** All contributors must have the same total electron count and, for closed-shell species, no contributor may introduce unpaired electrons that another lacks.
3. **Comparable energy.** Contributors that require large charge separation, place like charges on adjacent atoms, or place negative charge on a less-electronegative atom (§2.6, rules 7–8) are valid in the formal sense but contribute little to the real hybrid — they are "minor" contributors, not equally weighted with the dominant structures.
4. **Each contributor must individually be a chemically reasonable Lewis structure** — correct valence-electron count, satisfying the octet rule (or a recognized, separately justified exception).

**Equivalent vs. non-equivalent contributors.** Contributors are **equivalent** if they are related by a symmetry operation of the molecule (e.g., $\mathrm{NO_3^-}$'s three structures, related by which of the three chemically identical O atoms bears the double bond) — equivalent contributors are, by definition, equally stable and contribute *equally* to the hybrid, and bond-length equalization (§6.4) follows directly. Contributors are **non-equivalent** if they differ in formal-charge distribution, bond arrangement, or stability in a way not related by symmetry (e.g., the two $\mathrm{N_2O}$ structures below) — non-equivalent contributors contribute *unequally*, with the lower-energy (generally lower-formal-charge, better-placed-charge) structure weighted more heavily in the real hybrid.

> **Common Trap** — "More resonance structures always means more stability" is an oversimplification. Only contributors that are individually reasonable (rule 3 and 4 above) add meaningfully to the resonance energy; drawing additional, high-energy, poorly-charge-separated structures does not meaningfully lower the true energy of the hybrid, even though they are, strictly, "formally valid" by rules 1–2.

### 6.3 The Resonance Hybrid and Fractional Bond Order

The **resonance hybrid** is the single, true, weighted-average electronic structure — not a real physical mixture of the separate canonical forms existing at different moments, but the one actual structure the canonical forms are collectively an imperfect notational attempt to represent. For a set of $n$ equivalent contributors, the **average bond order** for a given bond position is (verified against `Chemical_Bonding_Kohinoor_.pdf` p.140):

$$\text{Bond order (averaged)} = \dfrac{\text{number of bonds between that pair of atoms, summed across all contributors}}{\text{total number of contributors}}$$

For $\mathrm{NO_3^-}$: each of the three N–O positions is a double bond in exactly one of the three equivalent contributors and a single bond in the other two, giving bond order $= (1\times2 + 2\times1)/3 = 4/3$ for every N–O bond — matching the intermediate, equal bond length already established in Worked Example 2.3.

> **Common Trap — resonance is not equilibrium, and canonical structures are not interconverting real species.** Do not write $\rightleftharpoons$ between resonance structures (reserved for genuine chemical equilibria between distinct, separately-existing species, §1.4-adjacent) — use only the double-headed resonance arrow $\leftrightarrow$. There is only **one** real molecule/ion with **one** true (delocalized) electronic structure; the several canonical drawings are alternative *notations* for that one structure, not alternative *states* the molecule physically visits over time.

> **Important Conceptual Distinction — resonance vs. tautomerism.** Resonance structures differ only in electron placement over a fixed nuclear skeleton (§6.2, rule 1) and are not separate, isolable species — you cannot "trap" one resonance structure. Tautomers (e.g., keto and enol forms) differ in the actual position of at least one atom (typically a proton) and *are* genuinely distinct, separately-existing (if often rapidly interconverting) chemical species related by an ordinary equilibrium, correctly written with $\rightleftharpoons$. Confusing these two is one of the most consequential terminology errors in this topic, because it leads directly to the "resonance structures rapidly interconvert" misconception explicitly flagged above.

### 6.4 Bond-Length Equalization as Experimental Evidence for Resonance

Because the resonance hybrid is the single true structure, every bond position that is equivalent across all major contributors is observed experimentally as a single, averaged bond length — never as two (or more) distinct lengths corresponding to the individual canonical drawings. This experimental equalization (already used as direct evidence in Worked Example 2.3 for $\mathrm{NO_3^-}$, and numerically confirmed for $\mathrm{CO_3^{2-}}$ below) is the primary real-world justification for treating resonance as a description of one true delocalized structure rather than a notational convenience with no physical content.

### 6.5 Fully Worked Resonance Structures

**Worked example 6.1 — Ozone, O₃ (non-equivalent lone-pair/bonding arrangement, equivalent overall contributors)**

Total valence electrons $= 3(6) = 18$. Skeleton: bent O–O–O (central O bonded to two terminal O). Two equivalent canonical structures exist, related by which terminal O bears the double bond:

Central O: 1 lone pair, one O=O double bond, one O–O single bond ($N=2, B=6$): $FC = 6-2-3 = +1$.
Doubly-bonded terminal O: 2 lone pairs ($N=4, B=4$): $FC = 6-4-2 = 0$.
Singly-bonded terminal O: 3 lone pairs ($N=6, B=2$): $FC = 6-6-1 = -1$.

Sum $= +1+0-1 = 0$ ✓ (neutral molecule). The two contributors are equivalent (related by the molecule's own mirror symmetry), so each O–O bond has average bond order $3/2$, consistent with the experimentally observed O–O bond length in ozone (128 pm) lying between a typical O–O single bond (148 pm) and O=O double bond (121 pm).

*Common mistake:* drawing ozone as $\mathrm{O=O=O}$ (both bonds double, no charge separation) — this uses $4+4+4(\text{lone pairs on ends})+0 = $ let us check: two double bonds $=8$ bonding electrons, terminal O's would need 2 lone pairs each ($4+4=8$ non-bonding), central O 0 lone pairs; total $=8+8=16 \ne 18$, failing the valence-electron count outright, and additionally leaving the central O with only 8 electrons but *zero* lone pairs while requiring $sp$ hybridization inconsistent with ozone's known bent (not linear) shape (Part 9). This structure is simply wrong, not merely a minor contributor — a useful reminder that the valence-electron count check (§2.6, rule 1) must be applied to *every* candidate structure, not assumed satisfied by symmetry alone.

**Worked example 6.2 — Carbonate, CO₃²⁻ (three equivalent contributors)**

Total valence electrons $= 4 + 3(6) + 2 = 24$. C central, bonded to three O; one C=O double bond and two C–O single bonds, three equivalent resonance structures (double bond rotating among the three O atoms).

C: $B=8$ (one double + two single bonds), $N=0$: $FC = 4-0-4 = 0$.
Doubly-bonded O: $N=4, B=4$: $FC=0$.
Each singly-bonded O (×2): $N=6, B=2$: $FC = -1$.

Sum $= 0+0-1-1 = -2$ ✓. Average C–O bond order $= (1\times2+2\times1)/3 = 4/3$ for every bond — and indeed all three C–O bonds in $\mathrm{CO_3^{2-}}$ are experimentally equal (129 pm), intermediate between a C–O single bond (143 pm) and C=O double bond (120 pm), the same pattern already established for $\mathrm{NO_3^-}$.

**Worked example 6.3 — Bicarbonate, HCO₃⁻ (resonance restricted by the added H)**

Total valence electrons $= 1 + 4 + 3(6) + 1 = 24$. Structure: C bonded to one –OH group (O–H single bond, O also single-bonded to C), one C=O double bond, and one C–O⁻ single bond; **only two** of the three oxygens (the non-hydroxyl ones) participate in resonance with each other — the hydroxyl oxygen's bonding is fixed by the H atom.

C: $B=8, N=0$: $FC=0$. Hydroxyl O (bonded to C and H): $N=4, B=4$: $FC=6-4-2=0$. Doubly-bonded O: $FC=0$. Singly-bonded (anionic) O: $N=6,B=2$: $FC=-1$.

Sum $=0+0+0-1=-1$ ✓. **Only the two non-hydroxyl C–O bonds are resonance-equalized** (average bond order $3/2$ between just those two positions); the C–OH bond is chemically and structurally distinct (a genuine single bond, not part of the delocalized resonance system) — this is the direct, worked illustration of why HCO₃⁻ is a useful case for the general point that resonance equalizes only the bonds that are genuinely equivalent across the valid contributors, not every bond in the ion indiscriminately.

**Worked example 6.4 — N₂O (non-equivalent contributors, unequal weighting)**

Total valence electrons $= 2(5)+6 = 16$. Linear skeleton N–N–O (**not** N–O–N — a frequently tested connectivity trap). Two non-equivalent canonical structures:

*(a)* $\mathrm{{:}N{\equiv}N{-}O{:}}$: terminal N ($B=6,N=2$): $FC=5-2-3=0$; central N ($B=8,N=0$): $FC=5-0-4=+1$; O ($B=2,N=6$): $FC=6-6-1=-1$. Sum $=0+1-1=0$ ✓.
*(b)* $\mathrm{{:}N{=}N{=}O{:}}$: terminal N ($B=4,N=4$): $FC=5-4-2=-1$; central N ($B=8,N=0$): $FC=+1$; O ($B=4,N=4$): $FC=6-4-2=0$. Sum $=-1+1+0=0$ ✓.

Both are individually valid, but they are **non-equivalent** — structure (a) places the formal negative charge on O (more electronegative, favoured by §2.6 rule 7) while structure (b) places it on the terminal N (less electronegative, disfavoured). By the same electronegativity-placement logic applied throughout §2.6 and Worked Example 2.6 (SCN⁻), **structure (a) is the major contributor**, consistent with $\mathrm{N_2O}$'s common depiction as $\mathrm{N \equiv N^+ {-} O^-}$ in most standard references, though real N₂O shows measurable contribution from both forms (its N–N bond, at 113 pm, is shorter than a typical N=N double bond, ~125 pm, and closer to the N≡N triple-bond length in structure (a), consistent with (a) dominating but not being the sole contributor).

**Worked example 6.5 — SO₂ and SO₃, contrasted**

$\mathrm{SO_2}$ (18 valence electrons): bent, S with 1 lone pair, one S=O double bond and one S–O single bond (two equivalent resonance structures, double bond alternating between the two O atoms). S: $N=2, B=6$: $FC=6-2-3=+1$. Doubly-bonded O: $FC=0$. Singly-bonded O: $FC=6-6-1=-1$. Sum $=+1+0-1=0$ ✓. Average S–O bond order $3/2$.

$\mathrm{SO_3}$ (24 valence electrons): trigonal planar, and — unlike $\mathrm{SO_2}$ — the simplest valid Lewis structure already places **three S=O double bonds** directly (S: $B=12, N=0$: $FC=6-0-6=0$; each O: $N=4,B=4$: $FC=0$; sum $=0$ ✓), giving bond order $2$ for every S–O bond **without needing resonance to explain the equal bond lengths** — the symmetric all-double-bond structure is already the most stable single contributor and already fully consistent with the observed $D_{3h}$ symmetry and equal S–O bond lengths (142 pm, shorter than $\mathrm{SO_2}$'s averaged 143 pm S–O bond order-$3/2$ length, consistent with $\mathrm{SO_3}$'s higher bond order).

> **Compare** — $\mathrm{SO_2}$ genuinely *requires* resonance (two non-identical-looking but equivalent contributors) to explain its equal bond lengths, while $\mathrm{SO_3}$'s equal bond lengths follow already from a *single*, symmetric, expanded-octet structure. This is a useful discipline-check: before invoking resonance, always first ask whether a single valid Lewis structure already explains the observed symmetry — resonance is invoked only when it is genuinely necessary, not reflexively for every molecule with more than one heteroatom.

**Worked example 6.6 — Oxo-anions of chlorine: ClO₂⁻, ClO₃⁻, ClO₄⁻**

All three follow the same pattern as $\mathrm{SO_3}$ above — the lowest-formal-charge structure places as many Cl=O double bonds as the expanded octet permits, with resonance then equalizing the remaining bond(s):

$\mathrm{ClO_2^-}$ (20 valence e⁻): one Cl=O, one Cl–O, 2 lone pairs on Cl (two equivalent resonance forms). Cl: $N=4,B=6$: $FC=7-4-3=0$. Double-bonded O: $FC=0$. Single-bonded O: $FC=-1$. Sum $=-1$ ✓. Average Cl–O bond order $3/2$.

$\mathrm{ClO_3^-}$ (26 valence e⁻): two Cl=O, one Cl–O, 1 lone pair on Cl (three equivalent resonance forms). Cl: $N=2, B=10$: $FC=7-2-5=0$. Doubly-bonded O (×2): $FC=0$. Singly-bonded O: $FC=-1$. Sum $=-1$ ✓. Average Cl–O bond order $= (2\times2+1\times1)/3 = 5/3$.

$\mathrm{ClO_4^-}$ (32 valence e⁻): three Cl=O, one Cl–O, no lone pair on Cl (four equivalent resonance forms). Cl: $N=0,B=14$: $FC=7-0-7=0$. Doubly-bonded O (×3): $FC=0$. Singly-bonded O: $FC=-1$. Sum $=-1$ ✓. Average Cl–O bond order $=(3\times2+1\times1)/4=7/4$.

*JEE Advanced Insight:* this series is a clean, self-consistent illustration that increasing the number of terminal O atoms on the same central atom (with the same central-atom charge accommodation) systematically increases the *average* bond order per Cl–O bond, which is the direct explanation for why Cl–O bond length shortens smoothly across $\mathrm{ClO^- > ClO_2^- > ClO_3^- > ClO_4^-}$ — a frequently tested bond-length ordering question, now derivable from first principles rather than requiring memorization.

**Worked example 6.7 — Cyanate, OCN⁻ (linear, cross-referencing SCN⁻)**

Total valence electrons $= 6+4+5+1 = 16$. Linear O–C–N skeleton. Dominant structure (by the same electronegativity-placement reasoning as $\mathrm{SCN^-}$, Worked Example 2.6, and $\mathrm{N_2O}$, Worked Example 6.4, above): $\mathrm{O{=}C{=}N^-}$. O: $N=4,B=4$: $FC=6-4-2=0$. C: $N=0,B=8$: $FC=4-0-4=0$. N: $N=4,B=4$: $FC=5-4-2=-1$. Sum $=0+0-1=-1$ ✓ — negative formal charge correctly placed on N, the more electronegative of the two terminal atoms compared to C, consistent with the same rule used throughout this Part.

### 6.6 Resonance in Odd-Electron Species

Odd-electron species (§2.7c) can also show resonance, with the single unpaired electron itself delocalized across more than one position rather than fixed on one atom. $\mathrm{NO_2}$ (already introduced in §2.10) is the standard example: the radical character and the formal negative charge can be written on either oxygen (two non-equivalent-by-formal-charge-but-symmetry-equivalent resonance structures, mirroring the $\mathrm{O_3}$ pattern above), consistent with $\mathrm{NO_2}$'s well-known tendency to dimerize through the delocalized radical density at either terminal position to form $\mathrm{N_2O_4}$.

### 6.7 Limitations of Simplistic Resonance Rules

1. **Formal charge minimization alone does not always identify the true major contributor** (§2.6's own caveat, revisited): in cases where several structures have comparably small formal charges, additional factors — actual bond strength trends, experimental bond-length data, and (beyond the scope of simple electron counting) computed electron-delocalization energies — are needed to assign relative weighting with confidence.
2. **Not every pair of "similar-looking" structures is a valid resonance pair** — §6.2's skeleton-fixed rule is absolute; a common error is treating structural or geometric isomers (genuinely different compounds) as if they were resonance forms of one compound.
3. **Resonance energy is not directly measurable as a single clean experimental quantity** — it is typically *inferred* indirectly, by comparing an experimentally measured property (such as heat of hydrogenation, or lattice energy via the Born–Haber-cycle-style comparison already used for ionic-vs-covalent character in §3.4) against a hypothetical non-delocalized reference structure's predicted value; the difference is attributed to resonance stabilization, but this inference depends on how the non-resonating reference is modelled.

### Part 6 Summary

- Resonance describes one real, delocalized electronic structure using several fixed-skeleton, electron-arrangement-only canonical drawings; the double-headed arrow ($\leftrightarrow$) and the explicit statement "these are not interconverting real species" are both essential, not optional, notation.
- Valid contributors share atomic positions and total electron count; equivalent contributors (related by molecular symmetry) weight equally, non-equivalent contributors weight by relative stability (formal charge magnitude and placement, §2.6's rules 7–8 reused directly).
- Average bond order $=$ (bonds at that position, summed over all contributors) $/$ (number of contributors) — directly explains experimentally observed bond-length equalization, worked explicitly for O₃, CO₃²⁻, HCO₃⁻ (partial equalization only), N₂O, SO₂ (resonance-requiring) vs. SO₃ (single-structure-sufficient), and the ClO₂⁻/ClO₃⁻/ClO₄⁻ series (systematic bond-order-driven bond-length trend).
- Resonance is categorically distinct from both chemical equilibrium (separate, isolable species, $\rightleftharpoons$) and tautomerism (genuine atom/proton repositioning, also $\rightleftharpoons$) — conflating these is the single most consequential terminology error in this topic.

---

## Source Traceability — Part 6

| Source PDF | Pages | Material found | Destination | Status |
|---|---|---|---|---|
| `Chemical_Bonding_Kohinoor_.pdf` | p.140 (of 261) | Resonance definition, average-bond-order formula (verified and directly used), CO₂ bond-length-intermediate example (not force-fit, CO₂ is not itself a resonance case — noted and correctly excluded), CO₃²⁻ equal-bond-length statement | §6.1, §6.3 | INCORPORATED |
| `Chemical_Bonding_Kohinoor_.pdf` | p.215, p.237 (SCN keyword hits) | Cross-reference confirmation only — same content already incorporated via Worked Example 2.6 in Part 2 | — | DUPLICATE — already covered in §2.6 |
| `Chemical_Bonding_Kohinoor_.pdf` | pp.74, 171 | π-electron delocalisation effects, VBT limitations (already used in Part 2's §2.9 cross-reference) | — | DUPLICATE — already covered |
| `CHEMICAL_BONDING.pdf` | (full text checked; no dedicated resonance section exists in this source's table of contents, §3.1–3.34) | — | — | IRRELEVANT — source does not cover resonance as a separate topic; Part 6 is therefore built primarily from Kohinoor plus independently-derived, hand-verified structures rather than heavily sourced from this PDF |
| `cbvj.pdf`, `Chemical Bonding (E)/1–12.pdf` | full existing OCR index re-queried (resonance, canonical, delocali, hybrid structure) | No hits beyond what is already logged (SCN-related pages already covered in Part 2's matrix) | — | IRRELEVANT TO PART 6 |
| Independently derived (not sourced from any single PDF) | — | O₃, CO₃²⁻, HCO₃⁻, SO₂, SO₃, N₂O, ClO₂⁻/ClO₃⁻/ClO₄⁻, OCN⁻ — all electron counts and formal charges computed and self-checked before writing | §6.5, Worked Examples 6.1–6.7 | INCORPORATED, independently verified |

---

*Part 6 complete. Continuing to Part 7 (Valence Bond Theory and Orbital Overlap).*
