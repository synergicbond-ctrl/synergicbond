## Part 9 — VSEPR Theory and Molecular Geometry

### 9.1 From Sidgwick–Powell to Gillespie's VSEPR

Sidgwick and Powell (1940) first proposed that molecular shape could be predicted purely from the *number* of electron pairs (bonding and lone) in the central atom's valence shell, treating all pairs as equivalent and mutually repelling, arranged to be as far apart as possible. Gillespie (1957) refined this into **VSEPR** (Valence Shell Electron Pair Repulsion) theory by recognizing that not all electron pairs repel *equally* — the refinement that gives VSEPR its real predictive power over the cruder Sidgwick–Powell starting point.

**The VSEPR repulsion hierarchy** (verified against `CHEMICAL_BONDING.pdf` §3.6):

$$\text{lone pair–lone pair} > \text{lone pair–bond pair} > \text{bond pair–bond pair}$$
$$\text{double bond–double bond} > \text{double bond–single bond} > \text{single bond–single bond}$$

> **Why? (the physical reason for the hierarchy, not just its statement)**
> A lone pair is attracted by only **one** nucleus (the central atom's), so its electron cloud is less tightly confined and spreads over a wider angular region than a bond pair, which is attracted by **two** nuclei simultaneously and is correspondingly pulled into a narrower, more confined region. A wider, more diffuse lone-pair cloud produces stronger angular repulsion against its neighbours than a confined bond pair does — this is the single physical fact underlying the entire repulsion hierarchy above, and it is the same fact already used (in different language) as the driving mechanism behind Bent's rule (§8.5: lone pairs occupy the most s-character-rich, most tightly nucleus-bound orbital available, precisely because they are single-nucleus-attracted and benefit most from being held close). A double bond, similarly, has a higher local electron density than a single bond (more shared electrons in the same general region), so it behaves as a "fatter" repelling domain than a single bond.

### 9.2 Steric Number and the AXₘEₙ Framework

The **steric number** (already introduced mechanically in §8.4) is the count of atoms bonded to the central atom plus the count of lone pairs on it. **Electron-pair (or "electron-domain") geometry** is the arrangement predicted by the steric number alone, treating every domain (bond or lone pair) as equivalent for the purpose of determining the underlying symmetric framework; **molecular geometry** is the shape actually observed, which is the electron-pair geometry with lone-pair positions removed from the description (since lone pairs are not directly observable in a structure determination) — the same skeleton, but named according to only the *atoms* now visible.

> **Important Conceptual Distinction — electron-pair geometry vs. molecular geometry.** These are frequently and consequentially confused. $\mathrm{NH_3}$ has *tetrahedral* electron-pair geometry (4 domains: 3 bonds + 1 lone pair) but *pyramidal* molecular geometry (only the 3 N and H atoms are "seen" in a structural description; the lone pair, while real and influential on the angle, does not count as a vertex of the named molecular shape). Getting this distinction right is essential for every worked structure in this Part.

**Table 9.1 — Complete geometry table, steric number 2–7**

| Steric number | Electron-pair geometry | Bond angles (ideal) |
|---:|---|---|
| 2 | Linear | $180°$ |
| 3 | Trigonal planar | $120°$ |
| 4 | Tetrahedral | $109.5°$ |
| 5 | Trigonal bipyramidal | axial–equatorial $90°$; equatorial–equatorial $120°$; axial–axial $180°$ |
| 6 | Octahedral | adjacent $90°$; opposite $180°$ |
| 7 | Pentagonal bipyramidal | axial–axial $180°$; axial–equatorial $90°$; equatorial–equatorial $72°$ |

![Parent geometries](figures/geometries/fig_vsepr_parent_linear.svg)
![Parent geometries](figures/geometries/fig_vsepr_parent_trigonal_planar.svg)
![Parent geometries](figures/geometries/fig_vsepr_parent_tetrahedral.svg)
![Parent geometries](figures/geometries/fig_vsepr_parent_trigonal_bipyramidal.svg)
![Parent geometries](figures/geometries/fig_vsepr_parent_octahedral.svg)
![Parent geometries](figures/geometries/fig_vsepr_parent_pentagonal_bipyramidal.svg)

**Figures 9.P1–9.P6.** The six parent electron-pair geometries corresponding to Table 9.1, drawn with a single consistent convention throughout this chapter: ordinary line = bond in the page plane, solid wedge = bond toward the viewer, hashed wedge = bond behind the plane. Every derived (lone-pair-containing) geometry in the rest of this Part is a modification of one of these six parents — worth returning to this set as a reference while working through §9.3–9.6.

### 9.3 Worked Structures — Steric Numbers 2–4

**$\mathrm{BeCl_2}$** ($AX_2$, steric number 2, sp): linear, $\mathrm{Cl-Be-Cl}$, $180°$, no lone pairs on Be — electron-pair geometry = molecular geometry (no lone pairs to distinguish them).

**$\mathrm{BF_3}$** ($AX_3$, steric number 3, sp²): trigonal planar, all F–B–F angles $120°$, no lone pair on B.

**$\mathrm{CH_4}$** ($AX_4$, steric number 4, sp³): tetrahedral, all H–C–H angles $109.5°$, no lone pairs on C.

**$\mathrm{NH_3}$** ($AX_3E_1$, steric number 4, sp³): tetrahedral electron-pair geometry, **pyramidal** molecular geometry; H–N–H angle compressed to $\approx107°$ (lone pair, wider angular spread per §9.1, compresses the bond–bond angle below the ideal $109.5°$).

**$\mathrm{H_2O}$** ($AX_2E_2$, steric number 4, sp³): tetrahedral electron-pair geometry, **bent/angular** molecular geometry; H–O–H angle compressed further, to $\approx104.5°$ — **two** lone pairs (rather than $\mathrm{NH_3}$'s one) produce two lone-pair–bond-pair repulsions plus one lone-pair–lone-pair repulsion (the single strongest repulsion type, §9.1), compressing the angle even more than in $\mathrm{NH_3}$.

> **Compare** — the ordering $\mathrm{CH_4\ (109.5°) > NH_3\ (107°) > H_2O\ (104.5°)}$ across isoelectronic-shell AXₘEₙ species with steric number 4 is the standard, frequently-tested worked demonstration that **more lone pairs on the same central atom monotonically compress the remaining bond angle** — and it directly follows from, rather than merely illustrates, the repulsion hierarchy of §9.1.

![Figure 9.3: CH4, NH3, H2O compression sequence](figures/geometries/fig_vsepr_ch4_nh3_h2o.svg)

**Figure 9.3.** All three species share tetrahedral electron-pair geometry (steric number 4), but molecular geometry and bond angle both change as lone pairs replace bond pairs: tetrahedral (0 LP) → pyramidal (1 LP) → bent (2 LP), with the H–X–H angle compressing at each step. This is the direct visual counterpart to the numerical trend stated above.

### 9.4 Worked Structures — Steric Number 5 (Trigonal Bipyramidal)

Steric number 5 is the first case where **not all positions are equivalent**: the trigonal bipyramid has two distinct site types — **axial** (two positions, $180°$ apart, each making $90°$ angles with all three equatorial positions) and **equatorial** (three positions, $120°$ apart from each other, $90°$ from both axial positions). An axial position experiences three $90°$ neighbour interactions; an equatorial position experiences only two $90°$ neighbour interactions (plus two $120°$ interactions, which are much weaker). **Equatorial sites are therefore the lower-repulsion, energetically preferred sites for a lone pair** (§9.1's hierarchy: fewer strong $90°$ neighbours to repel against) — matching Bent's rule (§8.5) exactly, since the equatorial orbital set also carries more s-character.

**$\mathrm{PCl_5}$** ($AX_5$, steric number 5, sp³d): trigonal bipyramidal, no lone pairs — electron-pair geometry = molecular geometry.

![Figure 9.4: PCl5 trigonal bipyramidal](figures/geometries/fig_vsepr_pcl5.svg)

**$\mathrm{SF_4}$** ($AX_4E_1$, steric number 5, sp³d): **see-saw** molecular geometry, lone pair equatorial (Figure 9.1). The observed F(axial)–S–F(axial) angle is compressed to $\approx173°$ (not the ideal $180°$) and the F(eq)–S–F(eq) angle to $\approx102°$ (not the ideal $120°$), both distortions caused by the single equatorial lone pair pushing the remaining bond pairs slightly away from their ideal positions.

![Figure 9.1: SF4 see-saw structure](figures/fig9_1_sf4_seesaw.svg)

**$\mathrm{ClF_3}$** ($AX_3E_2$, steric number 5, sp³d): **T-shaped** molecular geometry, both lone pairs equatorial (minimizing lone-pair–lone-pair repulsion by keeping them $120°$ apart rather than closer, and each lone pair minimizes its $90°$-neighbour count by being equatorial). Observed F–Cl–F angle $\approx87.5°$ (compressed from $90°$ by the two equatorial lone pairs).

![Figure 9.5: ClF3 T-shaped](figures/geometries/fig_vsepr_clf3.svg)

**$\mathrm{XeF_2}$** ($AX_2E_3$, steric number 5, sp³d): **linear** molecular geometry — with three lone pairs, all three occupy the equatorial positions (the only arrangement that places every lone pair in a low-repulsion equatorial site simultaneously), leaving the two bonded F atoms in the two axial positions, $180°$ apart. This is a clean, frequently-tested illustration that a highly lone-pair-rich steric-number-5 species reduces to a simple linear molecular geometry, precisely because the lone pairs, not the bonds, claim every equatorial site.

![Figure 9.6: XeF2 linear with 3 equatorial lone pairs](figures/geometries/fig_vsepr_xef2.svg)

**Figure 9.4–9.6.** All three drawn with the same axial(wedge/dash)/equatorial(in-plane) convention as the parent trigonal-bipyramidal geometry (Figure 9.P4), so the progressive lone-pair occupation of equatorial sites — 0 in PCl₅, 1 in SF₄, 2 in ClF₃, 3 in XeF₂ — is directly visually comparable across the series.

**$\mathrm{I_3^-}$ and $\mathrm{ICl_2^-}$** — both isoelectronic with $\mathrm{XeF_2}$ in electron-domain terms (central I with 3 lone pairs, 2 bonded atoms), both linear by the identical reasoning; dedicated figures and the three-centre–four-electron qualitative treatment are given in §9.7 alongside the other isoelectronic-shape examples.

### 9.5 Worked Structures — Steric Number 6 (Octahedral)

All six positions in an ideal octahedron are equivalent (unlike the trigonal bipyramid's axial/equatorial split) — but once a lone pair occupies one position, the remaining positions are no longer all equivalent relative to it (adjacent, $90°$ positions vs. the single opposite, $180°$ position).

**$\mathrm{SF_6}$** ($AX_6$, steric number 6, sp³d²): regular octahedral, no lone pairs.

![Figure 9.7: SF6 octahedral](figures/geometries/fig_vsepr_sf6.svg)

**$\mathrm{IF_5}$** ($AX_5E_1$, steric number 6, sp³d²): **square pyramidal** molecular geometry. The single lone pair pushes the four basal F atoms slightly toward it is not the case — rather, the four basal F–I–F angles compress to $\approx81.9°$ (from ideal $90°$) as they bend *away* from the lone pair, and the whole basal square puckers slightly away from the apical F.

![Figure 9.8: IF5 square pyramidal](figures/geometries/fig_vsepr_if5.svg)

**$\mathrm{XeF_4}$** ($AX_4E_2$, steric number 6, sp³d²): **square planar** molecular geometry (Figure 9.2). With two lone pairs, the lowest-repulsion arrangement places them **mutually trans** (opposite, $180°$ apart) — any other arrangement (e.g., $90°$ apart) would create a strong lone-pair–lone-pair repulsion in addition to the weaker lone-pair–bond-pair repulsions, so the *trans* placement is strongly preferred, leaving a perfectly symmetric, undistorted square planar array of F atoms.

![Figure 9.2: XeF4 square planar structure](figures/fig9_2_xef4_square_planar.svg)

**$\mathrm{ICl_4^-}$** — isoelectronic in domain terms with $\mathrm{XeF_4}$ (steric number 6, 2 lone pairs), also square planar by identical reasoning.

### 9.6 Worked Structures — Steric Number 7 and the XeF₆ Anomaly

**$\mathrm{IF_7}$** ($AX_7$, steric number 7, sp³d³): pentagonal bipyramidal, no lone pairs — five equatorial F atoms at $72°$ intervals, two axial F atoms at $180°$ to each other.

![Figure 9.9: IF7 pentagonal bipyramidal](figures/geometries/fig_vsepr_if7.svg)

**$\mathrm{XeF_6}$** ($AX_6E_1$, steric number 7): this is the standing exception worth flagging explicitly. Simple VSEPR reasoning (steric number 7, one lone pair) would predict a **pentagonal pyramidal** molecular geometry (lone pair occupying one of the seven positions of a pentagonal bipyramid). The molecule is experimentally close to, but not exactly, a **distorted octahedron** — the lone pair behaves as though it occupies a face of the octahedron rather than a distinct seventh vertex, and $\mathrm{XeF_6}$ is understood to exist as a rapidly-interconverting equilibrium mixture of several nearly-equivalent slightly-distorted-octahedral structures, with the lone pair's position best described as "stereochemically active but delocalized across several near-equivalent sites" rather than fixed at one sharp position. This contrasts with anions such as $\mathrm{[SbCl_6]^{3-}}$, $\mathrm{[TeCl_6]^{2-}}$, and $\mathrm{[ICl_6]^-}$, which *are* observed as essentially perfect, undistorted octahedra — in these cases the lone pair is described as **stereochemically inactive**, occupying a non-directional, spherically-symmetric $s$-type orbital that does not distort the surrounding octahedral geometry at all.

> **Exception** — $\mathrm{XeF_6}$ is the clearest single illustration in this entire chapter that simple VSEPR electron-counting, while an excellent first-approximation tool, does not always correctly predict the *exact* observed geometry — the lone pair's stereochemical activity (does it distort the shape, or not?) depends on subtle energetic factors beyond simple domain-counting, and must be checked against experimental structural data rather than assumed from the AXₘEₙ formula alone.

![Figure 9.10: XeF6 conventional model with explicit distortion caveat](figures/geometries/fig_vsepr_xef6_qualified.svg)

**Figure 9.10.** Deliberately boxed warning on the figure itself, not just in the caption: this sketch shows only the naive AX₆E steric-number-7 starting point. Treat every angle in this specific figure as illustrative, not as a claim about the real, fluxional structure.

### 9.7 Isoelectronic Species and Shape Transfer

Species with the same steric number and the same number of lone pairs on the central atom (i.e., the same $AX_mE_n$ formula) adopt the **same** molecular geometry, regardless of the specific identity of the central or terminal atoms — this is the direct practical payoff of the electron-domain-counting framework, and it is what makes VSEPR predictive rather than merely descriptive. $\mathrm{CO_2}$, $\mathrm{BeCl_2}$, $\mathrm{XeF_2}$, and $\mathrm{I_3^-}$ are all linear, despite belonging to entirely different parts of the periodic table and different bonding descriptions, precisely because each reduces to an $AX_2$ (steric number 2) or $AX_2E_3$ (steric number 5, but still linear per §9.4) domain count.

![Figure 9.11: XeO3 trigonal pyramidal](figures/geometries/fig_vsepr_xeo3.svg)

**$\mathrm{XeO_3}$** ($AX_3E_1$, steric number 4): trigonal pyramidal, directly analogous in domain-count terms to $\mathrm{NH_3}$ (§9.3) despite the very different atoms involved — the conventional localized Xe=O double-bond drawing is a bookkeeping representation, not a claim about the complete modern electronic structure (the same caveat already established for expanded-octet species generally, §2.7b).

![Figure 9.12: XeOF4 square pyramidal](figures/geometries/fig_vsepr_xeof4.svg)

**$\mathrm{XeOF_4}$** ($AX_5E_1$, steric number 6): square pyramidal, directly analogous to $\mathrm{IF_5}$ (§9.5) — the lone pair sits trans to the unique apical atom (here O rather than F), and the basal-plane bond angle compresses slightly away from the lone pair by the same mechanism established for $\mathrm{IF_5}$.

![Figure 9.13: I3- linear](figures/geometries/fig_vsepr_i3minus.svg)
![Figure 9.14: ICl2- linear](figures/geometries/fig_vsepr_icl2minus.svg)

**$\mathrm{I_3^-}$ and $\mathrm{ICl_2^-}$** — both isoelectronic with $\mathrm{XeF_2}$ in electron-domain terms (central atom with 3 lone pairs, 2 bonded atoms), both linear by the identical reasoning, and both describable qualitatively (beyond the simple Lewis picture) via a delocalized three-centre–four-electron bonding scheme across the linear framework — the anionic-species analogue of the neutral $\mathrm{XeF_2}$ case, worth recognizing as the same shape-transfer principle applied to a charged system.

### 9.8 Symmetry and Dipole Moment — the Direct Link to Part 5

This is the direct payoff of §5.6's dipole-moment shape-determination table, now with the underlying VSEPR structures fully derived: a molecule's calculated zero or non-zero dipole moment is a *consequence* of the molecular geometry established in this Part, via vector cancellation of the individual bond moments (and any lone-pair moments) — $\mathrm{XeF_4}$'s square planar, centrosymmetric structure guarantees $\mu=0$ by symmetry alone (every Xe–F bond moment is exactly cancelled by the opposite one), while $\mathrm{SF_4}$'s see-saw structure has no such cancelling symmetry, guaranteeing $\mu \ne 0$.

### 9.9 Limitations of VSEPR

1. **VSEPR predicts idealized shapes; real structures show systematic, explainable distortions** (already worked explicitly above — $\mathrm{SF_4}$'s $173°$/$102°$ angles, $\mathrm{ClF_3}$'s $87.5°$ angle, $\mathrm{IF_5}$'s $81.9°$ basal angles) driven by the electronegativity and multiple-bond effects layered on top of the basic domain count (§9.1's full hierarchy, not just the lone-pair-vs-bond-pair headline rule).
2. **It does not, by itself, explain *why* a lone pair might be stereochemically inactive in one case ($\mathrm{[SbCl_6]^{3-}}$) but active in a closely related case ($\mathrm{XeF_6}$)** — this requires additional orbital-energy reasoning beyond simple domain-counting (§9.6).
3. **It says nothing about bond order, magnetism, or overall stability** — VSEPR is a shape-prediction tool built on the same electron-pair-counting logic as VBT (Part 7), and inherits VBT's inability to address magnetic behaviour or genuinely delocalized bonding without external input from resonance (Part 6) or MOT (Part 10).
4. **Multiple-bond and electronegativity effects can compete, and the *net* observed distortion requires tracking both simultaneously** (§9.1's double-bond and electronegativity clauses) — a common error is applying only the lone-pair-vs-bond-pair rule and ignoring the additional, sometimes comparably large, multiple-bond or electronegativity contribution to a specific observed angle.

### Part 9 Summary

- VSEPR refines the cruder Sidgwick–Powell "count electron pairs" idea with an explicit repulsion hierarchy (lone pair–lone pair > lone pair–bond pair > bond pair–bond pair; double bond > single bond), grounded physically in how tightly each domain type is confined by its attracting nucleus/nuclei.
- Electron-pair geometry (from steric number alone) and molecular geometry (what is structurally observed, lone pairs excluded from the name) are frequently and consequentially different — NH₃ and H₂O are the standing worked illustrations.
- Steric numbers 5 and 6 introduce genuinely non-equivalent site types (axial/equatorial; and, once occupied, adjacent/opposite), with lone pairs preferentially occupying the lower-$90°$-neighbour-count sites — directly connected to Bent's rule (Part 8) via the shared underlying s-character mechanism.
- XeF₆ is the standing, explicitly-flagged exception where simple domain-counting does not cleanly predict the exact observed (fluxional, near-octahedral) structure — a genuine, not merely pedagogical, VSEPR limitation.
- Molecular geometry, established in this Part, is the direct structural input to the dipole-moment shape-determination framework of Part 5 — the two Parts are two ends of the same argument, not independent topics.

---

## Source Traceability — Part 9

| Source PDF | Pages | Material found | Destination | Status |
|---|---|---|---|---|
| `CHEMICAL_BONDING.pdf` | §3.6 (Valence Shell Electron Pair Repulsion Theory, full section, including Tables 3.3, 3.4 and Figures 3.4–3.7) | Sidgwick–Powell/Gillespie history, full repulsion hierarchy, steric-number worked geometry table, SF₄/ClF₃/XeF₂/PCl₃F₂/PCl₂F₃/XeO₂F₂/XeF₄/IF₅/XeF₆ structures with exact experimental bond angles, Bent's rule axial/equatorial mechanism, XeF₆ fluxional-structure discussion, [SbCl₆]³⁻/[TeCl₆]²⁻/[ICl₆]⁻ stereochemically-inactive lone pair comparison | §9.1–9.6, §9.9 | INCORPORATED |
| `Chemical Bonding (E)/5.pdf` | pp.9–12 (of 15, previously flagged) | Steric-number counting method (confirmatory of §8.4/§9.2, no new content beyond what CHEMICAL_BONDING.pdf already supplied) | §9.2 (confirmatory) | DUPLICATE — already covered |
| `cbvj.pdf` | p.40 (previously logged) | N(CH₃)₃/P(SiH₃)₃/N(SiH₃)₃ pyramidal-vs-planar comparison (back-bonding effect on geometry) | Cross-referenced from Part 2 | DUPLICATE — already covered |
| Independently derived | — | Table 9.1 (complete steric-number 2–7 geometry table), Worked structures §9.3–9.7 organized and cross-verified against standard bond-angle literature values | §9.2–9.7 | INCORPORATED, independently verified |

---

*Part 9 complete. Continuing to Part 10 (Molecular Orbital Theory).*
