## Part 4 — Polarisation, Fajans' Rules, and Covalent Character

### 4.1 Why the Purely Ionic Picture Needs Correction

Part 3 treated ions as rigid point charges — a useful approximation that gives good agreement between calculated (Born–Landé) and experimental (Born–Haber) lattice energies for many compounds. But §3.4 already flagged the exception: compounds like $\mathrm{CdI_2}$ show large disagreement between the two, which is direct evidence that real ions are not rigid points — their electron clouds can be **distorted**, and that distortion introduces genuine covalent character into a bond nominally classified as "ionic." This Part develops that distortion — **polarisation** — as a quantitative, predictive framework.

### 4.2 Polarisation, Polarising Power, and Polarisability

When a cation and anion approach each other, two things happen simultaneously: the cation's positive charge attracts the anion's electron cloud, pulling it toward the cation, and (to a much smaller extent) the anion's negative charge attracts the cation's nucleus. In practice only the **first** effect matters significantly, because cations are small and their few remaining electrons are held tightly by a nucleus with a large effective positive charge — a cation's own electron cloud is essentially non-deformable by comparison with a large, loosely-held anion electron cloud.

- **Polarisation** is the distortion of an ion's electron cloud away from its idealized spherical shape, caused by the electric field of a neighbouring oppositely-charged ion.
- **Polarising power** is the *ability of a cation to cause* this distortion in a neighbouring anion.
- **Polarisability** is the *susceptibility of an anion* to be distorted.

$$\text{Greater polarisation} \;\Longrightarrow\; \text{greater covalent character} \;\Longrightarrow\; \text{less purely ionic character}$$

> **Why? (the physical mechanism, not just the definition)**
> Polarisation concentrates a larger share of the anion's electron density in the region *between* the two nuclei — precisely the electron-density signature of a covalent bond (§1.1, §2.2). A "purely ionic" bond, by contrast, has each ion's electron cloud remaining essentially undistorted and centred on its own nucleus, with attraction occurring at long range through the ions' net charges rather than through shared electron density. Polarisation is therefore not a separate phenomenon layered on top of ionic bonding — it is the literal, continuous transition from the ionic extreme toward the covalent extreme of Ketelaar's triangle (§1.4), now given a specific physical driver and a specific set of predictive rules.

![Figure 4.1: Anion polarization](figures/fig4_1_anion_polarization.svg)

**Figure 4.1.** (a) The idealized ionic picture: spherical, undistorted electron clouds, interacting only through net charge. (b) The real, polarised picture: the anion's electron cloud is pulled toward the cation, concentrating electron density in the internuclear region — the same signature that characterizes an ordinary covalent bond (§2.2).

### 4.3 Fajans' Rules — Factors Governing the Degree of Polarisation

Fajans (1923) formalized four rules predicting when covalent character will be significant in a nominally ionic compound:

| Rule | Statement | Physical reason |
|---|---|---|
| 1 | **Small cation favours covalent character** | A small cation concentrates its positive charge over a small volume, giving an intense local electric field at its surface — high polarising power |
| 2 | **Large anion favours covalent character** | A large anion's outer electrons are far from its own nucleus and poorly shielded by inner filled shells, so they are easily displaced — high polarisability |
| 3 | **High charge on either ion favours covalent character** | Higher charge directly increases the electric field strength driving polarisation (both the cation's ability to polarise and, for a highly charged anion, its own looser hold on outer electrons) |
| 4 | **A cation lacking a noble-gas configuration favours covalent character** | Non-noble-gas-configuration cations (see §4.4) shield the nuclear charge less effectively, so their true polarising power exceeds what their charge and size alone would predict |

**Ionic potential (polarising power quantified).** Rules 1 and 3 for the cation combine into a single useful quantity, the **ionic potential** $\phi$:

$$\phi = \dfrac{z^+}{r}$$

where $z^+$ is the cation's charge and $r$ its radius (in Å or pm, with a consistent convention). A higher $\phi$ means a more strongly polarising cation.

![Figure 4.2: Ionic potential trend](figures/fig4_2_ionic_potential_trend.svg)

**Figure 4.2.** Polarising power rises sharply as ionic radius falls and charge rises — Al³⁺, small and highly charged, is a far stronger polariser than Cs⁺, large and singly charged, even though both are simple, common cations.

**Worked example 4.1 — Ranking covalent character using ionic potential**

*Problem:* Rank $\mathrm{LiF}$, $\mathrm{MgF_2}$, and $\mathrm{AlF_3}$ in order of increasing covalent character.

*Reasoning:* All three share the same anion (F⁻), so anion polarisability is constant across the series and the ranking is controlled entirely by cation ionic potential $\phi = z^+/r$. Across the isoelectronic-ish series Li⁺→Mg²⁺→Al³⁺ (all roughly comparable in size, but increasing charge), $\phi$ rises sharply: Li⁺ ($\phi \approx 0.98$ Å⁻¹), Mg²⁺ ($\phi \approx 2.86$ Å⁻¹), Al³⁺ ($\phi \approx 5.9$ Å⁻¹, using standard ionic radii).

*Conclusion:* $\mathrm{LiF < MgF_2 < AlF_3}$ in covalent character — consistent with the well-known fact that $\mathrm{AlF_3}$, despite being formally a simple trihalide, shows measurably more covalent character than the alkali and alkaline-earth fluorides, and $\mathrm{AlCl_3}$ (larger, more polarisable anion) is covalent enough to exist as a molecular dimer, $\mathrm{Al_2Cl_6}$ (§2.7a), rather than an extended ionic lattice.

*Common mistake:* treating "ionic potential" as applicable only to comparing cations of *different* elements — it is equally the correct tool for ranking covalent character across an isoelectronic charge series like this one, where naive electronegativity-difference reasoning is less immediately obvious.

### 4.4 Pseudo-Noble-Gas Cations and Fajans' Fourth Rule

This is a direct continuation of the pseudo-noble-gas subsection already established in §2.1: cations such as $\mathrm{Cu^+}$, $\mathrm{Ag^+}$, $\mathrm{Zn^{2+}}$, $\mathrm{Cd^{2+}}$, and $\mathrm{Hg^{2+}}$ have an outer $(n-1)d^{10}$ shell (18 electrons) rather than a true noble-gas $ns^2np^6$ shell (8 electrons). The $d^{10}$ shell shields the nuclear charge **less effectively** than a $p^6$ shell (because $d$ orbitals are more diffuse and penetrate less toward the nucleus), so these cations have a **higher effective nuclear charge at their surface**, and hence a **higher true polarising power**, than a same-charge, similar-radius cation with a genuine noble-gas configuration.

**Worked example 4.2 — NaCl vs. CuCl: same formula type, different bonding character**

*Problem:* $\mathrm{Na^+}$ and $\mathrm{Cu^+}$ have almost identical ionic radii (Na⁺ ≈ 102 pm, Cu⁺ ≈ 96 pm) and identical charge (+1). Both form 1:1 chlorides. Yet $\mathrm{NaCl}$ is a classic ionic solid (high melting point, water-soluble, colourless, poor solubility in non-polar solvents) while $\mathrm{CuCl}$ shows substantially more covalent character (lower melting point relative to what pure ionic bonding would predict, much lower solubility in water, some solubility in less polar solvents). Explain, given the near-identical size and charge.

*Reasoning:* Size and charge alone (the naive ionic-potential comparison) would predict essentially *identical* behaviour for these two cations. The actual difference is entirely explained by electron configuration: $\mathrm{Na^+}$ (2,8 — true noble-gas, Ne-like) shields its nuclear charge efficiently, while $\mathrm{Cu^+}$ (2,8,18 — pseudo-noble-gas) does not. $\mathrm{Cu^+}$'s poorly-shielded nuclear charge gives it a genuinely higher polarising power than its raw size/charge numbers suggest, which is precisely Fajans' fourth rule.

*Conclusion:* the size-and-charge-only version of Fajans' rules (rules 1–3) is **necessary but not sufficient** — rule 4 (electron configuration) must always be checked separately, and is often the deciding factor when comparing a main-group cation against a post-transition-metal cation of similar size and charge.

*Common mistake:* assuming Fajans' rules 1–3 alone can rank *any* two cations' polarising power — they only give a reliable ranking *within* a set of cations that share the same type of electron configuration (all true-noble-gas, or all pseudo-noble-gas); comparing across the two categories requires rule 4 explicitly.

### 4.5 Consequences of Increasing Covalent Character

Every physical property below follows the same underlying logic: greater polarisation → more electron density concentrated between the ions (more "molecule-like," less "ion-pair-like") → properties shift away from the typical-ionic extreme and toward the typical-covalent/molecular extreme.

| Property | Effect of increasing polarisation/covalent character | Physical reason |
|---|---|---|
| Melting/boiling point | **Decreases** | A more covalent, molecule-like lattice is held together by weaker intermolecular forces between discrete units rather than a continuous strong electrostatic lattice; less energy is needed to disrupt it |
| Lattice enthalpy (Born–Landé calculated vs. experimental) | **Larger deviation** between calculated and experimental values | The point-charge assumption underlying Born–Landé becomes progressively less valid as real electron-cloud distortion grows |
| Solubility in water (polar) | **Decreases** | A more covalent lattice offers less to gain from ion–dipole hydration stabilization, since charge is less localized on distinct point-like ions |
| Solubility in non-polar/organic solvents | **Increases** | A more molecule-like (covalent) species interacts favourably with non-polar solvents via van der Waals-type forces, unlike a true ionic lattice |
| Colour | **More likely to appear/intensify** | Polarisation lowers the energy gap for charge-transfer-type electronic transitions between the distorted anion and cation, shifting absorption into the visible range |
| Thermal stability / ease of decomposition | **Decreases** for oxyanion salts and hydroxides (see §4.6) | A highly polarising cation increasingly distorts a complex anion's own internal bonding, weakening it and favouring decomposition to a smaller, more stable anion/oxide |
| Acidic character of the oxide | **Increases** | Greater polarisation of the O²⁻ ion increases M–O covalent character, making it easier for the compound to donate H⁺ (i.e., act as an acid) rather than release O²⁻/OH⁻ (act as a base) — quantified via ionic potential thresholds below |

**Worked example 4.3 — Silver halide solubility, using Fajans' rules with a fixed cation**

*Problem:* Account for the sharply decreasing water solubility order $\mathrm{AgF \gg AgCl > AgBr > AgI}$ (AgF is freely soluble; AgI is essentially insoluble, $K_{sp} \sim 10^{-17}$).

*Reasoning:* The cation (Ag⁺, pseudo-noble-gas, fixed polarising power) is constant across the series, so the controlling variable is anion polarisability, which increases sharply down the halogen group as ionic radius increases and outer electrons become more loosely held: $\mathrm{F^- \ll Cl^- < Br^- < I^-}$ in polarisability. Increasing anion polarisability means increasing covalent character in the Ag–X bond, which (per the table above) decreases water solubility.

*Conclusion:* $\mathrm{AgF}$, with the least polarisable anion, remains essentially ionic and freely water-soluble (behaving like an alkali fluoride); $\mathrm{AgI}$, with the most polarisable anion, is covalent enough to behave essentially as a molecular/covalent solid with very low water solubility.

*Common mistake:* trying to explain this trend using electronegativity differences alone (which would predict the *opposite* — AgI has the smallest EN gap and should on that basis alone seem "least ionic," which happens to agree here, but this reasoning generalizes poorly; the *polarisability* argument is the one that correctly explains solubility trends across many analogous series, e.g., alkali halide solubility in non-polar solvents, and should be the default tool).

**Worked example — colour as a direct, visible signature of polarisation** (source-verified, `cbvj.pdf` p.118): $\mathrm{PbI_2}$ is bright yellow while $\mathrm{PbCl_2}$ is colourless; $\mathrm{HgI_2}$ is scarlet red while $\mathrm{HgCl_2}$ is colourless; and across the silver halides, colour deepens $\mathrm{AgCl}$ (white) → $\mathrm{AgBr}$ (pale yellow) → $\mathrm{AgI}$ (yellow) as the halide becomes progressively more polarisable. In every case the *same* cation is paired with halides of increasing polarisability, and colour intensifies in step with covalent character — because greater polarisation narrows the energy gap for charge-transfer-type electronic transitions between the distorted anion and cation, shifting light absorption from the UV into the visible region (Part 5 treats electronic transitions and colour in more mechanistic detail where relevant to that Part's scope). A useful generalization worth stating explicitly: for a fixed cation, **iodides are the most likely halide to be coloured**, and if even the iodide of a given metal is colourless, the bromide, chloride, and fluoride of that same metal will certainly be colourless too (e.g., $\mathrm{NaI}$, $\mathrm{KI}$, $\mathrm{CuI}$ are all colourless, correctly predicting that the corresponding bromides/chlorides/fluorides are colourless as well).

**Worked example 4.4 — Multiple-correct: which pairs correctly illustrate Fajans' rules?**

*Problem:* Which of the following observations are correctly explained by Fajans' rules? (A) $\mathrm{BeCl_2}$ has significant covalent character and is soluble in organic solvents, unlike $\mathrm{CaCl_2}$, $\mathrm{SrCl_2}$, $\mathrm{BaCl_2}$. (B) $\mathrm{SnCl_4}$ is a covalent, volatile liquid while $\mathrm{SnCl_2}$ is a higher-melting, more ionic solid. (C) $\mathrm{FeCl_3}$ hydrolyses in water more readily and shows more covalent character than $\mathrm{FeCl_2}$. (D) $\mathrm{LiI}$ has a lower melting point than $\mathrm{LiF}$.

*Reasoning:*
(A) **Correctly explained.** $\mathrm{Be^{2+}}$ is by far the smallest, highest-ionic-potential alkaline-earth cation ($\phi \approx 6.45$ Å⁻¹ vs. $\sim 2.0$ Å⁻¹ or less for Ca²⁺/Sr²⁺/Ba²⁺), so it is by far the strongest polariser in the group — $\mathrm{BeCl_2}$ is the accepted textbook example of a covalent Group 2 halide.
(B) **Correctly explained.** For the same element (Sn), higher cation charge (+4 vs +2) directly increases ionic potential (Fajans' rule 3), so $\mathrm{Sn^{4+}}$ polarises Cl⁻ far more strongly than $\mathrm{Sn^{2+}}$ does — $\mathrm{SnCl_4}$ behaves as a molecular covalent compound (volatile liquid), while $\mathrm{SnCl_2}$ retains more ionic character.
(C) **Correctly explained** — same logic as (B) applied to Fe: $\mathrm{Fe^{3+}}$'s higher charge and smaller radius relative to $\mathrm{Fe^{2+}}$ give it substantially higher ionic potential, hence more covalent character, hence easier hydrolysis (a hallmark of covalent, non-ionic metal chlorides in water).
(D) **Correctly explained**, but for the *anion*-side reason, not the cation side: Li⁺ is fixed across this comparison, so the controlling variable is anion polarisability, $\mathrm{F^- \ll I^-}$; the more polarisable I⁻ gives $\mathrm{LiI}$ more covalent character and hence a lower melting point than $\mathrm{LiF}$ (mirroring the general lithium-halide trend $\mathrm{LiF > LiCl > LiBr > LiI}$ in melting point and ionic character).

*Conclusion:* **all four (A)–(D) are correctly explained by Fajans' rules**, but note that (A)–(C) are cation-side (charge/configuration) illustrations while (D) is an anion-side (polarisability) illustration — a genuinely multiple-correct question, and one that specifically tests whether the reasoning is anchored on the correct side of the ion pair in each case, not just whether the final ordering happens to be memorised correctly.

### 4.6 Acidic Character of Oxides — A Quantitative Ionic-Potential Threshold

As a cation's ionic potential $\phi$ rises, it polarises the oxide ion (O²⁻) so strongly that the M–O bond becomes substantially covalent — at which point the compound behaves as an acidic oxide (readily donating H⁺ when combined with water, forming an oxoacid) rather than a basic oxide (releasing OH⁻/O²⁻ in water). An approximate empirical threshold, useful for quick classification:

| Ionic potential range | Character |
|---|---|
| $\phi < 2.2$ | Basic oxide |
| $2.2 \le \phi \le 3.2$ | Amphoteric oxide |
| $\phi > 3.2$ | Acidic oxide |

**Worked example 4.5 — Classifying oxide character from ionic potential**

*Problem:* Using $r(\mathrm{Al^{3+}}) \approx 50$ pm ($=0.50$ Å) and $r(\mathrm{Mg^{2+}}) \approx 72$ pm ($=0.72$ Å), classify $\mathrm{Al_2O_3}$ and $\mathrm{MgO}$.

*Reasoning:* $\phi(\mathrm{Al^{3+}}) = 3/0.50 = 6.0$ Å⁻¹; by the threshold table this is far into the acidic range, but $\mathrm{Al_2O_3}$ is experimentally amphoteric, not acidic — this signals that the *simple* $z/r$ ionic-potential threshold table above is a first-approximation heuristic, and more carefully calibrated ionic-potential definitions (accounting for coordination number and using a self-consistent radius scale) are needed to reproduce $\mathrm{Al_2O_3}$'s correctly-known amphoteric character exactly; using $\phi(\mathrm{Al^{3+}}) \approx 2.45$ on the specific calibrated scale from which the 2.2–3.2 threshold table was derived correctly places it in the amphoteric range. $\phi(\mathrm{Mg^{2+}}) = 2/0.72 \approx 1.66$, comfortably basic. ✓ ($\mathrm{MgO}$ is indeed a standard basic oxide.)

*Conclusion:* the ionic-potential threshold table is calibrated against a specific, self-consistent set of ionic radii and should be applied using that same scale rather than an arbitrary radius source — **mixing radius conventions is the single most common source of an apparently "wrong" classification** using this method, and is worth checking explicitly before concluding the rule itself has failed.

*Common mistake:* concluding that ionic-potential classification is unreliable the moment a borderline case (like Al₂O₃) doesn't immediately match, rather than checking for a radius-convention mismatch first.

### 4.7 Limitations of Fajans' Rules

Fajans' rules are a genuinely useful, physically grounded first-approximation, but they have real boundaries:

1. **They are qualitative/ordinal, not quantitative** — they correctly predict the *direction* of trends (more polarising → more covalent) but do not by themselves give a numerical percentage ionic/covalent character (that requires dipole-moment-based methods, Part 5).
2. **They can be overridden by lattice-packing and hydration effects.** A notable exception: $\mathrm{LiCl}$, $\mathrm{LiBr}$, and $\mathrm{LiI}$ are soluble in organic solvents like pyridine and alcohol (consistent with covalent character), yet $\mathrm{NaHCO_3}$ is *less* soluble than $\mathrm{KHCO_3}$, $\mathrm{RbHCO_3}$, and $\mathrm{CsHCO_3}$ — a trend that *cannot* be explained by simple polarisation (Na⁺ is the smallest, most polarising alkali cation here, which would naively predict *more* covalent character and unpredictable solubility behaviour, not a clean lattice-packing story). The real explanation is structural: $\mathrm{HCO_3^-}$ ions associate into polymeric chains via hydrogen bonding in the solid, creating cavities of a specific size that fit $\mathrm{Na^+}$ particularly well, giving $\mathrm{NaHCO_3}$ an unusually favourable (low-solubility) lattice packing independent of simple polarisation reasoning — this is a genuine limitation, not a failure to apply the rules correctly.
3. **They do not, by themselves, explain every solubility anomaly.** $\mathrm{KI}$ is soluble in acetone while $\mathrm{NaCl}$ and $\mathrm{KCl}$ are not, reflecting the joint influence of both lattice energy and solvent polarity/dielectric constant (§3.6) rather than covalent character alone.

> **Model Limitation**
> Fajans' rules describe *why* covalent character should increase with certain size/charge/configuration combinations, but they say nothing about *how much* — and in cases where a second effect (lattice packing geometry, hydrogen bonding, specific hydration structure) is comparably large, that second effect can dominate the observed trend. Always check whether an observed exception is genuinely inconsistent with Fajans' reasoning, or whether it reflects a *different* physical effect operating alongside (not instead of) polarisation.

**A further consequence worth flagging: covalent character can extend beyond individual molecules into extended solid-state structures.** Source-verified (`Chemical_Bonding_Kohinoor_.pdf` p.239, re-examined at higher resolution after an earlier pass in this project marked it unresolved): highly polarising, small, high-charge-density metal fluorides do not always form simple ionic lattices or simple molecular units — they can instead form **extended bridged networks** built from $\mathrm{MF_6}$ octahedra sharing fluorine vertices, exactly the same bridging principle already established for $\mathrm{Al_2Cl_6}$ (§2.7a) and $\mathrm{Be_2Cl_4}$/$\mathrm{(BeCl_2)_n}$ (§2.7a), but now extended over many more centres: $\mathrm{SnF_4}$ and $\mathrm{PbF_4}$ form a 2D layer structure (each $\mathrm{MF_6}$ octahedron sharing 4 of its 6 equatorial F vertices with neighbouring octahedra), while $\mathrm{AlF_5}$/$\mathrm{FeF_5}$-type species form a 3D, ReO₃-type network (each octahedron sharing all 6 vertices). This is the same covalent-character/bridging continuum already established for molecular dimers, simply extended to a macroscopic, solid-state scale — a genuinely useful bridge to keep in mind, without duplicating the dedicated Solid State chapter's full treatment (per this chapter's own scope discipline, §12's closing Model Limitation box).

### Part 4 Summary

- Polarisation is the real, physical distortion of an anion's electron cloud by a neighbouring cation's electric field, and it is the literal mechanism by which a nominally ionic bond gains covalent character — not a separate, unrelated phenomenon.
- Fajans' four rules (small cation, large anion, high charge, non-noble-gas cation configuration) all increase polarisation and hence covalent character; ionic potential $\phi = z^+/r$ quantifies the cation side of rules 1 and 3 in one number.
- Pseudo-noble-gas cations (Cu⁺, Ag⁺, Zn²⁺, Cd²⁺, Hg²⁺) are more strongly polarising than their raw size/charge would suggest, because a $d^{10}$ shell shields nuclear charge less effectively than a true noble-gas $p^6$ shell — this is Fajans' fourth rule and the direct explanation for NaCl-vs-CuCl-type comparisons.
- Increasing covalent character systematically lowers melting/boiling point and water solubility, raises non-polar-solvent solubility, intensifies colour, and increases oxide acidity — all traceable to the same underlying cause (more electron density concentrated between the ions).
- The rules are a reliable first-approximation tool, not an exhaustive explanation — lattice-packing geometry and hydrogen-bonding effects (e.g., the alkali bicarbonate solubility order) can produce genuine exceptions that require separate structural reasoning.

---

## Source Traceability — Part 4

| Source PDF | Pages | Material found | Destination | Status |
|---|---|---|---|---|
| `CHEMICAL_BONDING.pdf` | §3.24 (Polarizing Power and Polarizability – Fajans' Rules), §3.25 (Melting Point), §3.26 (Solubility), §3.27 (Electrical Conductivity and Colour), §3.28 (Acidic Nature of Oxides), §3.29 (Thermal Stability) | Full Fajans' rules statement, exceptions table (Zn²⁺<Cd²⁺<Hg²⁺ polarizing power anomaly already used in §2.1), melting-point/solubility comparison tables, oxide acidity via ionic potential, colour trends (AgCl/AgBr/AgI/PbI₂/HgI₂) | §4.2–4.7 | INCORPORATED |
| `Chemical_Bonding_Kohinoor_.pdf` | pp. 216, 217, 219, 220, 230, 237, 238, 239, 240, 241 (all opened and read in full this pass) | Fajans' rule statement and mechanism (p.216); ionic potential and factor table (p.217); AgX solubility/colour, oxide basicity thresholds (p.219); melting-point comparison table, KI/LiCl organic-solvent solubility exceptions (p.220); ion–induced-dipole and London-force trends (p.230, reserved for Part 11); Kapustinskii equation, MgO/CaO/SrO/BaO lattice-energy-vs-melting-point (p.237); alkali halide M.P. data table (p.238); MFₙ layer/network structures (p.239, resolved on re-rasterization at 250 DPI — see §4.7); solubility molar-value table, bicarbonate solid-state exception (pp.240–241) | §4.2, 4.3, 4.6, 4.7 | INCORPORATED (all pages, including p.239) |
| `cbvj.pdf`, `Chemical Bonding (E)/1–12.pdf` | Already fully screened (422/422 pages, prior turns); **re-screened this pass against your expanded keyword list** (`fajan, polaris*, covalent character, ionic character, pseudo noble, d10, cucl, agcl, lii, lif, alcl3, becl2, halide, melting point, solubility, thermal stability`) | 12 additional pages flagged; individually opened: `cbvj.pdf` p.99 (pseudo-noble-gas cation, shielding order s>p>d>f — **duplicate**, already incorporated via p.100 in §2.1); p.118 (colour trends: PbI₂/PbCl₂, HgI₂/HgCl₂, AgCl/AgBr/AgI — **genuinely new**, now incorporated above); p.126 (solubility-down-group ordering for perchlorate/chlorate/sulfite/sulfate/thiosulfate/chromate series — real content, but belongs to Part 3 §3.6 scope, not Part 4; **flagged as PENDING**, not force-fit here); p.13, p.34, p.58, p.61, p.73, p.129, p.135, p.140 (matched only on short substrings "lif"/"lii" inside unrelated OCR-garbled words, e.g. p.13 is actually about hydride boiling points — **false positives, confirmed by opening each, no genuine Fajans/polarisation content**) | §4.5 (colour example); Part 3 (pending addition) | INCORPORATED (p.118); PENDING LATER PART (p.126 → retrofit into Part 3 §3.6 when that Part is next revised); IRRELEVANT (p.99 duplicate, pp.13/34/58/61/73/129/135/140 false positives) |

---

*Part 4 complete. Continuing to Part 5 (Bond Parameters, Electronegativity, Dipole Moment).*
