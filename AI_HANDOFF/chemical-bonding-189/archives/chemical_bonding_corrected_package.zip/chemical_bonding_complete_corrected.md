# Chemical Bonding and Molecular Structure
### JEE Advanced Reference Chapter — Synergic Bond Chemistry

---

## Part 1 — Fundamental Ideas of Chemical Bonding

### 1.1 Why Do Atoms Form Bonds?

Isolated atoms are, in almost every case, higher in energy than the same atoms joined together in a molecule or a lattice. A chemical bond forms **only when the resulting arrangement has lower total energy than the separated atoms** — nothing more mystical than that. "Stability" in chemistry is not a vague virtue; it is a quantitative statement about energy: a bonded system is stable relative to the free atoms if

$$E_{\text{molecule}} < E_{\text{atom A}} + E_{\text{atom B}}$$

and the amount by which the molecule's energy is lower is released to the surroundings as the **bond dissociation energy**. If no arrangement of two approaching atoms can lower the total energy, no bond forms — this is why, for instance, two helium atoms do not combine (Part 10 will show exactly why, in molecular-orbital terms).

**Why energy actually drops.** As two atoms approach, two effects compete:

- **Attraction**: each nucleus is attracted to the *other* atom's electron cloud, and the two electron clouds can rearrange to concentrate charge density between the nuclei, which simultaneously attracts both nuclei toward that region.
- **Repulsion**: the two positively charged nuclei repel each other, and, as the electron clouds begin to overlap, electron–electron repulsion also rises.

At large separation, attraction dominates and the potential energy of the system falls as the atoms approach. At very short separation, repulsion (nuclear–nuclear, and Pauli-principle electron–electron repulsion as filled orbitals begin to overlap) rises steeply and dominates. Bond formation is simply the statement that there exists an intermediate separation at which the net energy is at a **minimum** — lower than at infinite separation.

> **Why? (physical reason, not just a label)**
> A covalent bond lowers energy specifically because concentrating electron density in the internuclear region allows *both* nuclei to be attracted to the same electrons simultaneously — this is a genuine quantum mechanical lowering of kinetic and potential energy relative to each electron being localized on a single atom (formalized later as the bonding molecular orbital, Part 10). It is not correct to say "atoms bond to complete their octet" as a causal mechanism — octet completion is a bookkeeping *pattern* seen in stable molecules, not the physical driving force. The driving force is always energy lowering; the octet rule is a useful empirical shortcut for predicting *when* that lowering typically occurs for second-period elements (Part 1.7 below).

### 1.2 The Potential Energy Curve

Plotting potential energy of the two-atom system against internuclear distance $r$ produces a curve with a characteristic shape (illustrated below for a diatomic molecule such as H₂):


![Figure 1.1: Potential energy vs internuclear distance for a diatomic molecule](figures/fig1_1_pe_curve.svg)

**Figure 1.1.** Potential energy of a two-atom system as a function of internuclear distance $r$. At large $r$, $E \to 0$ (free atoms, taken as the reference). As the atoms approach, attractive interactions (nucleus–electron) lower the energy until a minimum is reached at $r = r_0$. At separations smaller than $r_0$, nucleus–nucleus repulsion and electron-cloud (Pauli) repulsion rise steeply, so $E$ increases sharply. This handwritten-source diagram (confirmed against `cbvj.pdf`, p. 1) labels the same three features — attractive branch, bond-formation point, and dissociation limit — using the shorthand "attraction > repulsion" for the descending branch and "B.L." (bond length) at the minimum; the terminology used throughout this chapter (E₀, r₀, Dₑ) is the standard JEE-Advanced notation for the same quantities.

Key quantities read off this curve:

| Symbol | Name | Meaning |
|---|---|---|
| $r_0$ | Equilibrium bond length | Internuclear distance at the energy minimum; the experimentally measured bond length |
| $E_0$ | Bond energy (well depth) | Energy of the molecule at $r_0$ relative to free atoms (negative — the molecule is lower in energy) |
| $D_e$ | Bond dissociation energy | Magnitude of energy required to separate the bonded atoms back to $r = \infty$; numerically $D_e = -E_0$ measured from the minimum to the zero-energy asymptote |

**Why the curve has exactly this shape — cause and effect, not just description:**

- *Descending branch (large to intermediate $r$):* As $r$ decreases from infinity, the electron of one atom begins to feel the attraction of the other nucleus. This attractive potential energy term scales approximately as $-1/r$ at long range, so energy falls continuously as the atoms approach — this is the region where "attraction exceeds repulsion."
- *Rising branch (small $r$):* Once the electron clouds begin to interpenetrate significantly, two repulsive effects switch on and grow much faster than the attractive term: (i) direct nucleus–nucleus Coulomb repulsion, which scales as $+1/r$ and diverges as $r \to 0$, and (ii) Pauli exclusion-driven repulsion between electrons of like spin in overlapping filled orbitals, which rises exponentially at short range. Because these repulsive terms grow faster than the attractive term as $r$ decreases, there must be some $r_0$ at which the net force (the slope of the curve) is zero — this is the equilibrium bond length, and it is a genuine energy minimum, not an arbitrary "resting point."
- *At $r = r_0$ exactly:* $\dfrac{dE}{dr} = 0$. This is the mathematical statement of mechanical equilibrium — the attractive and repulsive forces exactly balance. Any small displacement from $r_0$ (compression or stretching) raises the energy, which is why bonds resist both compression and extension and why molecules vibrate about $r_0$ rather than sitting statically at it (at any $T > 0$ K, thermal energy populates vibrational levels above the bottom of the well).

> **JEE Advanced Insight**
> A stronger bond (larger $|D_e|$) is associated with a *narrower, deeper* well and, generally, a *shorter* $r_0$ — because greater orbital overlap simultaneously increases the attractive stabilization and requires the repulsive wall to be encountered at smaller $r$. This is why bond order, bond length, and bond enthalpy are correlated quantities used together in ordering questions (Part 5 and Part 13): higher bond order ⇒ shorter bond length ⇒ higher bond dissociation energy, for a given pair of atoms.

> **Common Trap**
> Do not say a molecule forms "because atoms want to be stable." Atoms have no intent. Always cite the actual energy comparison: *this* arrangement has lower potential energy than free atoms because of *this* specific attractive interaction, so energy is released (bond formation is exothermic) and the reverse process (bond breaking) requires that same amount of energy to be supplied (endothermic). This bond-formation/bond-breaking energy sign convention — exothermic formation, endothermic dissociation — is worth fixing early, since sign errors here propagate into Born–Haber cycle problems in Part 3.

### 1.3 Conditions Required for Bond Formation

For two atoms (or ions) to form a stable bond, the following must hold simultaneously:

1. **Net energy lowering.** As shown above, there must exist some $r_0$ at which total energy is below the separated-atom reference.
2. **Symmetry/orbital compatibility** (developed fully in Part 7 and Part 10): the interacting orbitals must be able to overlap constructively — they must have appropriate relative orientation and comparable energy. Two atoms can approach to short range and still fail to bond if no orbital combination gives net stabilization (this is exactly the He–He case, Part 10.12).
3. **Correct electron count in the interacting orbitals.** A bonding interaction is only net-stabilizing if bonding orbitals are preferentially filled over antibonding ones — this becomes quantitative via bond order in Part 10, but qualitatively it is why filled-shell atoms (noble gases) resist bonding: any stabilization from a bonding combination is cancelled by destabilization from the antibonding combination that must also be filled.

### 1.4 Classification of Chemical Interactions

Bonding interactions are conventionally divided by the *mechanism* through which the attractive, energy-lowering interaction is achieved. It is essential to see these not as unrelated categories memorised separately, but as different strategies for solving the same underlying problem — how to arrange electrons and nuclei so that electron density sits where it can attract multiple nuclei at once, or how ions can be held in a lattice by pure electrostatics.

| Interaction | Mechanism | Typical partners | Order of magnitude (strength) |
|---|---|---|---|
| **Ionic (electrovalent)** | Complete transfer of one or more electrons from an electropositive atom to an electronegative atom; resulting ions held by electrostatic (Coulombic) attraction | Metal + non-metal, large electronegativity difference | Strong (100s of kJ mol⁻¹, lattice energy) |
| **Covalent** | Sharing of an electron pair between two nuclei, with electron density concentrated between them | Non-metal + non-metal, similar electronegativity | Strong (typically 150–950 kJ mol⁻¹ per bond) |
| **Coordinate (dative)** | Sharing of an electron pair contributed entirely by one atom (the donor) to an empty orbital on the other (the acceptor) | Lewis base + Lewis acid | Comparable to an ordinary covalent bond once formed |
| **Metallic** | Delocalisation of valence electrons over a lattice of positive ion cores; electrons are not localized to any one atom or bond | Metal + metal (or one metal) | Variable — from weak (alkali metals) to very strong (transition metals, e.g., W) |
| **Hydrogen bond** | Electrostatic + partial covalent attraction between a H atom covalently bonded to a highly electronegative atom (N, O, F) and a lone pair on another electronegative atom | H–N, H–O, H–F donors; N, O, F, and occasionally Cl acceptors | Intermediate (10–40 kJ mol⁻¹) — much weaker than covalent/ionic, much stronger than van der Waals |
| **van der Waals (intermolecular)** | Dipole–dipole, dipole–induced dipole, and instantaneous dipole–induced dipole (London dispersion) attractions between otherwise complete molecules | Any molecules, polar or non-polar | Weak (0.4–40 kJ mol⁻¹) |

Three points about this table deserve explicit emphasis, because JEE Advanced regularly tests them:

**(a) These are idealized extremes, not watertight boxes.** Ketelaar's triangle (Figure 1.2) is the classical way of representing this: place ionic, covalent, and metallic bonding at the three corners of a triangle. Compounds with bonding predominantly of one type sit near a corner; compounds intermediate between two types lie along an edge; compounds with some character of all three lie inside the triangle.

![Figure 1.2: Ketelaar's triangle](figures/fig1_2_ketelaar_triangle.svg)

**Figure 1.2.** The three idealized bond types sit at the corners; real compounds occupy the interior or edges according to their actual electron distribution. This is a qualitative classification device, not a quantitative scale — position within the triangle is not read off a numeric axis, only compared relatively (e.g., "closer to the ionic corner than X" is a meaningful statement; "at coordinate (0.3, 0.5)" is not, at this level of treatment).

Lithium chloride, for example, is conventionally classified as ionic, yet its solubility in ethanol (a non-polar-ish organic solvent) is evidence of appreciable covalent character — a purely ionic solid would not dissolve appreciably in a non-aqueous, low-polarity solvent. This graded, not binary, character of bonding is the conceptual basis for Fajans' rules in Part 4.

**(b) The three "pure" categories arise from the electropositive/electronegative character of the participating atoms.**
- If one atom is strongly electropositive (tends to lose electrons) and the other strongly electronegative (tends to gain electrons), electron transfer is favourable → ionic bond.
- If both atoms are electronegative (both want to gain, neither wants to lose), electrons are shared rather than transferred → covalent bond.
- If both atoms are electropositive (neither wants to hold electrons tightly), valence electrons delocalize over the whole assembly of atoms rather than localizing on any one atom or bond → metallic bond.

**(c) Hydrogen bonding and van der Waals forces are *intermolecular*, not primary bonds.** They act *between* already-complete molecules (or between separate parts of one large molecule) rather than holding a single molecule's own atoms together, and they are treated in full generality in Part 11. They are listed here only to complete the classification picture — a common JEE trap is to describe hydrogen bonding as a "type of covalent bond," which is imprecise: it is predominantly electrostatic in character with a partial covalent/orbital-overlap contribution, and it is categorically weaker than a normal covalent bond (roughly one-tenth the energy).

> **Exam Method**
> When a question asks you to classify the bonding in an unfamiliar compound, do not guess from the compound's name. Check (i) the electronegativity difference between the constituent atoms (large gap → ionic character is significant); (ii) whether both atoms are non-metals of comparable electronegativity (→ covalent); (iii) whether the species is a metal or alloy (→ metallic); and only then, if the compound is molecular, ask whether hydrogen bonding or van der Waals forces are relevant to its *physical* properties (melting/boiling point, solubility) as distinct from the *primary* bonding holding each molecule together.

### 1.5 Electronic Theories of Valency — Historical and Conceptual Basis

Before quantum mechanics offered a rigorous account of bonding, chemists built increasingly refined **electronic theories** to rationalize why atoms combine in fixed, predictable ratios. The unifying insight behind all of them is that **valency is an electronic phenomenon**: the number of bonds an atom forms, and the type of bond it forms, is governed by the number and arrangement of electrons in its outermost (valence) shell — not by any property of the nucleus directly.

The progression of these ideas (detailed with full worked treatment in Part 2) is:

1. **Kossel's electrostatic (ionic) theory (1916)** — explains bond formation between markedly electropositive and electronegative atoms via complete electron transfer, driven by both atoms attaining a noble-gas electron configuration.
2. **Lewis's electron-pair (covalent) theory (1916)** — explains bond formation between atoms of similar electronegativity via *sharing* rather than transfer of an electron pair, again typically resulting in a noble-gas-like outer shell for each atom.
3. **Sidgwick–Powell theory (1940)** and its refinement, **Gillespie's VSEPR theory (1957)** — extend the electron-counting idea from *how many* bonds form to *what shape* the resulting molecule adopts, based on the number of electron pairs (bonding and lone) around the central atom (Part 9).
4. **Valence bond theory** and **molecular orbital theory** (Parts 7, 8, 10) — the quantum-mechanical treatments that explain *why* electron sharing lowers energy in the first place, and that correctly predict properties (such as the paramagnetism of O₂) that purely electron-counting theories cannot.

### 1.6 The Octet Concept — Origin and Physical Meaning

**Observation:** The noble gases (He, Ne, Ar, Kr, Xe, Rn) exist as stable, monatomic, chemically inert species under ordinary conditions. Every other main-group element, left to itself, is reactive.

**Physical reason:** The noble gases (other than He) have a filled outer $ns^2np^6$ configuration — eight electrons in the valence shell. A filled valence shell corresponds to a particularly low-energy, high-symmetry electron distribution: all the orbitals of that principal shell accessible at moderate energy are completely occupied, so there is no accessible orbital of comparable energy into which an electron could be promoted to form a new bond, and no partially filled orbital available to accept a shared pair either. This is why noble gases are largely unreactive — not because "eight is a magic number," but because a filled shell leaves no low-energy pathway for further orbital overlap to lower the system's energy.

**Consequence — the octet rule as a predictive heuristic:** Main-group atoms other than noble gases tend to gain, lose, or share electrons until they too attain eight electrons in the valence shell (a share of eight, some "owned" outright and some "borrowed" via bonding), because doing so mimics the low-energy, filled-shell arrangement of the nearest noble gas. Hydrogen and helium are the standard exception even within this rule — they are stable with only **two** electrons (a filled $1s$ shell), so H is said to obey a **duplet rule** rather than an octet rule.

$$\text{Na} \rightarrow \text{Na}^+ + e^- \qquad (\text{Na}^+: 1s^22s^22p^6, \text{ same configuration as Ne})$$
$$\text{Cl} + e^- \rightarrow \text{Cl}^- \qquad (\text{Cl}^-: 1s^22s^22p^63s^23p^6, \text{ same configuration as Ar})$$

> **Why? (going one level deeper)**
> It would be circular to say "Na loses an electron because it wants to look like Ne." The real reason is energetic: removing the single loosely-held $3s^1$ electron from Na costs a *first* ionization energy of only 496 kJ mol⁻¹ (this electron is well-shielded from the nucleus by the filled $n=1,2$ shells and sits in a higher shell), whereas removing a *second* electron from Na⁺ would mean breaking into the full $2p^6$ shell — an enormously higher ionization energy (~4560 kJ mol⁻¹) because that electron is both closer to the nucleus and no longer shielded by an outer electron. The "octet" outcome is simply what falls out of this large jump in successive ionization energies at shell boundaries; it is the ionization-energy data, not an abstract preference for eight electrons, that is the underlying cause.

### 1.7 Limitations of the Octet Rule

The octet rule is a highly useful first approximation but is broken in several well-defined classes of compounds — each of which is a standing JEE Advanced topic in its own right, developed fully in Part 2.7–2.9 and Part 8:

1. **Electron-deficient species** — central atoms with fewer than four valence electrons (e.g., Be, B) cannot reach an octet even using all available electrons for bonding: $\mathrm{BeCl_2}$ has only 4 electrons around Be; $\mathrm{BF_3}$ has only 6 around B.
2. **Expanded-octet (hypervalent) species** — elements of period 3 and beyond can accommodate more than eight electrons around the central atom, because an energetically accessible extra orbital set becomes available once the atom carries partial positive charge in a bond (the modern explanation, avoiding uncritical reliance on 3d-orbital participation, is developed in Part 2.9 and Part 12): $\mathrm{PF_5}$ (10 electrons around P), $\mathrm{SF_6}$ (12 around S).
3. **Odd-electron (free-radical) species** — molecules with an odd total electron count cannot possibly pair all electrons into octets: $\mathrm{NO}$ (11 valence electrons), $\mathrm{ClO_2}$, $\mathrm{NO_2}$.
4. **Species whose ground-state bonding is not well described by simple electron pairing at all** — $\mathrm{O_2}$ is the classic case: the Lewis structure $\mathrm{O=O}$ (all electrons paired) predicts diamagnetism, but $\mathrm{O_2}$ is experimentally **paramagnetic**, with two unpaired electrons. This single fact was historically decisive evidence that a more complete theory (molecular orbital theory, Part 10) was required beyond simple electron-pair counting — this is developed fully in Part 10.12, where it is shown that MOT correctly predicts two unpaired electrons in degenerate $\pi^*$ orbitals.

> **Exception**
> Even though the octet rule fails in the cases above, it remains the *correct default assumption* for second-period elements C, N, O, F when they are not otherwise electron-deficient or odd-electron species — the failures above are the identifiable exceptions, not evidence that the rule is generally unreliable. A working rule for JEE: expanded octets are essentially never seen for strictly second-period central atoms (C, N, O, F) bonded only to ordinary substituents, precisely because period-2 atoms have no accessible 3-level orbitals to expand into.

### 1.8 Part 1 Summary

- A bond forms when, and only when, some internuclear separation gives lower total energy than infinitely separated atoms; this is captured completely by the potential-energy curve (Figure 1.1), whose minimum defines $r_0$ (bond length) and whose depth defines $D_e$ (bond dissociation energy).
- Bonding interactions are classified by mechanism (ionic, covalent, coordinate, metallic, hydrogen-bonding, van der Waals) but form a continuum (Ketelaar's triangle), not sharply separated categories.
- The octet rule is an energetically-grounded heuristic — rooted in the very large jump in ionization/electron-gain energies at filled-shell boundaries — not an independent law of nature, and it has well-characterized, systematically explainable exceptions (electron-deficient, expanded-octet, odd-electron, and O₂-type paramagnetic species).

---


## Part 2 — The Lewis–Kossel Approach and Lewis Structures

### 2.1 Kossel's Electrostatic (Ionic) Theory

Walther Kossel (1916) proposed the first systematic electronic account of ionic bonding: atoms of markedly electropositive elements lose electrons, atoms of markedly electronegative elements gain electrons, and the two resulting ions are held together purely by **electrostatic (Coulombic) attraction**, with both ions attaining a stable noble-gas electron configuration in the process.

**Worked illustration — NaCl formation** (verified against `CHEMICAL_BONDING.pdf`, §3.3):

$$\text{Na} \; (1s^22s^22p^63s^1) \longrightarrow \text{Na}^+ \; (1s^22s^22p^6) + e^-$$
$$\text{Cl} \; (1s^22s^22p^63s^23p^5) + e^- \longrightarrow \text{Cl}^- \; (1s^22s^22p^63s^23p^6)$$

Na⁺ now has the electron configuration of Ne; Cl⁻ now has the configuration of Ar.

**True noble-gas configuration vs. pseudo-noble-gas configuration.** Na⁺ (electron count 2,8) and Cl⁻ (2,8,8) attain a genuine noble-gas configuration — the outermost shell has the $ns^2np^6$ pattern of an actual noble gas (Ne and Ar respectively). This is not the only way a cation can reach a filled-subshell outer shell, however. Post-transition-metal cations such as Zn²⁺, Cd²⁺, Hg²⁺, and Cu⁺ instead attain a **pseudo-noble-gas configuration**: an outermost shell of the form $(n-1)d^{10}$ — 18 electrons rather than 8 — because the $d$ subshell fills before ionization removes only the outer $s$ electrons. For example, Cu⁺ (2,8,18) and Zn²⁺ (2,8,18) both have an outer 18-electron shell, structurally analogous to Na⁺'s outer 8-electron shell but *not identical to any actual noble gas's electron count*.

> **Why this distinction matters (not just terminology)**
> A filled $d^{10}$ shell shields the nuclear charge far less effectively than a filled $p^6$ shell does, because $d$ orbitals are more diffuse and penetrate less toward the nucleus. Consequently, a cation with a pseudo-noble-gas configuration has a **higher effective nuclear charge felt at its surface** than a same-charge, similar-size cation with a true noble-gas configuration — which makes it a **more strongly polarizing** ion (Fajans' rules, Part 4). This is the direct explanation for an experimentally observed and frequently tested trend: covalent character increases sharply down the sequence $\mathrm{ZnCl_2 < CdCl_2 < HgCl_2}$ even though ionic radius is also increasing (which by itself, per Fajans' rules, ought to *decrease* polarizing power) — the pseudo-noble-gas shielding effect dominates over the simple size trend. The same reasoning explains why $\mathrm{AgCl}$, $\mathrm{AgBr}$, and $\mathrm{AgI}$ (Ag⁺: pseudo-noble-gas, 2,8,18,18) show markedly more covalent character than the corresponding alkali-metal halides. The electrostatic attraction between Na⁺ and Cl⁻ is the "bond." Extended over a crystal, every Na⁺ is surrounded by six Cl⁻ and vice versa (developed fully with radius-ratio rules and lattice energy in Part 3).

**Worked illustration — CaCl₂ formation:** Ca (outer configuration $4s^2$) is electropositive and loses *two* electrons — one to each of two separate Cl atoms — because a single Cl atom can accept only one electron (it needs only one more electron to complete its octet):

$$\text{Ca} \longrightarrow \text{Ca}^{2+} + 2e^- \qquad 2\,\text{Cl} + 2e^- \longrightarrow 2\,\text{Cl}^-$$

giving the ionic formula unit $\mathrm{Ca^{2+}(Cl^-)_2}$.

> **Why? (going deeper on "why lose electrons at all")**
> Kossel's theory only *works* when the energy released by the electron-gaining atom (electron-gain enthalpy, favourable/exothermic for most non-metals) plus the electrostatic lattice-formation energy exceeds the energy that must be *supplied* to strip the electron off the electropositive atom (ionization energy, always endothermic). The theory itself does not derive this energy balance — that derivation is the Born–Haber cycle, covered fully in Part 3.9 — but Kossel's contribution was to correctly identify *which* electron configuration each ion should end up with (the noble-gas configuration) and *why* that configuration is preferred (Part 1.6).

### 2.2 Lewis's Electron-Pair (Covalent) Theory

G. N. Lewis (1916) extended electronic bonding theory to atoms of similar electronegativity, where neither atom has a strong enough pull on electrons to justify complete transfer. Instead, **a pair of electrons is shared between the two atoms**, with each atom contributing one electron to the shared pair (for an ordinary covalent bond) — the shared pair is simultaneously attracted to both nuclei, which is the source of the bonding stabilization (Part 1.1, and rigorously in Part 7 and Part 10).

**Lewis symbols.** In a Lewis symbol, only the *valence* (outermost-shell) electrons of an atom are shown, as dots arranged around the elemental symbol — core electrons are omitted because they do not participate in ordinary bond formation.

```
   H·          ·N·         :O:          :F:
                  ··          ··          ···
                                             ·
(1 valence e⁻) (5 valence e⁻, N)  (6 valence e⁻, O)  (7 valence e⁻, F)
```

**Formation of Cl₂ (single covalent bond):**

$$:\!\overset{\displaystyle ..}{\text{Cl}}\!\cdot \;+\; \cdot\!\overset{\displaystyle ..}{\text{Cl}}\!: \;\longrightarrow\; :\!\overset{\displaystyle ..}{\text{Cl}}\!:\!\overset{\displaystyle ..}{\text{Cl}}\!:$$

Each Cl atom starts with seven valence electrons (one unpaired). By sharing one electron each, the shared pair is counted toward *both* atoms' octets, so each Cl atom now has access to eight electrons (six as three lone pairs it owns outright, plus a share of the bonding pair) — both atoms simultaneously attain an argon-like outer-shell electron count. In valence-bond line notation this is written $\mathrm{Cl-Cl}$, where the line represents the shared electron pair.

**Formation of CCl₄ (four single bonds):** Carbon has four valence electrons, one short of... actually four short of an octet; each Cl is one electron short. Carbon shares one electron with each of four Cl atoms, forming four C–Cl bonds; carbon attains an octet (4 bonding pairs, fully "shared-in"), and each Cl attains an octet (3 lone pairs + 1 bonding pair).

**Formation of NH₃ — and the origin of the lone pair.** Nitrogen has five valence electrons; three are used to form three N–H bonds (each H contributing its one electron), and **two electrons remain on N, unshared** — this pair is called a **lone pair**. The existence of this "left-over," non-bonding pair on N is the single most important structural fact about ammonia: it is precisely the presence of this lone pair that (a) is available for coordinate bond donation (Section 2.4) and (b) distorts the H–N–H bond angle away from the ideal tetrahedral value, as developed quantitatively in Part 9.

**Double and triple bonds.** When four electrons (two pairs) are shared between one pair of atoms, the result is a **double bond**; when six electrons (three pairs) are shared, a **triple bond**:

$$\mathrm{O=C=O} \quad (\text{CO}_2,\ \text{two C=O double bonds}) \qquad \mathrm{N \equiv N} \quad (\text{N}_2,\ \text{one triple bond})$$

> **Why more shared pairs = shorter, stronger bond**
> Each additional shared pair adds further electron density concentrated in the internuclear region, which increases the net nucleus–electron attraction pulling the two nuclei together. This is why bond order (Part 5, Part 10) correlates directly with bond length (shorter with higher order) and bond enthalpy (higher with higher order) for a given pair of atoms — it is not a separate empirical fact but a direct consequence of "more shared electron density between the nuclei → more attraction → shorter equilibrium separation and deeper energy well."

### 2.3 Comparing Kossel and Lewis: One Underlying Idea

Both theories are driven by the *same* underlying principle — atoms rearrange their valence electrons to approach a noble-gas-like configuration, because (Part 1.6) a filled valence shell is a low-energy electron arrangement. They differ only in *mechanism*:

| | Kossel (ionic) | Lewis (covalent) |
|---|---|---|
| Electron movement | Complete transfer, one atom to another | Sharing, pair remains associated with both atoms |
| Driving asymmetry | Large electronegativity difference | Small/no electronegativity difference |
| Resulting species | Discrete cations and anions, held by long-range electrostatics | Discrete molecules, held by short-range, directional shared pairs |
| Physical state consequence | High-melting crystalline lattices | Often low-melting molecular solids, liquids, or gases |

### 2.4 The Coordinate (Dative) Covalent Bond

An ordinary covalent bond has each atom contributing one electron to the shared pair. A **coordinate (dative) bond** is a covalent bond in which **both** electrons of the shared pair originate from a single atom (the **donor**, which must possess a lone pair) while the other atom (the **acceptor**) contributes an empty orbital.

**Once formed, a coordinate bond is indistinguishable from an ordinary covalent bond** — it differs only in its *origin*, not in its final electronic character, bond length, or bond strength. This point is worth stating explicitly because it is a frequently tested conceptual distinction (see the "Important Conceptual Distinctions" note at the end of this Part).

**Worked illustration — NH₄⁺ formation** (Figure 2.1):

$$\mathrm{NH_3} + \mathrm{H^+} \longrightarrow \mathrm{NH_4^+}$$

![Figure 2.1: Coordinate bond formation in NH4+](figures/fig2_1_nh4_coordinate_bond.svg)

**Figure 2.1.** Ammonia already possesses a complete octet on N (three N–H bonds + one lone pair). When it reacts with H⁺ (which has an empty $1s$ orbital and no electrons of its own to contribute), the lone pair on N is donated wholesale into that empty orbital, forming a new N–H bond. **All four N–H bonds in NH₄⁺ are experimentally identical** in length and strength — there is no way to distinguish, in the product ion, which N–H bond was "formed by sharing" and which was "formed by donation." This is the clearest possible demonstration that coordinate and ordinary covalent bonds are the *same kind of bond* once formed.

**Worked illustration — NH₃·BF₃ adduct.** BF₃ has only six electrons around B (electron-deficient, Section 2.7) and therefore an empty $2p$ orbital on B. Ammonia's lone pair on N is donated into this empty orbital:

$$\mathrm{H_3N:} + \mathrm{BF_3} \longrightarrow \mathrm{H_3N \to BF_3}$$

The arrow notation $\mathrm{N \to B}$ (rather than a plain line) is conventionally used specifically to flag the *donor–acceptor origin* of a bond where it is pedagogically useful to do so (for instance, to track formal charge — N becomes formally $+1$ and B formally $-1$ in this adduct) — but the arrow is a notational convenience, not a statement that the resulting bond is physically different from a normal covalent bond.

**Further coordinate-bond examples** (all confirmed structurally consistent with `CHEMICAL_BONDING.pdf`, §3.3):

$$\mathrm{PCl_5 + Cl^- \longrightarrow [PCl_6]^-} \qquad \mathrm{SbF_5 + F^- \longrightarrow [SbF_6]^-} \qquad \mathrm{H_2O + H^+ \longrightarrow H_3O^+} \qquad \mathrm{F^- + BF_3 \longrightarrow [BF_4]^-}$$

In each case, a species with a lone pair (Cl⁻, F⁻, H₂O) donates that pair into an empty/expandable orbital on an electron-deficient or hypervalent-capable acceptor.

> **JEE Advanced Insight**
> The requirement for coordinate bonding is *not* "one atom must be a metal" — it is simply: one participant needs an available lone pair (Lewis base) and the other needs an accessible empty orbital (Lewis acid). This is exactly the Lewis acid–base framework, and every coordinate-bond example above is a Lewis acid–base reaction. Recognizing a species as electron-deficient (BF₃, AlCl₃) or as possessing accessible empty $d$-type orbitals in an expandable valence shell (PCl₅, SbF₅) immediately tells you it can act as a Lewis acid and accept a coordinate bond.

### 2.5 Formal Charge

**Definition and derivation.** When a Lewis structure is drawn, it is useful to check how the electron count around each atom compares to that atom's *original* number of valence electrons as a free atom — this bookkeeping quantity is the **formal charge**:

$$\text{Formal charge} = V - N - \frac{B}{2}$$

where $V$ = number of valence electrons in the free (neutral) atom, $N$ = number of non-bonding (lone-pair) electrons on that atom *in the structure as drawn*, and $B$ = number of bonding electrons around that atom (i.e., 2 × number of bonds to that atom) *in the structure as drawn*.

**Physical meaning.** Formal charge answers the question: *if bonding electrons were shared exactly equally between the two bonded atoms (ignoring real electronegativity differences), what net charge would be left on this atom?* It is explicitly **not** the same as the real, physically measured partial charge on an atom (which depends on the actual electronegativity difference and is always smaller in magnitude than a full formal-charge unit for typical covalent bonds), and it is **not** the same as oxidation number (which assigns *all* bonding electrons to the more electronegative atom, the opposite extreme assumption). All three — formal charge, oxidation number, and real partial charge — are different bookkeeping conventions for the same electrons, useful for different purposes; conflating them is a common and heavily tested error (see the Important Conceptual Distinctions note below).

**Worked example 2.1 — Formal charges in CO**

*Problem:* Determine the formal charge on each atom in carbon monoxide, CO, given the correct Lewis structure has a C≡O triple bond with one lone pair on each atom.

*Concept tested:* Formal charge calculation combined with correct multiple-bond/lone-pair placement to satisfy total valence electron count.

*Reasoning:* Total valence electrons = C(4) + O(6) = 10. A single C–O bond with three lone pairs on each atom would need $2 + 6 + 6 = 14$ electrons — more than the 10 available, so that candidate fails immediately. If C and O are joined by a triple bond (6 bonding electrons) with one lone pair on each (2 + 2 = 4 non-bonding electrons), total = $6 + 4 = 10$ ✓, matching the valence electron count exactly, and giving both atoms an octet (C: 1 lone pair (2e⁻) + share of 6 bonding e⁻ = 8; O: same).

*Structure:* $:\!\mathrm{C}\!\equiv\!\mathrm{O}\!:$ — one lone pair on C, one lone pair on O, connected by a triple bond.

*Formal charge on C:* $V = 4$ (C is in Group 14), $N = 2$ (one lone pair), $B = 6$ (triple bond = 6 bonding electrons around C). FC(C) $= 4 - 2 - 6/2 = 4 - 2 - 3 = -1$.

*Formal charge on O:* $V = 6$, $N = 2$ (one lone pair), $B = 6$. FC(O) $= 6 - 2 - 3 = +1$.

*Verification:* Sum of formal charges $= -1 + 1 = 0$, correctly matching the overall neutral charge on the CO molecule. ✓

*Conclusion:* CO carries formal charges of $-1$ on C and $+1$ on O — despite oxygen being the more electronegative atom. This is chemically unusual (formal negative charge is normally expected on the more electronegative atom, see below) and is exactly why CO's dipole moment is anomalously small (0.112 D, far smaller than expected from the C–O electronegativity difference): the electronegativity-driven bond dipole (pointing C→O, i.e., negative end toward O) is substantially cancelled by the formal-charge-driven contribution (negative end toward C), as detailed quantitatively in Part 5.

*Common mistake:* Students frequently draw CO with a double bond ($\mathrm{O=C}$, mimicking CO₂) and two lone pairs on O, one on C. Checking the count: double bond = 4 bonding e⁻, O with 2 lone pairs (4 e⁻), C with 1 lone pair (2 e⁻); total $= 4+4+2 = 10$ ✓ — the electron count works, but the octet check fails on carbon: C has 2 lone-pair electrons plus a share of only 4 bonding electrons $= 6$ electrons, **not an octet**. This structure is therefore incorrect, and checking octet completion on *every* atom (not just electron count matching) is the necessary second check.

**Worked example 2.2 — Formal charges and structure selection for SO₄²⁻**

*Problem:* Sulfate has two common candidate Lewis structures — one with all four S–O bonds as single bonds (each O bearing formal charge $-1$ and S bearing $+2$), and one with two S=O double bonds and two S–O single bonds (giving lower formal charges). Which is preferred, and why does this matter?

*Reasoning:* All-single-bond structure: S has 4 bonds, 0 lone pairs → $B=8, N=0, V=6$ → FC(S) $= 6-0-4 = +2$. Each O (singly bonded, 3 lone pairs) → $B=2,N=6,V=6$ → FC(O) $=6-6-1=-1$. Sum $= +2 + 4(-1) = -2$ ✓ matches overall charge.

Two-double-bond structure: S now has 6 bonds' worth of bonding electrons ($2\times2 + 2\times1$ pairs $=$ 4 bonds, 2 of which are double) — S: $B = 12$ (4 bonds, 2 double + 2 single $= 2+2+1+1=6$ bond pairs $\times 2 = 12$ electrons), $N=0$ → FC(S) $=6-0-6=0$. The two doubly-bonded O: $B=4,N=4$ → FC $=6-4-2=0$. The two singly-bonded O: FC $=-1$ as before. Sum $= 0+0+0-1-1=-2$ ✓.

*Which is "more reasonable"?* The general guideline (not an absolute rule) is that **the structure with formal charges closest to zero, and with any negative formal charge residing on the most electronegative atom, is generally the lower-energy, more representative structure.** By this guideline the two-double-bond structure (S formal charge 0, only two O atoms bearing $-1$) looks preferable to the all-single-bond structure (S formal charge $+2$).

*Exception — where formal-charge minimization alone is insufficient:* Modern bonding descriptions of sulfate (and phosphate, perchlorate, and similar oxoanions of period-3 central atoms) show that invoking S=O double bonds via naive $d$-orbital participation over-emphasizes covalent double-bond character; the S–O bonds are better described as strongly polarized, largely single bonds with significant ionic/electrostatic character, and the experimentally observed S–O bond length in $\mathrm{SO_4^{2-}}$ (all four bonds equal by resonance/symmetry, ~149 pm) is shorter than a "pure" single S–O bond would be, but this shortening is now attributed more to electrostatic contraction and $\pi$-type delocalization without requiring literal $d$-orbital hybrid participation (developed fully in Part 12, Hypervalency). **The correct practical takeaway for structure-drawing purposes:** minimizing formal charge is a good heuristic for choosing among candidate Lewis structures, but it is a bookkeeping tool, not proof of the literal bonding picture — Part 12 draws this distinction explicitly.

> **Common Trap**
> "Minimize formal charge" is not the same as "always maximize bond multiplicity." For period-2 central atoms (C, N, O), you cannot exceed an octet regardless of what formal-charge minimization might suggest — the octet ceiling is a harder constraint than formal-charge minimization, because no accessible low-energy orbital exists beyond the octet for these atoms (Part 1.7). Formal-charge minimization is only used to choose *among structures that already satisfy the octet/valence rules appropriate to that atom*.

### 2.6 Rules for Drawing a Correct Lewis Structure

Followed in this fixed order, these rules reliably generate the correct structure for the great majority of species:

1. **Count total valence electrons.** Sum the group-valence-electron count of every atom; for a polyatomic ion, **add** one electron per unit of negative charge, or **subtract** one electron per unit of positive charge.
2. **Identify the skeletal (connectivity) framework.** The least electronegative atom is usually central (except H, which is never central, since it can form only one bond); atoms are arranged around it, generally as symmetrically as the formula allows. **Tie-break rule:** if two candidate atoms have the same electronegativity, the atom capable of the **higher valency** (more bonds) is taken as central, since it can accommodate more surrounding atoms.
3. **Place a single bond (shared pair) between every pair of connected atoms**, and subtract these electrons from the total.
4. **Complete octets on terminal atoms first** (using the remaining electrons as lone pairs), then place any leftover electrons on the central atom.
5. **If the central atom does not yet have an octet, convert one or more terminal-atom lone pairs into an additional shared pair** (forming a double or triple bond) so that the central atom's octet is completed without violating any terminal atom's octet.
6. **Calculate formal charges** on every atom and check that they sum to the overall charge on the species.
7. **Where more than one valid structure is possible, select the structure(s) with formal charges closest to zero, with negative formal charge preferentially on the more electronegative atom(s)** — and where multiple equally valid structures exist that differ only in the position of a multiple bond or lone pair, recognize this as **resonance** (developed fully in Part 6) rather than treating one structure as uniquely "correct."
8. **Two further formal-charge preference rules, beyond simple magnitude minimization:** (i) a structure with unlike formal charges on *adjacent* (bonded) atoms is generally more favourable than one with the same-magnitude charges held far apart, because opposite charges close together provide additional electrostatic stabilization; (ii) a structure with **like formal charges on adjacent atoms is strongly disfavoured**, since it places two centres of the same-sign charge directly next to one another, which is electrostatically destabilizing.

**Worked example 2.6 — Applying the full formal-charge hierarchy to SCN⁻ (thiocyanate)**

*Problem:* Three candidate skeletal arrangements/bond patterns are possible for the linear thiocyanate ion, $\mathrm{SCN^-}$: (a) $\mathrm{[S=C=N]^-}$, (b) $\mathrm{[S-C\equiv N]^-}$, the single-bond-on-S placement, (c) $\mathrm{[S\equiv C-N]}$ triple-bond-on-S placement. Which is the best representation?

*Reasoning — apply the rules in order:*

Total valence electrons $= \mathrm{S}(6)+\mathrm{C}(4)+\mathrm{N}(5)+1\ (\text{for the } -1\text{ charge}) = 16$. Two charge-balanced candidate structures survive an initial octet/electron-count check:

| Structure | S | C | N | Formal charges (S, C, N) | Sum |
|---|---|---|---|---|---|
| (a) $\mathrm{S=C=N}$, S with 2 lone pairs, N with 2 lone pairs | double bond, 2 lone pairs | 2 double bonds, no lone pair | double bond, 2 lone pairs | $(0,\ 0,\ -1)$ | $-1$ ✓ |
| (b) $\mathrm{S-C \equiv N}$, S with 3 lone pairs, N with 1 lone pair | single bond, 3 lone pairs | 1 single + 1 triple bond, no lone pair | triple bond, 1 lone pair | $(-1,\ 0,\ 0)$ | $-1$ ✓ |

(A third candidate, $\mathrm{S \equiv C - N}$ with a triple bond on S, gives formal charges $(+1, 0, -2)$ — already ruled out at the magnitude-minimization step, rule 7, since $\pm 2$ is larger than the $\pm 1$ achieved by (a) and (b).)

*Applying the hierarchy:* Structures (a) and (b) are tied on formal-charge magnitude (both have one atom at $\pm1$, the rest at $0$), so the decision falls to **placement**: rule 7 requires the negative formal charge to sit on the more electronegative atom. Nitrogen (EN $\approx 3.0$) is more electronegative than sulfur (EN $\approx 2.6$), so structure (a) — with the $-1$ formal charge on N rather than S — is the better-motivated, lower-energy structure.

*Conclusion:* $\mathrm{[S=C=N]^-}$, with formal charges S(0), C(0), N($-1$), is the dominant contributing resonance structure of thiocyanate. This matches thiocyanate's well-established coordination chemistry, in which it binds metal centres through *both* S and N depending on the metal ("ambidentate" behaviour), but with electron density concentrated more on the N end, consistent with structure (a) being the major contributor.

*Common mistake:* Stopping as soon as *a* charge-balanced structure is found, without checking whether an alternative placement of the same bond pattern lowers the energy further by putting negative formal charge on the more electronegative atom.

**Worked example 2.3 — Full structure derivation for NO₃⁻**

*Problem:* Derive the Lewis structure of the nitrate ion.

*Step 1:* Valence electrons $= \mathrm{N}(5) + 3\times\mathrm{O}(6) + 1 (\text{for the } -1 \text{ charge}) = 5+18+1=24$.

*Step 2:* N is central (less electronegative, and there is only one N to be "the center" of three O atoms).

*Step 3:* Three N–O single bonds use $3\times2=6$ electrons; $24-6=18$ remain.

*Step 4:* Distribute the remaining 18 electrons as lone pairs on the three O atoms: 3 lone pairs (6 electrons) on each O, using all 18. Each O now has an octet (2 bonding + 6 non-bonding). N, however, has only 3 bonding pairs $=6$ electrons around it — short of an octet.

*Step 5:* Convert one O lone pair into a second N–O bond (making one N=O double bond) to complete N's octet: N now has 4 bonding pairs $= 8$ electrons ✓.

*Step 6 — formal charges:* N ($V=5,N=0,B=8$): FC $=5-0-4=+1$. Doubly-bonded O ($V=6,N=4,B=4$): FC$=6-4-2=0$. Each singly-bonded O ($V=6,N=6,B=2$): FC$=6-6-1=-1$. Sum $=+1+0-1-1=-1$ ✓ matches overall charge.

*Step 7 — resonance:* Because any one of the three O atoms could equally well be the doubly-bonded one, there are **three equivalent canonical structures** (Figure 2.2), and the true structure is the resonance hybrid of all three — **not** any single one of them, and **not** a molecule that "rapidly flips" between the three (Part 6 makes this distinction rigorous). Experimentally, all three N–O bonds in $\mathrm{NO_3^-}$ are equal in length (~124 pm, intermediate between a typical N–O single bond ~140 pm and N=O double bond ~120 pm), consistent with a bond order of $4/3$ for each N–O bond — direct structural evidence for the resonance-hybrid picture over any single canonical form.

![Figure 2.2: Resonance structures of NO3-](figures/fig2_2_no3_resonance.svg)

*Common mistake:* Drawing all three N–O bonds as double bonds "to be safe" — this would put 10 electrons around N ($4\times2$ bonding), violating the octet rule, and is a frequent JEE error caused by not tracking the total valence-electron count rigorously against rule 1.

### 2.7 Exceptions to the Octet Rule — Full Structural Treatment

**(a) Electron-deficient species (incomplete octet).** Atoms with fewer than four valence electrons cannot reach eight even when all are used for bonding.

- **BeCl₂:** Be has 2 valence electrons, forms 2 bonds, 0 lone pairs → only 4 electrons around Be. Linear, $\mathrm{Cl-Be-Cl}$.
- **BF₃:** B has 3 valence electrons, forms 3 bonds → only 6 electrons around B. Trigonal planar. Because B has an empty $2p$ orbital, BF₃ is a strong Lewis acid and readily accepts a coordinate bond (Section 2.4).
- **AlCl₃:** analogous to BF₃ in the monomer, though it dimerizes to $\mathrm{Al_2Cl_6}$ via bridging chlorine coordinate bonds to satisfy Al's octet (developed in Part 12, electron-deficient/multicentre bonding).

> **Exception — electron-deficient monomers are frequently not the isolated form found in practice.** A genuinely electron-deficient species will often dimerize or polymerize specifically to relieve that deficiency, using a bridging atom's lone pair to form a coordinate bond back to the deficient centre. $\mathrm{BeH_2}$ and $\mathrm{BeCl_2}$ are monomeric, linear, $sp$-hybridized only in the gas phase at high temperature; $\mathrm{Be_2H_4}$ and $\mathrm{Be_2Cl_4}$ dimers, and eventually polymeric chain $(\mathrm{BeH_2})_n$ / $(\mathrm{BeCl_2})_n$ in the solid state, use bridging H or Cl atoms whose lone pair (or, for the 3-centre–2-electron H bridge, whose bonding electron pair) is shared with the electron-deficient Be centre so that Be's local octet is completed. $\mathrm{AlCl_3}$ behaves identically, forming $\mathrm{Al_2Cl_6}$. **This bridge-bonding structural detail is developed rigorously — including the distinct 3-centre–2-electron and 3-centre–4-electron bonding pictures — in Part 12 (Electron-Deficient Bonding)**; it is flagged here only so that "BeCl₂/AlCl₃ are electron-deficient" is not mistaken for "BeCl₂/AlCl₃ exist as isolated electron-deficient monomers under ordinary conditions," which they generally do not.
>
> A related, subtler refinement applies to BF₃ itself: although the simple Lewis picture shows an empty $2p$ orbital on B with three ordinary B–F single bonds, each F atom in fact partially donates a lone pair into that empty orbital (**back bonding**, $2p_\pi\text{–}2p_\pi$), giving the B–F bonds partial double-bond character and *reducing* — without eliminating — B's real electron deficiency.

![Figure 2.4: BF3 back bonding](figures/fig2_4_bf3_backbonding.svg)

**Figure 2.4.** One fluorine's filled $2p$ orbital (green) donates sideways into boron's empty $2p$ orbital (dashed outline), a $2p_\pi\text{–}2p_\pi$ interaction identical in geometric character to the lateral $\pi$ overlap developed fully in Part 7. This happens, to a smaller extent, at all three B–F bonds simultaneously (only one is highlighted here for clarity) — the effect is real and measurable (shortened B–F bonds relative to a pure-single-bond estimate) but partial, not a complete conversion to a fixed double bond.

B remains a genuine Lewis acid (it still readily accepts a fourth, fully dative bond from F⁻ to give $\mathrm{BF_4^-}$, Section 2.4); back bonding only means the *pure*, textbook-simple electron-deficiency picture slightly overstates how reactive/acidic B truly is, not that BF₃ should be redrawn as an ordinary complete-octet molecule. This is precisely why the Lewis-acid strength of the boron trihalides follows $\mathrm{BF_3 < BCl_3 < BBr_3 < BI_3}$ — the *opposite* order to what electronegativity of the halogen alone would predict — because back-bonding is strongest for the best-matched, most compact donor orbital (F's $2p$, matching B's $2p$ almost exactly in size) and weakens down the halogen group as the donor orbital becomes larger and more poorly matched in size to B's $2p$ orbital ($2p_\pi\text{–}3p_\pi$ for Cl, $2p_\pi\text{–}4p_\pi$ for Br, $2p_\pi\text{–}5p_\pi$ for I). Back bonding and its structural consequences are treated in full generality in Part 9.

**Worked example 2.7 — Diborane, B₂H₆: electron deficiency resolved by 3-centre–2-electron bridge bonds**

*Problem:* $\mathrm{B_2H_6}$ has the molecular formula suggesting six ordinary B–H bonds, yet boron (3 valence electrons each) and hydrogen (1 valence electron each) together supply only $2(3) + 6(1) = 12$ valence electrons — enough for only **six** ordinary two-electron bonds' worth of *electron pairs*, while the observed structure requires each B to be surrounded by **four** H atoms (tetrahedral, $sp^3$). A conventional 2-centre–2-electron Lewis structure cannot represent this molecule at all; drawing $\mathrm{H_3B{-}BH_3}$ with an ordinary B–B bond is chemically wrong (no such bond exists in diborane) and still leaves both B atoms short of an octet.

*Structure:* Diborane has **four terminal B–H bonds** (two on each B, ordinary 2-centre–2-electron bonds, ordinary line notation, using $4 \times 2 = 8$ electrons) and **two bridging B–H–B bonds**, in which a single hydrogen atom sits between the two boron atoms and bonds to *both simultaneously*. Each bridge is a genuine **three-centre–two-electron (3c–2e) bond**: only **2 electrons total** are delocalized over the three nuclei (B, H, B) of that bridge — not 2 electrons per B–H contact, which would require 4. The two bridges together therefore use only $2 \times 2 = 4$ electrons. Total: $8+4=12$ electrons ✓, matching the valence-electron count exactly, with **no ordinary B–B bond anywhere in the structure**.

```
        H   H   H
         \  |  /
          B---B
         /  |  \
        H   H   H
```
*(schematic only — the two centre hydrogens are bridging, each simultaneously bonded to both B atoms via a 3c–2e bond; the four outer H atoms are ordinary terminal 2c–2e bonds, two per boron)*

![Figure 2.3: Diborane bridge bonding](figures/fig2_3_diborane_bridge_bonds.svg)

**Figure 2.3.** The four terminal B–H bonds (black) are ordinary 2c–2e bonds; the two bridging B–H–B linkages (red, drawn as curved "banana bonds") are each a single 3c–2e bond in which 2 electrons are delocalized over three nuclei simultaneously — not two separate 2c–2e bonds, which the total electron count (12 valence electrons) could not support.

Each boron is tetrahedrally ($sp^3$) surrounded by four H atoms (two terminal, two bridging) and, through participation in the delocalized bridge bonds, achieves a locally complete octet — even though the *electron count* available is insufficient to have built that same connectivity from ordinary 2-centre bonds alone. This is exactly what "electron-deficient" means for diborane: **not** that any atom is left with an incomplete octet in the final structure, but that the total electron supply is insufficient to construct the observed B–H connectivity using only ordinary two-centre bonds, which is why the non-classical 3c–2e bridge bond is *required*, not optional.

*Bond-length consequence (verifiable structural signature):* the bridging B–H bonds are experimentally longer and weaker than the terminal B–H bonds, consistent with each bridging bond's electron pair being shared over three nuclei rather than concentrated between two — direct structural evidence for the 3c–2e picture over any ordinary-bond alternative.

*Scope note:* this Part gives the 3c–2e bridge-bond picture in the depth needed to resolve diborane's octet/electron-deficiency status correctly. The full molecular-orbital treatment of 3-centre bonding (constructing the bonding/non-bonding/antibonding combination explicitly), the related $\mathrm{Al_2Cl_6}$ and $\mathrm{Be}$-halide bridging structures introduced qualitatively in the Exception box above, and general electron-counting rules for multicentre boranes are developed in full in **Part 12 (Electron-Deficient Bonding)** — nothing about the present treatment is provisional or to be revised there, it is simply extended to more complex cages and clusters.

*Common mistake:* Describing diborane as "two BH₃ units joined by a B–B bond," or drawing six ordinary 2c–2e B–H bonds without acknowledging the bridge — both misrepresent the actual bonding and both fail a valence-electron count check (six ordinary bonds would require 12 electrons *for the terminal+naive-bridge bonds combined only if each bridge were also ordinary*, which over-draws the true connectivity and is inconsistent with the experimentally distinct terminal/bridging B–H bond lengths).

**(b) Expanded-octet (hypervalent) species.** Period-3-and-beyond central atoms can be surrounded by more than eight electrons.

- **PCl₅:** P contributes 5 valence electrons, forms 5 P–Cl bonds → 10 electrons around P.
- **SF₆:** S forms 6 S–F bonds → 12 electrons around S.
- **ClF₃, XeF₂, XeF₄, IF₅, IF₇** — all expanded-octet species whose shapes are developed fully with lone-pair placement in Part 9 (VSEPR); their existence is noted here only to establish that the octet rule does not apply to these central atoms, and the modern caveat about *why* expansion is possible (charge-driven orbital contraction rather than routine literal $d$-orbital hybridization) is deferred to Part 12, per the "Hypervalency" treatment required there. Electron counts around the central atom, verified directly for each: PCl₅ (5 bonds → 10 e⁻), SF₆ (6 bonds → 12 e⁻), ClF₃ (3 bonds + 2 lone pairs → 6 + 4 = 10 e⁻), IF₅ (5 bonds + 1 lone pair → 10+2=12 e⁻), IF₇ (7 bonds → 14 e⁻).

> **Worked example 2.4 — Why does NF₅ not exist, but PF₅ does?**
> *Problem:* Nitrogen and phosphorus are both Group 15 elements, yet $\mathrm{PF_5}$ is a well-known, stable compound while $\mathrm{NF_5}$ does not exist under any ordinary conditions. Explain.
> *Reasoning:* Both N and P have five valence electrons and, in principle, five unpaired electrons could be made available for bonding by promoting one electron. The difference is not in *electron count* but in **orbital availability**. Nitrogen is a period-2 element: its valence shell is $n=2$, which contains only $2s$ and $2p$ orbitals — there is no $2d$ subshell at all, at any energy, for nitrogen to draw on. Phosphorus is a period-3 element, whose valence shell is $n=3$; the $3d$ subshell, while empty in the ground state, becomes energetically accessible once P is bonded to strongly electronegative atoms (via the charge-induced orbital-contraction mechanism detailed in Part 12), permitting expansion beyond an octet.
> *Conclusion:* $\mathrm{NF_5}$ cannot exist because there is no physically available orbital set for N to expand into — this is an absolute prohibition rooted in the periodic table's shell structure, not a matter of degree. This is the single cleanest illustration available that expanded octets are fundamentally restricted to period 3 and beyond.
> *Common mistake:* Attributing the non-existence of NF₅ to "nitrogen's small size" alone. Size is a contributing factor in some hypervalency boundary cases (see next example) but is not the primary reason here — the primary reason is the complete absence of an $n=2$ $d$-subshell, a hard quantum-mechanical constraint independent of size.

> **Worked example 2.5 — Why does IF₇ exist, but ClF₇ and BrF₇ do not?**
> *Problem:* Iodine forms the heptafluoride $\mathrm{IF_7}$, yet chlorine and bromine — also period-3-and-beyond halogens with accessible $d$ orbitals — form only pentafluorides ($\mathrm{ClF_5}$, $\mathrm{BrF_5}$) at most, never heptafluorides. Why?
> *Reasoning:* Unlike the N-vs-P case above, Cl and Br **do** have accessible $d$ orbitals in principle (Cl is period 3, Br is period 4), so orbital availability is not the limiting factor here. The limitation is **steric** — a purely geometric packing constraint: seven fluorine atoms must be packed around the central halogen without excessive F···F repulsion. Iodine, being the largest of the halogens, has a large enough covalent/ionic radius to accommodate seven F atoms at a tolerable F–I–F separation (giving the pentagonal-bipyramidal geometry of Part 9). Chlorine and bromine are too small to accommodate seven fluorine atoms without prohibitive non-bonded repulsion between adjacent F atoms.
> *Conclusion:* Two genuinely distinct constraints govern expanded-octet formation, and JEE Advanced regularly tests the ability to distinguish them: **(i) electronic accessibility** of an appropriate empty orbital set (the N-vs-P boundary, a period-based, essentially absolute constraint) and **(ii) steric/size accommodation** of the required number of surrounding atoms (the Cl/Br-vs-I boundary, a size-based, comparative constraint). A structure can fail for either reason independently, and correctly identifying *which* reason applies is what distinguishes a strong answer from a superficial "it just doesn't exist" response.

**(c) Odd-electron (free-radical) species.** A molecule or ion with an odd total valence-electron count *cannot* have every electron paired.

- **NO:** valence electrons $= 5+6=11$ (odd). Best Lewis structure: $\mathrm{:N=O\cdot}$ with the unpaired electron formally on N (consistent with NO's known reactivity as a radical) — total: N has 1 lone pair + double bond (2+4=6) + 1 unpaired electron $=7$; O has 2 lone pairs + double bond $=4+4=8$. NO is paramagnetic (one unpaired electron), confirmed by both simple electron counting and MOT (Part 10.13).
- **NO₂:** valence electrons $=5+12=17$ (odd); N carries the unpaired electron, consistent with NO₂'s tendency to dimerize (N–N bond formation via the two odd electrons pairing up) to $\mathrm{N_2O_4}$.
- **ClO₂:** valence electrons $=7+12=19$ (odd); a well-known free radical, industrially used precisely because of its radical reactivity.

**General rule:** every odd-electron species is necessarily paramagnetic, because an odd total electron count makes it structurally impossible to pair every electron — at least one electron must remain unpaired regardless of how the Lewis structure is drawn, and an unpaired electron is precisely the condition for paramagnetism. This is a direct, unavoidable consequence of parity (odd vs. even electron count), not an empirical correlation that happens to hold for the examples above.

> **Exception (within the exception)**
> Odd-electron species are one of the few genuine, unavoidable failures of the octet rule — there is no way to redraw NO, NO₂, or ClO₂ with every atom obeying an octet, because the total electron count is fundamentally odd. This is different in character from the electron-deficient and expanded-octet cases above, which are failures of the *rule's applicability* to certain atoms, not arithmetic impossibilities.

### 2.8 Selecting the Most Reasonable Lewis Structure — Summary Procedure

When more than one structure satisfies the basic valence-electron count:

1. Prefer the structure that **satisfies the octet rule for every atom that is capable of an octet** (i.e., period-2 atoms), reserving expanded octets only for period-3-and-beyond central atoms where a valid octet structure genuinely cannot be drawn without leaving formal charges unreasonably large.
2. Among remaining candidates, prefer **minimum formal charges overall** (as close to zero as possible on each atom).
3. Where formal charge cannot be reduced to zero everywhere, place **negative formal charge on the more electronegative atom(s)** and positive formal charge on the less electronegative atom(s) — this matches the real direction of electron density polarization and is the physically better-motivated (lower-energy) structure. Additionally, prefer placing unlike formal charges on adjacent (bonded) atoms over separating them, and strongly avoid any structure that places like formal charges on adjacent atoms (Section 2.6, rule 8; Worked Example 2.6).
4. If two or more structures are equally valid by criteria 1–3 and differ only in which equivalent atom bears a double bond, they are **resonance structures**, not competing candidates — all must be drawn, and the true structure is their hybrid (Part 6).

### 2.9 Limitations of Lewis Structures

Lewis structures, for all their utility, have well-defined limitations that more advanced theories are needed to resolve:

- They give **no information about molecular shape** — $\mathrm{CH_4}$ and a hypothetical square-planar $\mathrm{CH_4}$ have identical Lewis structures; shape requires VSEPR (Part 9).
- They treat bonds as localized, two-centre, two-electron entities, which **fails for delocalized/resonance-stabilized systems** (Part 6) and for genuinely multicentre bonds such as the 3-centre–2-electron bridge bonds in $\mathrm{B_2H_6}$ (Part 12).
- They give **no quantitative account of relative bond strength, bond order in fractional cases, or magnetic behaviour** — $\mathrm{O_2}$'s paramagnetism (Section 1.7) is invisible to a Lewis structure and requires MOT (Part 10).
- Formal charge, which Lewis structures rely on for structure-selection, is a **bookkeeping convention**, not a measurement of real charge distribution (Section 2.5) — real (partial) charges are always smaller in magnitude and are governed by actual electronegativity differences, not by the equal-sharing assumption formal charge makes.

### 2.10 Structure Verification Panel — Every Required Species

The species below were named in earlier sections but not all were given an explicit, checkable structure. This panel corrects that: every species has its valence-electron count, bonding skeleton, lone pairs, atom-wise formal charges, checked charge sum, and octet status shown explicitly. (CO, NO₃⁻, and SCN⁻ are fully derived above as Worked Examples 2.1, 2.3, 2.6 and are not repeated here; B₂H₆ is fully derived as Worked Example 2.7 and is not repeated here.)

**Simple molecules (duplet/octet satisfied, no exceptions):**

| Species | Valence e⁻ | Skeleton | Lone pairs | Formal charges | ΣFC | Octet/duplet status |
|---|---:|---|---|---|---:|---|
| $\mathrm{H_2}$ | 2 | H–H | none | H: 0, H: 0 | 0 | Both H: duplet (2e) ✓ |
| $\mathrm{Cl_2}$ | 14 | Cl–Cl | 3 per Cl | Cl: 0, Cl: 0 | 0 | Both octet (8e) ✓ |
| $\mathrm{O_2}$ | 12 | O=O | 2 per O | O: 0, O: 0 | 0 | Both octet (8e) ✓ — **but see Common Trap below** |
| $\mathrm{N_2}$ | 10 | N≡N | 1 per N | N: 0, N: 0 | 0 | Both octet (8e) ✓ |
| $\mathrm{HCl}$ | 8 | H–Cl | 3 on Cl | H: 0, Cl: 0 | 0 | H duplet, Cl octet ✓ |
| $\mathrm{H_2O}$ | 8 | H–O–H | 2 on O | O: 0, H: 0 (×2) | 0 | O octet, H duplet (×2) ✓ |
| $\mathrm{NH_3}$ | 8 | N bonded to 3 H | 1 on N | N: 0, H: 0 (×3) | 0 | N octet, H duplet (×3) ✓ |
| $\mathrm{CH_4}$ | 8 | C bonded to 4 H | none | C: 0, H: 0 (×4) | 0 | C octet, H duplet (×4) ✓ |

> **Common Trap** — $\mathrm{O_2}$'s Lewis structure ($\mathrm{O=O}$, all electrons paired, both O with octet and FC $=0$) is entirely self-consistent as a piece of electron bookkeeping, and is not "wrong" in the sense of violating any counting rule. It is nonetheless an **incomplete physical description**: this structure predicts a diamagnetic molecule (no unpaired electrons anywhere), while $\mathrm{O_2}$ is experimentally paramagnetic. This is the standing example (first raised in §1.7) of a case where a perfectly valid Lewis structure still fails to capture real molecular behaviour — resolved only by molecular orbital theory in Part 10.

**Coordinate-bonded cations:**

| Species | Valence e⁻ | Skeleton | Lone pairs | Formal charges | ΣFC | Overall charge | Octet status |
|---|---:|---|---|---|---:|---:|---|
| $\mathrm{NH_4^+}$ | 8 | N bonded to 4 H (Figure 2.1) | none | N: $+1$, H: 0 (×4) | $+1$ | $+1$ ✓ | N octet ✓ |
| $\mathrm{H_3O^+}$ | 8 | O bonded to 3 H | 1 on O | O: $+1$, H: 0 (×3) | $+1$ | $+1$ ✓ | O octet ✓ |

**Carbon/nitrogen-oxide family (extending the CO and NO₃⁻ worked examples):**

| Species | Valence e⁻ | Skeleton | Lone pairs | Formal charges | ΣFC | Overall charge | Octet status |
|---|---:|---|---|---|---:|---:|---|
| $\mathrm{CO_2}$ | 16 | O=C=O | 2 per O, none on C | C: 0, O: 0 (×2) | 0 | 0 ✓ | All octet ✓ |
| $\mathrm{CN^-}$ | 10 | $[\mathrm{C{\equiv}N}]^-$ | 1 on C, 1 on N | C: $-1$, N: 0 | $-1$ | $-1$ ✓ | Both octet ✓ |
| $\mathrm{NO}$ | 11 (odd) | N=O, unpaired e⁻ on N | 1 pair on N, 2 on O | N: 0, O: 0 | 0 | 0 ✓ | N: 7e⁻ (odd-electron exception, §2.7c); O octet ✓ |
| $\mathrm{NO_2}$ | 17 (odd) | O=N(·)–O (resonance) | 2 on double-bond O, 3 on single-bond O | N: $+1$, O(=): 0, O(–): $-1$ | 0 | 0 ✓ | N: 7e⁻ (odd-electron exception); both O octet ✓ |
| $\mathrm{NO_2^+}$ | 16 | O=N=O (linear, isoelectronic with CO₂) | 2 per O | N: $+1$, O: 0 (×2) | $+1$ | $+1$ ✓ | All octet ✓ |
| $\mathrm{NO_2^-}$ | 18 | O=N–O (bent, resonance) | 1 on N, 2 on double-bond O, 3 on single-bond O | N: 0, O(=): 0, O(–): $-1$ | $-1$ | $-1$ ✓ | All octet ✓ |

> **Exception worth flagging explicitly (CN⁻):** the formal-charge preference rule (§2.6, rule 7) would, taken alone, suggest placing the $-1$ formal charge on N rather than C, since N is more electronegative. But redistributing the two non-bonding lone pairs to put both on N (rather than one on each atom) leaves **C with only 6 electrons — an incomplete octet** — which is not permissible for a period-2 atom with no other stabilizing exception at play (§1.7). The octet-completion requirement is a **harder constraint** than the electronegativity-placement heuristic, and overrides it here: this is exactly the point already made in §2.6's rule ordering (octet satisfaction is checked *before* formal-charge placement is used as a tiebreaker), and CN⁻ is the cleanest worked illustration of that ordering actually mattering.

**Electron-deficient (incomplete-octet) species:**

| Species | Valence e⁻ | Skeleton | Lone pairs | Formal charges | ΣFC | Electrons around central atom |
|---|---:|---|---|---|---:|---|
| $\mathrm{BF_3}$ | 24 | B bonded to 3 F | 3 per F, none on B | B: 0, F: 0 (×3) | 0 | 6 (incomplete octet — see back-bonding refinement, §2.7a) |
| $\mathrm{BeCl_2}$ | 16 | Cl–Be–Cl (linear) | 3 per Cl, none on Be | Be: 0, Cl: 0 (×2) | 0 | 4 (incomplete octet) |
| $\mathrm{AlCl_3}$ | 24 | Al bonded to 3 Cl | 3 per Cl, none on Al | Al: 0, Cl: 0 (×3) | 0 | 6 (incomplete octet; dimerizes to $\mathrm{Al_2Cl_6}$, §2.7a) |

**Coordinate-bond-completed anion:**

| Species | Valence e⁻ | Skeleton | Lone pairs | Formal charges | ΣFC | Overall charge | Electrons around B |
|---|---:|---|---|---|---:|---:|---|
| $\mathrm{BF_4^-}$ | 32 | B bonded to 4 F | 3 per F, none on B | B: $-1$, F: 0 (×4) | $-1$ | $-1$ ✓ | 8 (octet now complete via the coordinate bond from F⁻, §2.4) |

**Expanded-octet (hypervalent) species — period 3 and beyond:**

| Species | Valence e⁻ | Skeleton | Lone pairs on central atom | Formal charges | ΣFC | Electrons around central atom |
|---|---:|---|---|---|---:|---|
| $\mathrm{PCl_5}$ | 40 | P bonded to 5 Cl | none | P: 0, Cl: 0 (×5) | 0 | 10 |
| $\mathrm{SF_4}$ | 34 | S bonded to 4 F | 1 | S: 0, F: 0 (×4) | 0 | 10 |
| $\mathrm{SF_6}$ | 48 | S bonded to 6 F | none | S: 0, F: 0 (×6) | 0 | 12 |
| $\mathrm{ClF_3}$ | 28 | Cl bonded to 3 F | 2 | Cl: 0, F: 0 (×3) | 0 | 10 |
| $\mathrm{XeF_2}$ | 22 | F–Xe–F (linear) | 3 | Xe: 0, F: 0 (×2) | 0 | 10 |
| $\mathrm{XeF_4}$ | 36 | Xe bonded to 4 F | 2 | Xe: 0, F: 0 (×4) | 0 | 12 |
| $\mathrm{IF_5}$ | 42 | I bonded to 5 F | 1 | I: 0, F: 0 (×5) | 0 | 12 |
| $\mathrm{IF_7}$ | 56 | I bonded to 7 F | none | I: 0, F: 0 (×7) | 0 | 14 |

All electron counts above are around the **central atom only** — not the total molecular valence-electron count shown in the second column, which is a distinct quantity (total molecular valence electrons includes every terminal-atom electron too; the "electrons around central atom" figure is just the central atom's own local bonding+lone-pair count, which is what determines whether the octet rule is satisfied or exceeded at that atom). Conflating these two counts is a frequent source of error and is worth checking explicitly on every hypervalent species: e.g. $\mathrm{SF_6}$ has 48 total molecular valence electrons, but only 12 of them are "around" S in the sense relevant to octet-counting.

> **Exception — not every species that can be formally drawn with an expanded octet is chemically real or stable.** Nothing about correctly balancing an electron count and drawing a symmetric structure guarantees the compound exists — $\mathrm{NF_5}$, discussed in Worked Example 2.4, is formally impossible to draw at all (no accessible orbital), which is different from, say, a hypothetical $\mathrm{ClF_7}$, which *can* be drawn on paper with a balanced electron count but does not exist because the central Cl atom is sterically too small to accommodate seven F atoms (Worked Example 2.5). A correct, charge-balanced Lewis structure is a **necessary** check, not a **sufficient** one, for a species' real existence — stability additionally depends on steric accommodation, thermodynamic favourability, and (for the heavier hypervalent species) the specific nature of the bonding beyond the simple octet-expansion picture, which is why Part 12 revisits hypervalency with the multicentre/delocalized-bonding model rather than resting on formal electron counting alone.

### Important Conceptual Distinctions (Part 1–2)

| Distinction | Clarification |
|---|---|
| **Formal charge vs. oxidation number** | Formal charge assumes bonding electrons are shared *exactly equally* regardless of real electronegativity; oxidation number assumes bonding electrons belong *entirely* to the more electronegative atom. They are opposite bookkeeping extremes of the same electron pair and will generally give different numbers for the same atom in the same molecule. |
| **Formal charge vs. actual (partial) charge** | Actual partial charge, measurable via dipole moment and other experimental methods (Part 5), reflects the *real* unequal sharing driven by electronegativity difference, and its magnitude is almost always smaller than a full formal-charge unit for typical covalent bonds. |
| **Coordinate bond formation vs. the nature of the bond after formation** | The *origin* of the electron pair (one atom vs. two atoms contributing) is a historical/formation-mechanism distinction only; the *resulting bond* is physically identical to an ordinary covalent bond of the same order (Section 2.4, NH₄⁺ example). |
| **Octet rule vs. duplet rule** | Only H (and He) are stable with 2 valence electrons; all other main-group atoms discussed in this Part follow the 8-electron octet target where applicable. |

### Part 2 Summary

- Kossel's and Lewis's theories are two mechanisms (transfer vs. sharing) serving the same underlying goal: valence electron rearrangement toward a low-energy, noble-gas-like configuration.
- A coordinate bond differs from an ordinary covalent bond only in electron-pair origin, never in the resulting bond's physical character.
- Formal charge, $FC = V - N - B/2$, is the essential quantitative tool for selecting among candidate Lewis structures and for explaining otherwise-puzzling properties (e.g., CO's small dipole moment); it must not be confused with oxidation number or real partial charge.
- The octet rule fails in three systematically distinct, well-characterized ways — electron deficiency, expanded octets, and odd-electron count — each of which is developed into full structural and theoretical treatment later in this chapter (Parts 8, 9, 10, 12).

---

## Mandatory Coverage Audit — Source-to-Content Matrix (Parts 1–2)

**Inspection method, stated plainly:** `CHEMICAL_BONDING.pdf` and `Chemical_Bonding_Kohinoor_.pdf` have genuine, machine-extractable text layers (Kohinoor confirmed on this pass — it is a digitally produced document, not a scan, despite stylized fonts) and were read as text directly. `cbvj.pdf` (177 pp.) and all twelve `Chemical Bonding (E)/1–12.pdf` files (245 pp.) are true image scans of handwriting with no text layer. Every one of these 422 pages was rasterized and OCR'd in full this session; every page was then checked for topic relevance from its OCR output, and every page flagged as relevant was individually re-examined against its OCR text before being written into the notes above. Handwriting OCR remains imperfect — where a flagged page's content could not be resolved with confidence, it is marked `UNCLEAR` below rather than guessed at, per your instruction.

| Source PDF | Pages inspected for Parts 1–2 | Relevant topics found | Examples/figures found | Exact destination in notes | Status |
|---|---:|---|---|---|---|
| `CHEMICAL_BONDING.pdf` | Full text, §3.1–3.4 (pp. correspond to source §3.1–§3.4) | Bond formation/energy, types of bonds, Ketelaar triangle, Lewis octet theory, Sidgwick–Powell | NaCl/CaCl₂ ionic formation, Cl₂/CCl₄/NH₃ covalent formation, NH₄⁺/BF₃ coordinate bond, BeF₂/BF₃ incomplete octet, PF₅ expanded octet, NO/ClO₂/O₂ odd-electron & paramagnetism | §1.1–1.7, §2.1–2.2, §2.7 | INCORPORATED |
| `CB_Guha.pdf` | pp. 1–20 sampled | Identical opening (Ketelaar triangle, watermark) to `CHEMICAL_BONDING.pdf` | none beyond duplicate | — | DUPLICATE — already covered via `CHEMICAL_BONDING.pdf` |
| `Chemical_Bonding_Kohinoor_.pdf` | **All 261 extracted text-pages searched by keyword; pp. 3, 4, 12, 17, 110, 135, 136 opened and read in full** | p.3–4: octet/duplet definitions, incomplete/expanded octet, odd-e⁻ molecules, pseudo-inert-gas vs inert-gas configuration table; p.12: Lewis-structure electron-counting method; p.17: central-atom selection rule (EN tie-break → max valency); p.110: BF₃ Lewis-acidity order via back bonding, N(CH₃)₃ vs N(SiH₃)₃; pp.135–136: formal charge definition and four structure-selection rules, worked on SCN⁻/OCN⁻-type species | Na⁺/Cu⁺ pseudo-noble-gas comparison; BF₃>BCl₃>BBr₃>BI₃ Lewis acidity order; SCN⁻ formal-charge worked case | §2.1 (pseudo-noble-gas subsection), §2.6 rule 2 (tie-break), §2.6 rule 8 + Worked Example 2.6, §2.7(a) (back-bonding note) | INCORPORATED |
| `Chemical_Bonding_Kohinoor_.pdf`, remainder (~253 pages not flagged by keyword search) | Searched by keyword only, not opened individually | Keyword search (octet, lewis, formal charge, coordinate, kossel, valence, expanded, odd e⁻, hypervalent, deficient, bond energy/length, dissociation, radical, incomplete octet) returned no further hits | — | — | IRRELEVANT TO PARTS 1–2 *(by keyword search only — see limitation note below)* |
| `cbvj.pdf`, p. 1 | p. 1 | Bond formation, potential-energy curve, attraction/repulsion, bond-formation point, exothermic formation/endothermic dissociation | HClO<HClO₂<HClO₃<HClO₄ thermal-stability aside (not used — belongs to a later oxoacid-comparison part) | Figure 1.1 caption; §1.2 "Common Trap" box | INCORPORATED |
| `cbvj.pdf`, pp. 2–15 | pp. 2–15 | Dipole–dipole, London dispersion, H-bonding, clathrates | Ar·6H₂O etc. | — | IRRELEVANT TO PARTS 1–2 (confirmed Part 11 material) |
| `cbvj.pdf`, pp. 16–177 | **All rasterized and OCR'd; OCR text keyword-searched in full** | pp. 38, 50, 57–59: back bonding / bridge bonding in BF₃, AlCl₃/Al₂Cl₆, BeH₂/BeCl₂ dimers (3c–2e, 3c–4e bonds); pp. 63, 66: odd-electron molecules NO, NO₂, ClO₂, paramagnetism generalization; p. 83: oxoacid formation reactions; p. 87: XeFₙ hydrolysis; p. 100: pseudo-inert-gas configuration (Zn²⁺/Cd²⁺/Hg²⁺, ZnCl₂<CdCl₂<HgCl₂ covalent-character order — corroborates the Kohinoor p.4 finding independently); p. 172: fullerene/graphite/diamond bonding, dangling bonds | Bridge-bond electron-deficient dimer structures; pseudo-noble-gas covalent-character order (cross-confirms Kohinoor) | §2.7(a) bridge-bonding cross-reference note (pp.38,50,57–59); §2.7(c) paramagnetism generalization (pp.63,66); §2.1 pseudo-noble-gas subsection (p.100, corroborating) | INCORPORATED (pp.38,50,57–59,63,66,100); IRRELEVANT TO PARTS 1–2 — belongs to later Parts as noted (pp.83 → oxoacid comparison part; p.87 → Xe chemistry, Part 9/13; p.172 → allotrope/solid-state bonding, outside current 18-part scope) |
| `Chemical Bonding (E)/1.pdf` | **All 11 pages rasterized, OCR'd, and checked** | pp. 1–2: attraction/repulsion, chemical bond definition, covalent bond as 2c–2e sharing | — | §1.1, §2.2 (already-consistent confirmation, no new content) | INCORPORATED (confirmatory only) |
| `Chemical Bonding (E)/2.pdf` | **All 21 pages rasterized, OCR'd, and checked** | p.13: types of covalent bond overlap (σ/π/δ) | — | Belongs to Part 7/8 (Valence Bond Theory, Sigma/Pi bonds) | IRRELEVANT TO PARTS 1–2 |
| `Chemical Bonding (E)/3.pdf` | **All 16 pages rasterized, OCR'd, and checked** | p.13: expanded octet/hypervalent/hypovalent terminology (confirmatory only, no new fact beyond existing §2.7(b)) | — | §2.7(b) (confirmatory) | INCORPORATED (confirmatory only) |
| `Chemical Bonding (E)/4.pdf` | **All 13 pages rasterized and OCR'd** | No Part 1–2 keyword hits | — | — | IRRELEVANT TO PARTS 1–2 |
| `Chemical Bonding (E)/5.pdf` | **All 15 pages rasterized and OCR'd** | pp.9–12: VSEPR/steric-number method (Sidgwick–Powell-adjacent but developed as full VSEPR, not basic Lewis) | — | Belongs to Part 9 | IRRELEVANT TO PARTS 1–2 |
| `Chemical Bonding (E)/6.pdf` | **All 24 pages rasterized and OCR'd** | No Part 1–2 keyword hits | — | — | IRRELEVANT TO PARTS 1–2 |
| `Chemical Bonding (E)/7.pdf` | **All 19 pages rasterized and OCR'd** | No Part 1–2 keyword hits | — | — | IRRELEVANT TO PARTS 1–2 |
| `Chemical Bonding (E)/8.pdf` | **All 24 pages rasterized and OCR'd** | p.10: bond-length keyword hit only, context = bond-parameter comparison table | — | Belongs to Part 5 (Covalent Bond Parameters) | IRRELEVANT TO PARTS 1–2 |
| `Chemical Bonding (E)/9.pdf` | **All 20 pages rasterized and OCR'd** | No Part 1–2 keyword hits | — | — | IRRELEVANT TO PARTS 1–2 |
| `Chemical Bonding (E)/10.pdf` | **All 19 pages rasterized and OCR'd** | No Part 1–2 keyword hits | — | — | IRRELEVANT TO PARTS 1–2 |
| `Chemical Bonding (E)/11.pdf` | **All 34 pages rasterized and OCR'd** | No Part 1–2 keyword hits | — | — | IRRELEVANT TO PARTS 1–2 |
| `Chemical Bonding (E)/12.pdf` | **All 29 pages rasterized and OCR'd** | p.6: odd-electron species (confirmatory only); p.27: bond-length (Part 5 context) | — | §2.7(c) (confirmatory) | INCORPORATED (confirmatory only) |
| `Topic Wise Questions/covalencyandlewisoctetstructure.pdf` | Full 7 pages, text-native, read directly | NF₅ non-existence (no accessible d-orbital), IF₇-vs-ClF₇/BrF₇ boundary (steric limit), electron-deficiency, octet-rule exceptions, energy release on bond formation | Used as the basis for two newly written worked examples | Worked Examples 2.4 and 2.5 (rewritten originally, not pasted from source) | INCORPORATED |
| `Topic Wise Questions/basicchemicalbondinglevel0.pdf` | Full 65 pages, text-native; qq.1–24 read in full, remainder scanned by heading | qq.1–11, 19–24: ionic bond formation conditions, energy release; qq.5–18: lattice energy comparisons | Confirms existing §2.1 framing; no new Part 1–2 fact beyond what was already present | §2.1 (confirmatory) | INCORPORATED (confirmatory only); remainder (lattice-energy questions) → IRRELEVANT TO PARTS 1–2, belongs to Part 3 |
| `Topic Wise Questions/Overlappingtheorylevel0.pdf`, `level0vseprt.pdf`, `planarandnonplanarlevel0.pdf` | Headings/opening text-extracted | Orbital overlap types, VSEPR, planar/non-planar geometry | — | Belong to Parts 7, 9 | IRRELEVANT TO PARTS 1–2 |

**Explicit limitation on the "IRRELEVANT" calls for `Kohinoor` pp. not individually opened:** the ~253 unflagged Kohinoor pages were screened by keyword match against the extracted text only, not opened and read individually one-by-one. Keyword search on clean, genuinely-extracted text (unlike OCR on handwriting) is a reliable method for *locating* relevant material — a real word match is a real word match, not a probabilistic guess — so I am confident this did not miss Part 1–2 content that uses standard terminology. It could in principle miss a passage that discusses, say, formal charge or octet exceptions without ever using those words. I am flagging this explicitly rather than silently treating full-page-by-page reading and keyword search as equivalent.

## Exact Additions Made After the Missing-Source Review

1. **Pseudo-noble-gas configuration** (new subsection in §2.1) — Zn²⁺/Cd²⁺/Cu⁺/Hg²⁺ vs. true noble-gas Na⁺/Cl⁻; explanation via d-shell shielding; ZnCl₂<CdCl₂<HgCl₂ covalent-character consequence. *Source: Kohinoor p.4, independently corroborated by cbvj p.100.*
2. **Central-atom selection tie-break rule** (added to §2.6, rule 2) — when two candidate central atoms have equal electronegativity, the one with higher valency is chosen. *Source: Kohinoor p.17.*
3. **Two additional formal-charge structure-selection rules** (added to §2.6 as rule 8, and to the §2.8 summary) — preference for unlike adjacent charges over separated charges; strong disfavouring of like adjacent charges — plus a full new **Worked Example 2.6** applying the complete rule hierarchy to SCN⁻. *Source: Kohinoor pp.135–136.*
4. **Bridge-bonding cross-reference note** (added to §2.7(a)) — flags that BeCl₂/AlCl₃/BeH₂ do not persist as isolated electron-deficient monomers but dimerize/polymerize via 3-centre bonds, with full treatment correctly deferred to Part 12. *Source: cbvj pp.38, 50, 57–59.*
5. **Back-bonding note on BF₃ Lewis acidity** (added to §2.7(a)) — BF₃<BCl₃<BBr₃<BI₃ order and the 2p–np orbital-mismatch explanation. *Source: Kohinoor p.110.*
6. **Explicit paramagnetism generalization** for odd-electron species (added to §2.7(c)) — parity-based, not merely empirical. *Source: cbvj pp.63, 66.*
7. **Worked Example 2.4** (NF₅ non-existence, period-2 vs period-3 orbital accessibility) — newly written, grounded in `basicchemicalbondinglevel0.pdf` Q4/Q6.
8. **Worked Example 2.5** (IF₇ vs ClF₇/BrF₇, steric vs electronic limits on octet expansion) — newly written, grounded in `covalencyandlewisoctetstructure.pdf` Q30.
9. **Electron counts made explicit** for every expanded-octet example in §2.7(b) (PCl₅=10, SF₆=12, ClF₃=10, IF₅=12, IF₇=14 electrons around the central atom) — independently verified by direct counting, not sourced from any single PDF, to correct the earlier draft's incompleteness on this point.

## Final Chemistry Validation Report

Every Lewis structure and worked example above was independently re-checked against the following criteria immediately before this submission:

| Check | Result |
|---|---|
| Total valence-electron counts (all worked examples: CO, SO₄²⁻, NO₃⁻, SCN⁻) | Verified arithmetically; shown explicitly in each worked example |
| Octet/duplet completion on every atom | Verified for H₂, Cl₂, CCl₄, NH₃, NH₄⁺, CO, NO₃⁻, SCN⁻; exceptions (BeCl₂, BF₃, PCl₅, SF₆, NO, NO₂, ClO₂) explicitly identified and classified by type |
| Formal charges — atom-by-atom and summed against overall charge | Verified for CO ($-1,+1$; Σ=0), SO₄²⁻ (both candidate structures; Σ=$-2$ in both), NO₃⁻ ($+1,0,0,-1,-1$... i.e. N:+1, one O:0, two O:−1; Σ=−1), SCN⁻ (both candidate structures; Σ=$-1$ in both) |
| Overall ionic charge shown correctly in brackets | NH₄⁺, NO₃⁻, SO₄²⁻, SCN⁻ all shown with correct bracket/charge notation |
| Lone pairs shown explicitly | Shown in every worked Lewis structure and in Figures 2.1–2.2 |
| Bond multiplicities | Single/double/triple bonds verified against total electron count in every example |
| Coordinate-bond representation | NH₄⁺ and NH₃·BF₃ shown with correct donor/acceptor framing; explicitly stated that the resulting bond is physically identical to an ordinary covalent bond post-formation |
| Resonance notation | NO₃⁻ shown with three canonical structures and a double-headed resonance arrow (↔), explicitly *not* an equilibrium arrow; the "hybrid, not oscillation" caveat is stated explicitly |
| Terminology (formal charge vs. oxidation number vs. partial charge; coordinate vs. ordinary covalent bond; octet vs. duplet) | Addressed explicitly in the Important Conceptual Distinctions table |
| Mathematical notation | KaTeX-compatible throughout; units, subscripts, superscripts, and charges checked |
| Diagram labels | Figures 1.1, 2.1, 2.2 captioned with figure numbers and explanatory text |
| JEE Advanced depth | Insight/Trap/Exception boxes present in both Parts; two new fully-worked boundary-case examples (2.4, 2.5) added specifically to raise depth beyond NCERT level |
| Coverage of all relevant uploaded-source examples located in this pass | All examples listed in "Exact Additions" above are incorporated; no located Part 1–2-relevant example was left out |

No chemistry errors were identified in the pre-existing Part 1–2 content during this re-check; the corrections made were additions (new content found) and one presentational cleanup (Worked Example 2.6's derivation, which originally contained a visible false start and has been rewritten as a clean table-based derivation).

---


## Part 3 — Ionic Bonding and Energetics

### 3.1 Formation of Ionic Compounds — Conditions and the Redox Framing

Ionic bond formation is, at its core, a **redox process**: the electropositive atom is oxidized (loses electrons) and the electronegative atom is reduced (gains electrons), and the two resulting ions are held together by the entirely separate, subsequent electrostatic attraction between them.

$$\mathrm{Na \to Na^+ + e^-} \quad (\text{oxidation}) \qquad \mathrm{\tfrac{1}{2}Cl_2 + e^- \to Cl^-} \quad (\text{reduction})$$
$$\mathrm{Na + \tfrac{1}{2}Cl_2 \to NaCl} \quad (\text{overall redox reaction})$$

Four conditions must hold simultaneously for ionic bonding to be favourable — not merely present, but favourable enough that the ionic route outcompetes covalent sharing:

1. **The reaction must occur between a metal and a non-metal** (or, more precisely, between a strongly electropositive species and a strongly electronegative one).
2. **The metal's ionization energy must be low enough** that electron removal is not prohibitively costly.
3. **The non-metal's electron-gain enthalpy must be sufficiently favourable (exothermic)** to offset at least part of the ionization cost.
4. **The electronegativity difference between the two atoms must be large.** A large gap is what makes electron *transfer* more energetically sensible than electron *sharing* — this is the same underlying comparison introduced qualitatively in §1.4, now made quantitative.
5. **The resulting lattice energy must be large enough (highly exothermic)** to make the overall process favourable — this is frequently the *decisive* term, since ionization energy is always endothermic and often substantial, and it is lattice energy that must supply enough stabilization to overcome it. This is the direct link to §3.2–3.3 below: ionic bonding is not simply "electron transfer," it is electron transfer *followed by* a large electrostatic stabilization that makes the whole multi-step process net exothermic.

> **Why? (the conceptual bridge to what follows)**
> It is easy to mis-state ionic bond formation as "sodium gives its electron to chlorine because chlorine wants it more." This confuses electron-gain enthalpy (a real, quantifiable, exothermic step) with the *complete* energy picture. In fact, ionizing Na costs energy (endothermic, $+496\text{ kJ mol}^{-1}$) and even Cl's electron-gain enthalpy alone doesn't fully repay that cost ($-349\text{ kJ mol}^{-1}$; net so far: $+147\text{ kJ mol}^{-1}$, unfavourable). The reaction is only overall exothermic because of the large additional energy released when the gaseous ions condense into a solid lattice — the electrostatic attraction summed over the *entire* crystal, not just one ion pair. This is precisely why lattice energy — not ionization energy or electron-gain enthalpy alone — deserves the detailed quantitative treatment that follows.

### 3.2 The Born–Haber Cycle

The **Born–Haber cycle** (Born and Haber, 1919) is an application of Hess's Law that breaks the overall formation of an ionic solid from its elements into a sequence of individually measurable (or calculable) steps, allowing any *one* unmeasurable quantity in the sequence to be found if all the others are known.

**Worked example 3.1 — Full Born–Haber cycle for NaCl(s), with correct sign convention**

*Problem:* Given the enthalpy of sublimation of Na, the bond dissociation enthalpy of Cl₂, the ionization enthalpy of Na, the electron-gain enthalpy of Cl, and the lattice enthalpy of NaCl, verify the standard enthalpy of formation of NaCl(s).

*Data (standard literature values):* $\Delta H_{\mathrm{sub}}(\mathrm{Na}) = +108\text{ kJ mol}^{-1}$; $D(\mathrm{Cl_2}) = +242\text{ kJ mol}^{-1}$ (so $\tfrac{1}{2}D = +121\text{ kJ mol}^{-1}$); $IE_1(\mathrm{Na}) = +496\text{ kJ mol}^{-1}$; $\Delta H_{\mathrm{eg}}(\mathrm{Cl}) = -349\text{ kJ mol}^{-1}$; $U(\mathrm{NaCl}) = -788\text{ kJ mol}^{-1}$ (lattice enthalpy **of formation**, i.e., $\mathrm{Na^+(g) + Cl^-(g) \to NaCl(s)}$).

*Reasoning — build the cycle step by step, tracking signs:*

$$\mathrm{Na(s) + \tfrac{1}{2}Cl_2(g) \xrightarrow{\Delta H_f^\circ} NaCl(s)}$$

By Hess's Law, this direct path must equal the sum of the indirect path via gaseous atoms and ions:

$$\Delta H_f^\circ = \Delta H_{\mathrm{sub}}(\mathrm{Na}) + \tfrac{1}{2}D(\mathrm{Cl_2}) + IE_1(\mathrm{Na}) + \Delta H_{\mathrm{eg}}(\mathrm{Cl}) + U$$

$$\Delta H_f^\circ = (+108) + (+121) + (+496) + (-349) + (-788) = -412\text{ kJ mol}^{-1}$$

*Verification:* the accepted experimental $\Delta H_f^\circ(\mathrm{NaCl}) = -411\text{ kJ mol}^{-1}$ — the cycle closes correctly within rounding. ✓

*Conclusion:* every endothermic step (sublimation, dissociation, ionization — energy must be *supplied* to create gaseous, separated cations) is more than repaid by the two exothermic steps (electron gain, and overwhelmingly, lattice formation), and it is specifically the **lattice term** that dominates the exothermic side and makes the overall reaction favourable.

*Common mistake:* mixing up the sign of the lattice term by forgetting whether it is defined as *formation* ($\mathrm{ions(g) \to solid}$, exothermic, negative) or *dissociation* ($\mathrm{solid \to ions(g)}$, endothermic, positive) — these are numerically equal in magnitude but **opposite in sign**, and every Born–Haber cycle calculation must state explicitly which convention is being used before substituting a value. This distinction is elaborated fully in §3.3.

![Figure 3.1: Born-Haber cycle for NaCl](figures/fig3_1_born_haber_nacl.svg)

**Figure 3.1.** Each arrow represents one measurable enthalpy step; the diagonal (green, dashed) is the single-step overall formation enthalpy, equal by Hess's Law to the sum of all the smaller steps taken together. Endothermic steps (blue) raise the energy; exothermic steps (red) lower it; the lattice-formation step is by far the largest single contribution and is what pulls the overall diagonal downward into strongly exothermic territory.

> **Exam Method**
> When a Born–Haber question gives you every quantity except one, set up the full signed equation first (as above), substitute every known value with its correct sign, and solve for the unknown **algebraically** — do not try to "guess" the unknown quantity's sign from intuition. A very common trap is being given the lattice **dissociation** enthalpy (positive) when the cycle as drawn requires the lattice **formation** enthalpy (negative) for that same numerical magnitude — always re-check which direction the arrow in your specific cycle diagram is pointing before substituting.

### 3.3 Lattice Enthalpy — Definition and the Formation/Dissociation Distinction

**Lattice enthalpy** is the enthalpy change associated with the formation or breaking apart of one mole of an ionic solid into (or from) its gaseous ions.

$$\mathrm{Na^+(g) + Cl^-(g) \longrightarrow NaCl(s)} \qquad \Delta H = U_{\text{formation}} = -788\text{ kJ mol}^{-1} \quad (\text{exothermic})$$
$$\mathrm{NaCl(s) \longrightarrow Na^+(g) + Cl^-(g)} \qquad \Delta H = U_{\text{dissociation}} = +788\text{ kJ mol}^{-1} \quad (\text{endothermic})$$

These are the **same physical process run in opposite directions**, and therefore have exactly the same magnitude but opposite sign — treating them as interchangeable without flipping the sign is one of the most common numerical errors in this topic, worth restating from §3.2's Common Trap box.

### 3.4 The Born–Landé Equation

The lattice energy can be calculated from first principles by treating ions as point charges held together by Coulombic attraction, opposed at short range by a repulsive term arising from the overlap of filled electron shells (the same attractive/repulsive competition that produces the general potential-energy curve of §1.2, now applied specifically to an extended ionic lattice rather than a single bond).

$$U = -N_0 \dfrac{A z^+ z^- e^2}{4\pi\varepsilon_0 r_0}\left(1 - \dfrac{1}{n}\right)$$

where: $N_0$ = Avogadro's constant; $A$ = **Madelung constant** (a purely geometric factor depending on the crystal structure, summing the electrostatic contributions of every ion in the lattice, not just nearest neighbours); $z^+, z^-$ = the numerical charges on the cation and anion; $e$ = electronic charge; $\varepsilon_0$ = permittivity of free space; $r_0$ = equilibrium inter-ionic distance; $n$ = the **Born exponent**, an empirical number (typically 5–12) reflecting how steeply the short-range repulsive term rises as the ions are compressed together — larger $n$ corresponds to a "harder," less compressible ion (Table 3.2).

| Electronic structure of ion | Born exponent $n$ | Example ions |
|---|---:|---|
| He-like | 5 | Li⁺, Be²⁺ |
| Ne-like | 7 | Na⁺, Mg²⁺, O²⁻, F⁻ |
| Ar-like | 9 | K⁺, Ca²⁺, S²⁻, Cl⁻, Cu⁺ |
| Kr-like | 10 | Rb⁺, Br⁻, Ag⁺ |
| Xe-like | 12 | Cs⁺, I⁻, Au⁺ |

For a compound of two different ions, the average of the two individual $n$ values is used (e.g., for LiCl, $n = (5+9)/2 = 7$).

| Crystal structure type | Madelung constant $A$ |
|---|---:|
| Zinc blende (ZnS) | 1.638 |
| Wurtzite (ZnS) | 1.641 |
| Rock salt (NaCl) | 1.748 |
| Caesium chloride (CsCl) | 1.763 |
| Rutile (TiO₂) | 2.408 |
| Fluorite (CaF₂) | 2.519 |
| Corundum (Al₂O₃) | 4.172 |

**Reading the equation physically, term by term:**
- The $\dfrac{z^+z^-}{r_0}$ factor is the ordinary Coulomb's-law statement that attraction is stronger for higher ionic charges and shorter inter-ionic distance — this alone would predict an *infinite* energy release as $r_0 \to 0$, which is unphysical.
- The $\left(1 - \dfrac{1}{n}\right)$ correction factor is what prevents that unphysical divergence: it accounts for the short-range repulsion that switches on once electron clouds begin to overlap (exactly the repulsive branch of the general potential-energy curve, §1.2), capping the lattice energy at a finite, physically sensible value corresponding to the true equilibrium separation.

> **Model Limitation**
> The close numerical agreement typically seen between Born–Landé-calculated lattice energies and Born–Haber-cycle experimental values (often within 1–3% for alkali halides) does **not** by itself prove that the underlying assumption — that the ions behave as perfect point charges with 100% ionic bonding — is correct. The equation is, in a specific sense, self-compensating: increasing the inter-ionic distance $r_0$ (e.g., by changing coordination number) *reduces* the calculated lattice energy, but a coordination-number change is nearly always accompanied by a *change in crystal structure*, and hence in the Madelung constant $A$, which *increases* the calculated lattice energy in partial compensation. The two effects substantially cancel, which can mask genuine errors in the underlying point-charge assumption. Large disagreement between calculated and experimental lattice energy (seen, for example, in $\mathrm{CdI_2}$, which shows roughly 20%+ deviation) is itself useful evidence that a compound has **significant covalent character** and is not well described as a simple ionic point-charge lattice — this is the direct bridge into Part 4 (Fajans' rules, polarization, and covalent character).

### 3.5 Factors Affecting Lattice Enthalpy

Lattice enthalpy magnitude is governed by exactly the two variables that appear explicitly in the Born–Landé equation's dominant Coulombic term:

**(a) Ionic charge.** Lattice energy is directly proportional to the product $z^+z^-$. Doubling either ionic charge roughly doubles the numerator of the dominant Coulombic term, so lattice energy rises sharply with charge — this is why oxides and nitrides of a given cation (with $\mathrm{O^{2-}}$ or $\mathrm{N^{3-}}$) have dramatically higher lattice energies than the corresponding halides (with singly-charged $\mathrm{X^-}$) of the same cation, even at comparable ionic size.

**(b) Ionic size (inter-ionic distance).** Lattice energy is inversely proportional to $r_0$. Smaller ions can approach more closely, concentrating the Coulombic attraction over a shorter distance, so lattice energy decreases smoothly down a group as ionic radius increases (for a fixed charge type): $\mathrm{LiF > NaF > KF > RbF > CsF}$ in lattice energy.

**Worked example 3.2 — Ordering lattice energies by combining both factors**

*Problem:* Arrange $\mathrm{NaF}$, $\mathrm{MgO}$, and $\mathrm{ScN}$ in order of increasing lattice energy, given all three have essentially the same rock-salt crystal structure and comparable inter-ionic distances.

*Reasoning:* Since $r_0$ and $A$ are held roughly constant across this series, lattice energy is controlled almost entirely by the charge product $z^+z^-$: $\mathrm{NaF}$ ($1\times1=1$), $\mathrm{MgO}$ ($2\times2=4$), $\mathrm{ScN}$ ($3\times3=9$).

*Conclusion:* $\mathrm{NaF < MgO < ScN}$ — and because lattice energy correlates directly with melting point and hardness (both reflect the energy needed to disrupt the lattice), the same order holds for melting point and Mohs hardness across this series, which is a frequently tested cross-property ordering question.

*Common mistake:* trying to order these by ionic radius alone (which would be a much weaker, secondary effect here) instead of recognizing that the charge-product term dominates so heavily ($9\times$ difference between NaF and ScN) that it alone determines the ranking.

### 3.6 Hydration Enthalpy, Solution Enthalpy, and Solubility

When an ionic solid dissolves, two competing energetic processes occur: the lattice must be broken apart (always endothermic, requiring input equal to the lattice dissociation enthalpy) and the resulting free ions become surrounded and stabilized by solvent molecules — for water, this is **hydration enthalpy**, always exothermic, since ion–dipole attraction between the ion and the polar water molecules releases energy.

$$\Delta H_{\text{solution}} = \Delta H_{\text{lattice dissociation}} + \Delta H_{\text{hydration}}$$

A salt is soluble when $\Delta H_{\text{solution}}$ is sufficiently favourable (or, more completely, when $\Delta G_{\text{solution}} = \Delta H_{\text{solution}} - T\Delta S_{\text{solution}}$ is negative — dissolution always increases entropy, since ions become free to move in solution rather than fixed in a lattice, so even a mildly endothermic $\Delta H_{\text{solution}}$ can still be spontaneous if the entropy term is large enough at a given temperature).

**Why water is such an effective solvent for ionic solids — and why not universally.** Water's very high **dielectric constant** ($\varepsilon_r \approx 80$) means that once ions are separated in solution, the electrostatic attraction *between* those ions (which would otherwise pull them back together) is reduced by a factor of $\sim 80$ relative to their attraction in a vacuum or in a low-polarity solvent — this is the direct, quantitative reason polar solvents dissolve ionic solids far more effectively than non-polar ones ("like dissolves like" restated with its actual physical mechanism, not just as a slogan).

| Solvent | Dielectric constant $\varepsilon_r$ (approx.) |
|---|---:|
| Water | 80 |
| Methanol | 33 |
| Ethanol | 24 |
| Diethyl ether | 4.3 |

**Solubility trends down a group for oxoanion salts**: for a fixed oxoanion, the *direction* of the solubility trend down the alkali-metal group is set by which term of §3.6's equation — lattice dissociation enthalpy or hydration enthalpy — falls faster as the cation grows. For the **carbonates**, the lattice term falls faster than the hydration term (Li₂CO₃'s exceptionally strong, short-distance lattice is not fully repaid even by Li⁺'s very large hydration enthalpy), so solubility **increases** down the group:

$$\mathrm{Li_2CO_3 < Na_2CO_3 < K_2CO_3 < Rb_2CO_3 < Cs_2CO_3}$$

For the **perchlorates**, the direction is the opposite: with the very large, singly-charged, charge-diffuse $\mathrm{ClO_4^-}$ anion, the lattice enthalpy is dominated by the anion and varies only weakly with the cation, while hydration enthalpy falls steeply from Li⁺/Na⁺ to Cs⁺ — so solubility **decreases** from sodium downward, and $\mathrm{KClO_4}$, $\mathrm{RbClO_4}$, and $\mathrm{CsClO_4}$ are all only sparingly soluble (the classical basis for precipitating potassium gravimetrically as $\mathrm{KClO_4}$):

$$\mathrm{NaClO_4 > KClO_4 > RbClO_4 > CsClO_4} \qquad (\text{decreasing solubility})$$

and, extending the same reasoning to alkaline-earth oxoanion salts of decreasing lattice stability down the group:

$$\mathrm{BeSO_4 > MgSO_4 > CaSO_4 > SrSO_4 > BaSO_4} \qquad (\text{decreasing solubility down the group})$$

> **Compare** — this is the same size-matching principle already used for thermal stability (§3.8) now applied to solubility, and it is worth explicitly noting that the *direction* of the trend depends on which effect dominates for a given salt family: for simple halides of a fixed small cation (§3.6's main worked material), solubility trends are typically dominated by hydration-enthalpy loss down the group (decreasing solubility, e.g. LiF<NaF<KF<RbF<CsF is actually an *increasing* trend driven by lattice energy falling faster than hydration energy for this specific small-anion case — see the full alkali-halide solubility discussion in §3.6). Alkaline-earth sulfates show the *opposite* direction (BeSO₄ most soluble, decreasing down the group) because, for these larger, polyatomic-anion, higher-charge-density combinations, lattice energy dominates hydration energy across the whole series rather than only for the lightest member. **The controlling physical variable is always the same (relative size of the lattice-energy and hydration-energy terms in §3.6's equation) — only which term wins, and therefore which direction the trend runs, changes from series to series**, which is exactly why this class of ordering question cannot be answered by memorizing a single universal direction.

**Worked example 3.3 — Predicting the solubility-trend direction from first principles**

*Problem:* Without memorizing the specific direction, predict whether $\mathrm{Li_2CO_3}$ or $\mathrm{Cs_2CO_3}$ is more soluble in water.

*Reasoning:* Compare the two terms of §3.6's equation and how each changes from Li⁺ to Cs⁺. Li⁺, the smallest alkali cation, gives the shortest inter-ionic distance and hence the strongest lattice of the series (with some additional covalent stabilization, per Fajans-type reasoning, Part 4); Li⁺ is also the most strongly hydrated cation. The observed low solubility of $\mathrm{Li_2CO_3}$ tells us which term wins: the exceptionally strong lattice is *not* fully repaid even by Li⁺'s very large hydration enthalpy. Descending the group, both terms fall — but the lattice term falls faster than the hydration term for this series, so the dissolution balance becomes progressively more favourable.

*Conclusion:* $\mathrm{Li_2CO_3}$ is *less* soluble than $\mathrm{Cs_2CO_3}$ — matching the order above — because Cs⁺ forms a much weaker lattice with $\mathrm{CO_3^{2-}}$ than Li⁺ does, and that loss of lattice enthalpy down the group outpaces the simultaneous loss of hydration enthalpy: lattice-enthalpy decline, not hydration-enthalpy gain, is the term that controls this series.

*Common mistake:* assuming "smaller cation = more strongly hydrated = more soluble" as a universal rule. Hydration is only one of the two competing terms; whenever the lattice term is the faster-changing one (as in this carbonate series), the naive hydration-only prediction reverses. The direction must be settled per series by asking which term dominates — never by a single memorized rule.

> **Exception** — water is sometimes called the "universal solvent," but it is not used as a solvent for reactive metal salts or in redox-sensitive contexts, because water itself can act as **both an oxidizing and a reducing agent** depending on the other species present (it can be reduced at the cathode to $\mathrm{H_2}$, or oxidized at the anode to $\mathrm{O_2}$, in electrolysis, for example) — a genuine limitation on treating "polar solvent" and "water" as interchangeable in every context.

### 3.7 Physical Properties of Ionic Compounds — Summary Table

| Property | Typical behaviour | Physical reason |
|---|---|---|
| Physical state | Crystalline solids at room temperature | Long-range, non-directional electrostatic ordering favours a regular repeating lattice |
| Melting/boiling point | High | Breaking the lattice requires overcoming the full lattice enthalpy, which is large (§3.4–3.5) |
| Hardness/brittleness | Hard but brittle | A shearing stress that shifts one ionic layer relative to another brings like-charged ions into direct contact, producing strong repulsion and fracture — not gradual deformation (contrast with metallic bonding, Part 12) |
| Directionality | Non-directional | Coulombic attraction acts equally in all directions around an ion, unlike the directional orbital overlap of covalent bonds |
| Solubility | Generally soluble in polar solvents, insoluble in non-polar solvents | High dielectric constant of polar solvents reduces inter-ionic attraction after dissolution (§3.6) |
| Electrical conductivity | Poor as solids; good when molten or dissolved | Ions are fixed in the solid lattice (cannot migrate to carry current) but become mobile once the lattice is broken (melting) or the ions are solvated (dissolution) |
| Isomorphism | Ionic compounds with comparable ionic size, charge, and crystal structure can co-crystallize (isomorphism) | Requires comparable size of corresponding constituent units, comparable polarizing power/polarizability, comparable molar volume, and the same crystal structure type — e.g., $\mathrm{KMnO_4}$ and $\mathrm{BaSO_4}$, or $\mathrm{K_2SO_4 \cdot Al_2(SO_4)_3 \cdot 24H_2O}$ and $\mathrm{(NH_4)_2SO_4 \cdot Al_2(SO_4)_3 \cdot 24H_2O}$ (isomorphous alums) |

### 3.8 Thermal Stability of Ionic Compounds

For simple binary ionic compounds, thermal stability tracks lattice enthalpy directly: a larger inter-ionic distance gives a lower lattice enthalpy, which in turn gives lower thermal stability (the compound decomposes more readily on heating, since less energy is needed to disrupt a weaker lattice).

$$\mathrm{Li_2O > Na_2O > K_2O > Rb_2O > Cs_2O} \qquad \mathrm{LiX > NaX > KX > RbX > CsX \; (X = F, Cl, Br, I)}$$

For ionic compounds with a **polyatomic anion**, the trend can invert: thermal stability then *increases* down a group, because efficient packing between a large cation and a large polyatomic anion (both of comparable size) gives a more stable lattice than a size-mismatched pairing of a small cation with a large anion.

$$\mathrm{LiNO_3 < NaNO_3 < KNO_3 < RbNO_3 < CsNO_3} \qquad \mathrm{Li_2CO_3 < Na_2CO_3 < K_2CO_3 < Rb_2CO_3 < Cs_2CO_3}$$

> **Compare** — This is a genuinely tested reversal, and the reasoning matters more than memorizing the direction: for a *simple* anion (F⁻, O²⁻, N³⁻), a small, high-charge-density cation packs closely and gives a strong lattice → small cations favour stability with simple anions. For a *large, polyatomic* anion, a small cation "rattles" in an oversized site and packs poorly, giving a *weaker* lattice than a size-matched large cation would → large cations favour stability with large polyatomic anions. The controlling factor in both cases is the same (efficient close packing maximizes lattice enthalpy) — only the direction of the resulting trend differs, because what counts as "size-matched" is different in the two cases.

### Part 3 Summary

- Ionic bond formation is a redox process whose overall favourability depends on the full multi-step energy balance (sublimation + ionization + dissociation + electron gain + lattice formation), captured completely and quantitatively by the Born–Haber cycle (Worked Example 3.1, Figure 3.1).
- Lattice enthalpy of formation and dissociation are numerically equal but oppositely signed — the single most common sign error in this topic.
- The Born–Landé equation quantifies lattice energy from ionic charge, inter-ionic distance, crystal geometry (Madelung constant), and short-range repulsion (Born exponent); its close fit to experiment is not, by itself, proof of purely ionic bonding, and large deviations (e.g., $\mathrm{CdI_2}$) are direct evidence of covalent character — the conceptual bridge into Part 4.
- Solubility is governed by the competition between lattice dissociation enthalpy (endothermic) and hydration enthalpy (exothermic), mediated by solvent dielectric constant.
- Thermal stability tracks lattice enthalpy for simple anions (small cation favours stability) but *inverts* for large polyatomic anions (large cation favours stability), with size-matching as the single unifying physical explanation for both directions.

---

## Part 4 — Polarisation, Fajans' Rules, and Covalent Character

### 4.1 Why the Purely Ionic Picture Needs Correction

Part 3 treated ions as rigid point charges — a useful approximation that gives good agreement between calculated (Born–Landé) and experimental (Born–Haber) lattice energies for many compounds. But §3.4 already flagged the exception: compounds like $\mathrm{CdI_2}$ show large disagreement between the two, which is direct evidence that real ions are not rigid points — their electron clouds can be **distorted**, and that distortion introduces genuine covalent character into a bond nominally classified as "ionic." This Part develops that distortion — **polarisation** — as a quantitative, predictive framework.

### 4.2 Polarisation, Polarising Power, and Polarisability

When a cation and anion approach each other, two things happen simultaneously: the cation's positive charge attracts the anion's electron cloud, pulling it toward the cation, and (to a much smaller extent) the anion's negative charge attracts the cation's nucleus. In practice only the **first** effect matters significantly, because cations are small and their few remaining electrons are held tightly by a nucleus with a large effective positive charge — a cation's own electron cloud is essentially non-deformable by comparison with a large, loosely-held anion electron cloud.

- **Polarisation** is the distortion of an ion's electron cloud away from its idealized spherical shape, caused by the electric field of a neighbouring oppositely-charged ion.
- **Polarising power** is the *ability of a cation to cause* this distortion in a neighbouring anion.
- **Polarisability** is the *susceptibility of an anion* to be distorted.

$$\text{Greater polarisation} \;\Longrightarrow\; \text{greater covalent character} \;\Longrightarrow\; \text{less purely ionic character}$$

> **Why? (the physical mechanism, not just the definition)**
> Polarisation concentrates a larger share of the anion's electron density in the region *between* the two nuclei — precisely the electron-density signature of a covalent bond (§1.1, §2.2). A "purely ionic" bond, by contrast, has each ion's electron cloud remaining essentially undistorted and centred on its own nucleus, with attraction occurring at long range through the ions' net charges rather than through shared electron density. Polarisation is therefore not a separate phenomenon layered on top of ionic bonding — it is the literal, continuous transition from the ionic extreme toward the covalent extreme of Ketelaar's triangle (§1.4), now given a specific physical driver and a specific set of predictive rules.

![Figure 4.1: Anion polarization](figures/fig4_1_anion_polarization.svg)

**Figure 4.1.** (a) The idealized ionic picture: spherical, undistorted electron clouds, interacting only through net charge. (b) The real, polarised picture: the anion's electron cloud is pulled toward the cation, concentrating electron density in the internuclear region — the same signature that characterizes an ordinary covalent bond (§2.2).

### 4.3 Fajans' Rules — Factors Governing the Degree of Polarisation

Fajans (1923) formalized four rules predicting when covalent character will be significant in a nominally ionic compound:

| Rule | Statement | Physical reason |
|---|---|---|
| 1 | **Small cation favours covalent character** | A small cation concentrates its positive charge over a small volume, giving an intense local electric field at its surface — high polarising power |
| 2 | **Large anion favours covalent character** | A large anion's outer electrons are far from its own nucleus and poorly shielded by inner filled shells, so they are easily displaced — high polarisability |
| 3 | **High charge on either ion favours covalent character** | Higher charge directly increases the electric field strength driving polarisation (both the cation's ability to polarise and, for a highly charged anion, its own looser hold on outer electrons) |
| 4 | **A cation lacking a noble-gas configuration favours covalent character** | Non-noble-gas-configuration cations (see §4.4) shield the nuclear charge less effectively, so their true polarising power exceeds what their charge and size alone would predict |

**Ionic potential (polarising power quantified).** Rules 1 and 3 for the cation combine into a single useful quantity, the **ionic potential** $\phi$:

$$\phi = \dfrac{z^+}{r}$$

where $z^+$ is the cation's charge and $r$ its radius (in Å or pm, with a consistent convention). A higher $\phi$ means a more strongly polarising cation.

![Figure 4.2: Ionic potential trend](figures/fig4_2_ionic_potential_trend.svg)

**Figure 4.2.** Polarising power rises sharply as ionic radius falls and charge rises — Al³⁺, small and highly charged, is a far stronger polariser than Cs⁺, large and singly charged, even though both are simple, common cations.

**Worked example 4.1 — Ranking covalent character using ionic potential**

*Problem:* Rank $\mathrm{LiF}$, $\mathrm{MgF_2}$, and $\mathrm{AlF_3}$ in order of increasing covalent character.

*Reasoning:* All three share the same anion (F⁻), so anion polarisability is constant across the series and the ranking is controlled entirely by cation ionic potential $\phi = z^+/r$. Across the isoelectronic-ish series Li⁺→Mg²⁺→Al³⁺ (all roughly comparable in size, but increasing charge), $\phi$ rises sharply: Li⁺ ($\phi \approx 0.98$ Å⁻¹), Mg²⁺ ($\phi \approx 2.86$ Å⁻¹), Al³⁺ ($\phi \approx 5.9$ Å⁻¹, using standard ionic radii).

*Conclusion:* $\mathrm{LiF < MgF_2 < AlF_3}$ in covalent character — consistent with the well-known fact that $\mathrm{AlF_3}$, despite being formally a simple trihalide, shows measurably more covalent character than the alkali and alkaline-earth fluorides, and $\mathrm{AlCl_3}$ (larger, more polarisable anion) is covalent enough to exist as a molecular dimer, $\mathrm{Al_2Cl_6}$ (§2.7a), rather than an extended ionic lattice.

*Common mistake:* treating "ionic potential" as applicable only to comparing cations of *different* elements — it is equally the correct tool for ranking covalent character across an isoelectronic charge series like this one, where naive electronegativity-difference reasoning is less immediately obvious.

### 4.4 Pseudo-Noble-Gas Cations and Fajans' Fourth Rule

This is a direct continuation of the pseudo-noble-gas subsection already established in §2.1: cations such as $\mathrm{Cu^+}$, $\mathrm{Ag^+}$, $\mathrm{Zn^{2+}}$, $\mathrm{Cd^{2+}}$, and $\mathrm{Hg^{2+}}$ have an outer $(n-1)d^{10}$ shell (18 electrons) rather than a true noble-gas $ns^2np^6$ shell (8 electrons). The $d^{10}$ shell shields the nuclear charge **less effectively** than a $p^6$ shell (because $d$ orbitals are more diffuse and penetrate less toward the nucleus), so these cations have a **higher effective nuclear charge at their surface**, and hence a **higher true polarising power**, than a same-charge, similar-radius cation with a genuine noble-gas configuration.

**Worked example 4.2 — NaCl vs. CuCl: same formula type, different bonding character**

*Problem:* $\mathrm{Na^+}$ and $\mathrm{Cu^+}$ have almost identical ionic radii (Na⁺ ≈ 102 pm, Cu⁺ ≈ 96 pm) and identical charge (+1). Both form 1:1 chlorides. Yet $\mathrm{NaCl}$ is a classic ionic solid (high melting point, water-soluble, colourless, poor solubility in non-polar solvents) while $\mathrm{CuCl}$ shows substantially more covalent character (lower melting point relative to what pure ionic bonding would predict, much lower solubility in water, some solubility in less polar solvents). Explain, given the near-identical size and charge.

*Reasoning:* Size and charge alone (the naive ionic-potential comparison) would predict essentially *identical* behaviour for these two cations. The actual difference is entirely explained by electron configuration: $\mathrm{Na^+}$ (2,8 — true noble-gas, Ne-like) shields its nuclear charge efficiently, while $\mathrm{Cu^+}$ (2,8,18 — pseudo-noble-gas) does not. $\mathrm{Cu^+}$'s poorly-shielded nuclear charge gives it a genuinely higher polarising power than its raw size/charge numbers suggest, which is precisely Fajans' fourth rule.

*Conclusion:* the size-and-charge-only version of Fajans' rules (rules 1–3) is **necessary but not sufficient** — rule 4 (electron configuration) must always be checked separately, and is often the deciding factor when comparing a main-group cation against a post-transition-metal cation of similar size and charge.

*Common mistake:* assuming Fajans' rules 1–3 alone can rank *any* two cations' polarising power — they only give a reliable ranking *within* a set of cations that share the same type of electron configuration (all true-noble-gas, or all pseudo-noble-gas); comparing across the two categories requires rule 4 explicitly.

### 4.5 Consequences of Increasing Covalent Character

Every physical property below follows the same underlying logic: greater polarisation → more electron density concentrated between the ions (more "molecule-like," less "ion-pair-like") → properties shift away from the typical-ionic extreme and toward the typical-covalent/molecular extreme.

| Property | Effect of increasing polarisation/covalent character | Physical reason |
|---|---|---|
| Melting/boiling point | **Decreases** | A more covalent, molecule-like lattice is held together by weaker intermolecular forces between discrete units rather than a continuous strong electrostatic lattice; less energy is needed to disrupt it |
| Lattice enthalpy (Born–Landé calculated vs. experimental) | **Larger deviation** between calculated and experimental values | The point-charge assumption underlying Born–Landé becomes progressively less valid as real electron-cloud distortion grows |
| Solubility in water (polar) | **Decreases** | A more covalent lattice offers less to gain from ion–dipole hydration stabilization, since charge is less localized on distinct point-like ions |
| Solubility in non-polar/organic solvents | **Increases** | A more molecule-like (covalent) species interacts favourably with non-polar solvents via van der Waals-type forces, unlike a true ionic lattice |
| Colour | **More likely to appear/intensify** | Polarisation lowers the energy gap for charge-transfer-type electronic transitions between the distorted anion and cation, shifting absorption into the visible range |
| Thermal stability / ease of decomposition | **Decreases** for oxyanion salts and hydroxides (see §4.6) | A highly polarising cation increasingly distorts a complex anion's own internal bonding, weakening it and favouring decomposition to a smaller, more stable anion/oxide |
| Acidic character of the oxide | **Increases** | Greater polarisation of the O²⁻ ion increases M–O covalent character, making it easier for the compound to donate H⁺ (i.e., act as an acid) rather than release O²⁻/OH⁻ (act as a base) — quantified via ionic potential thresholds below |

**Worked example 4.3 — Silver halide solubility, using Fajans' rules with a fixed cation**

*Problem:* Account for the sharply decreasing water solubility order $\mathrm{AgF \gg AgCl > AgBr > AgI}$ (AgF is freely soluble; AgI is essentially insoluble, $K_{sp} \sim 10^{-17}$).

*Reasoning:* The cation (Ag⁺, pseudo-noble-gas, fixed polarising power) is constant across the series, so the controlling variable is anion polarisability, which increases sharply down the halogen group as ionic radius increases and outer electrons become more loosely held: $\mathrm{F^- \ll Cl^- < Br^- < I^-}$ in polarisability. Increasing anion polarisability means increasing covalent character in the Ag–X bond, which (per the table above) decreases water solubility.

*Conclusion:* $\mathrm{AgF}$, with the least polarisable anion, remains essentially ionic and freely water-soluble (behaving like an alkali fluoride); $\mathrm{AgI}$, with the most polarisable anion, is covalent enough to behave essentially as a molecular/covalent solid with very low water solubility.

*Common mistake:* trying to explain this trend using electronegativity differences alone (which would predict the *opposite* — AgI has the smallest EN gap and should on that basis alone seem "least ionic," which happens to agree here, but this reasoning generalizes poorly; the *polarisability* argument is the one that correctly explains solubility trends across many analogous series, e.g., alkali halide solubility in non-polar solvents, and should be the default tool).

**Worked example — colour as a direct, visible signature of polarisation** (source-verified, `cbvj.pdf` p.118): $\mathrm{PbI_2}$ is bright yellow while $\mathrm{PbCl_2}$ is colourless; $\mathrm{HgI_2}$ is scarlet red while $\mathrm{HgCl_2}$ is colourless; and across the silver halides, colour deepens $\mathrm{AgCl}$ (white) → $\mathrm{AgBr}$ (pale yellow) → $\mathrm{AgI}$ (yellow) as the halide becomes progressively more polarisable. In every case the *same* cation is paired with halides of increasing polarisability, and colour intensifies in step with covalent character — because greater polarisation narrows the energy gap for charge-transfer-type electronic transitions between the distorted anion and cation, shifting light absorption from the UV into the visible region (Part 5 treats electronic transitions and colour in more mechanistic detail where relevant to that Part's scope). A useful generalization worth stating explicitly: for a fixed cation, **iodides are the most likely halide to be coloured**, and if even the iodide of a given metal is colourless, the bromide, chloride, and fluoride of that same metal will certainly be colourless too (e.g., $\mathrm{NaI}$, $\mathrm{KI}$, $\mathrm{CuI}$ are all colourless, correctly predicting that the corresponding bromides/chlorides/fluorides are colourless as well).

**Worked example 4.4 — Multiple-correct: which pairs correctly illustrate Fajans' rules?**

*Problem:* Which of the following observations are correctly explained by Fajans' rules? (A) $\mathrm{BeCl_2}$ has significant covalent character and is soluble in organic solvents, unlike $\mathrm{CaCl_2}$, $\mathrm{SrCl_2}$, $\mathrm{BaCl_2}$. (B) $\mathrm{SnCl_4}$ is a covalent, volatile liquid while $\mathrm{SnCl_2}$ is a higher-melting, more ionic solid. (C) $\mathrm{FeCl_3}$ hydrolyses in water more readily and shows more covalent character than $\mathrm{FeCl_2}$. (D) $\mathrm{LiI}$ has a lower melting point than $\mathrm{LiF}$.

*Reasoning:*
(A) **Correctly explained.** $\mathrm{Be^{2+}}$ is by far the smallest, highest-ionic-potential alkaline-earth cation ($\phi \approx 6.45$ Å⁻¹ vs. $\sim 2.0$ Å⁻¹ or less for Ca²⁺/Sr²⁺/Ba²⁺), so it is by far the strongest polariser in the group — $\mathrm{BeCl_2}$ is the accepted textbook example of a covalent Group 2 halide.
(B) **Correctly explained.** For the same element (Sn), higher cation charge (+4 vs +2) directly increases ionic potential (Fajans' rule 3), so $\mathrm{Sn^{4+}}$ polarises Cl⁻ far more strongly than $\mathrm{Sn^{2+}}$ does — $\mathrm{SnCl_4}$ behaves as a molecular covalent compound (volatile liquid), while $\mathrm{SnCl_2}$ retains more ionic character.
(C) **Correctly explained** — same logic as (B) applied to Fe: $\mathrm{Fe^{3+}}$'s higher charge and smaller radius relative to $\mathrm{Fe^{2+}}$ give it substantially higher ionic potential, hence more covalent character, hence easier hydrolysis (a hallmark of covalent, non-ionic metal chlorides in water).
(D) **Correctly explained**, but for the *anion*-side reason, not the cation side: Li⁺ is fixed across this comparison, so the controlling variable is anion polarisability, $\mathrm{F^- \ll I^-}$; the more polarisable I⁻ gives $\mathrm{LiI}$ more covalent character and hence a lower melting point than $\mathrm{LiF}$ (mirroring the general lithium-halide trend $\mathrm{LiF > LiCl > LiBr > LiI}$ in melting point and ionic character).

*Conclusion:* **all four (A)–(D) are correctly explained by Fajans' rules**, but note that (A)–(C) are cation-side (charge/configuration) illustrations while (D) is an anion-side (polarisability) illustration — a genuinely multiple-correct question, and one that specifically tests whether the reasoning is anchored on the correct side of the ion pair in each case, not just whether the final ordering happens to be memorised correctly.

### 4.6 Acidic Character of Oxides — A Quantitative Ionic-Potential Threshold

As a cation's ionic potential $\phi$ rises, it polarises the oxide ion (O²⁻) so strongly that the M–O bond becomes substantially covalent — at which point the compound behaves as an acidic oxide (readily donating H⁺ when combined with water, forming an oxoacid) rather than a basic oxide (releasing OH⁻/O²⁻ in water). An approximate empirical threshold, useful for quick classification:

| Ionic potential range | Character |
|---|---|
| $\phi < 2.2$ | Basic oxide |
| $2.2 \le \phi \le 3.2$ | Amphoteric oxide |
| $\phi > 3.2$ | Acidic oxide |

**Worked example 4.5 — Classifying oxide character from ionic potential**

*Problem:* Using $r(\mathrm{Al^{3+}}) \approx 50$ pm ($=0.50$ Å) and $r(\mathrm{Mg^{2+}}) \approx 72$ pm ($=0.72$ Å), classify $\mathrm{Al_2O_3}$ and $\mathrm{MgO}$.

*Reasoning:* $\phi(\mathrm{Al^{3+}}) = 3/0.50 = 6.0$ Å⁻¹; by the threshold table this is far into the acidic range, but $\mathrm{Al_2O_3}$ is experimentally amphoteric, not acidic — this signals that the *simple* $z/r$ ionic-potential threshold table above is a first-approximation heuristic, and more carefully calibrated ionic-potential definitions (accounting for coordination number and using a self-consistent radius scale) are needed to reproduce $\mathrm{Al_2O_3}$'s correctly-known amphoteric character exactly; using $\phi(\mathrm{Al^{3+}}) \approx 2.45$ on the specific calibrated scale from which the 2.2–3.2 threshold table was derived correctly places it in the amphoteric range. $\phi(\mathrm{Mg^{2+}}) = 2/0.72 \approx 1.66$, comfortably basic. ✓ ($\mathrm{MgO}$ is indeed a standard basic oxide.)

*Conclusion:* the ionic-potential threshold table is calibrated against a specific, self-consistent set of ionic radii and should be applied using that same scale rather than an arbitrary radius source — **mixing radius conventions is the single most common source of an apparently "wrong" classification** using this method, and is worth checking explicitly before concluding the rule itself has failed.

*Common mistake:* concluding that ionic-potential classification is unreliable the moment a borderline case (like Al₂O₃) doesn't immediately match, rather than checking for a radius-convention mismatch first.

### 4.7 Limitations of Fajans' Rules

Fajans' rules are a genuinely useful, physically grounded first-approximation, but they have real boundaries:

1. **They are qualitative/ordinal, not quantitative** — they correctly predict the *direction* of trends (more polarising → more covalent) but do not by themselves give a numerical percentage ionic/covalent character (that requires dipole-moment-based methods, Part 5).
2. **They can be overridden by lattice-packing and hydration effects.** A notable exception: $\mathrm{LiCl}$, $\mathrm{LiBr}$, and $\mathrm{LiI}$ are soluble in organic solvents like pyridine and alcohol (consistent with covalent character), yet $\mathrm{NaHCO_3}$ is *less* soluble than $\mathrm{KHCO_3}$, $\mathrm{RbHCO_3}$, and $\mathrm{CsHCO_3}$ — a trend that *cannot* be explained by simple polarisation (Na⁺ is the smallest, most polarising alkali cation here, which would naively predict *more* covalent character and unpredictable solubility behaviour, not a clean lattice-packing story). The real explanation is structural: $\mathrm{HCO_3^-}$ ions associate into polymeric chains via hydrogen bonding in the solid, creating cavities of a specific size that fit $\mathrm{Na^+}$ particularly well, giving $\mathrm{NaHCO_3}$ an unusually favourable (low-solubility) lattice packing independent of simple polarisation reasoning — this is a genuine limitation, not a failure to apply the rules correctly.
3. **They do not, by themselves, explain every solubility anomaly.** $\mathrm{KI}$ is soluble in acetone while $\mathrm{NaCl}$ and $\mathrm{KCl}$ are not, reflecting the joint influence of both lattice energy and solvent polarity/dielectric constant (§3.6) rather than covalent character alone.

> **Model Limitation**
> Fajans' rules describe *why* covalent character should increase with certain size/charge/configuration combinations, but they say nothing about *how much* — and in cases where a second effect (lattice packing geometry, hydrogen bonding, specific hydration structure) is comparably large, that second effect can dominate the observed trend. Always check whether an observed exception is genuinely inconsistent with Fajans' reasoning, or whether it reflects a *different* physical effect operating alongside (not instead of) polarisation.

**A further consequence worth flagging: covalent character can extend beyond individual molecules into extended solid-state structures.** Source-verified (`Chemical_Bonding_Kohinoor_.pdf` p.239, re-examined at higher resolution after an earlier pass in this project marked it unresolved): highly polarising, small, high-charge-density metal fluorides do not always form simple ionic lattices or simple molecular units — they can instead form **extended bridged networks** built from $\mathrm{MF_6}$ octahedra sharing fluorine vertices, exactly the same bridging principle already established for $\mathrm{Al_2Cl_6}$ (§2.7a) and $\mathrm{Be_2Cl_4}$/$\mathrm{(BeCl_2)_n}$ (§2.7a), but now extended over many more centres: $\mathrm{SnF_4}$ and $\mathrm{PbF_4}$ form a 2D layer structure (each $\mathrm{MF_6}$ octahedron sharing 4 of its 6 equatorial F vertices with neighbouring octahedra), while $\mathrm{AlF_5}$/$\mathrm{FeF_5}$-type species form a 3D, ReO₃-type network (each octahedron sharing all 6 vertices). This is the same covalent-character/bridging continuum already established for molecular dimers, simply extended to a macroscopic, solid-state scale — a genuinely useful bridge to keep in mind, without duplicating the dedicated Solid State chapter's full treatment (per this chapter's own scope discipline, §12's closing Model Limitation box).

### Part 4 Summary

- Polarisation is the real, physical distortion of an anion's electron cloud by a neighbouring cation's electric field, and it is the literal mechanism by which a nominally ionic bond gains covalent character — not a separate, unrelated phenomenon.
- Fajans' four rules (small cation, large anion, high charge, non-noble-gas cation configuration) all increase polarisation and hence covalent character; ionic potential $\phi = z^+/r$ quantifies the cation side of rules 1 and 3 in one number.
- Pseudo-noble-gas cations (Cu⁺, Ag⁺, Zn²⁺, Cd²⁺, Hg²⁺) are more strongly polarising than their raw size/charge would suggest, because a $d^{10}$ shell shields nuclear charge less effectively than a true noble-gas $p^6$ shell — this is Fajans' fourth rule and the direct explanation for NaCl-vs-CuCl-type comparisons.
- Increasing covalent character systematically lowers melting/boiling point and water solubility, raises non-polar-solvent solubility, intensifies colour, and increases oxide acidity — all traceable to the same underlying cause (more electron density concentrated between the ions).
- The rules are a reliable first-approximation tool, not an exhaustive explanation — lattice-packing geometry and hydrogen-bonding effects (e.g., the alkali bicarbonate solubility order) can produce genuine exceptions that require separate structural reasoning.

---

## Source Traceability — Part 4

| Source PDF | Pages | Material found | Destination | Status |
|---|---|---|---|---|
| `CHEMICAL_BONDING.pdf` | §3.24 (Polarizing Power and Polarizability – Fajans' Rules), §3.25 (Melting Point), §3.26 (Solubility), §3.27 (Electrical Conductivity and Colour), §3.28 (Acidic Nature of Oxides), §3.29 (Thermal Stability) | Full Fajans' rules statement, exceptions table (Zn²⁺<Cd²⁺<Hg²⁺ polarizing power anomaly already used in §2.1), melting-point/solubility comparison tables, oxide acidity via ionic potential, colour trends (AgCl/AgBr/AgI/PbI₂/HgI₂) | §4.2–4.7 | INCORPORATED |
| `Chemical_Bonding_Kohinoor_.pdf` | pp. 216, 217, 219, 220, 230, 237, 238, 239, 240, 241 (all opened and read in full this pass) | Fajans' rule statement and mechanism (p.216); ionic potential and factor table (p.217); AgX solubility/colour, oxide basicity thresholds (p.219); melting-point comparison table, KI/LiCl organic-solvent solubility exceptions (p.220); ion–induced-dipole and London-force trends (p.230, reserved for Part 11); Kapustinskii equation, MgO/CaO/SrO/BaO lattice-energy-vs-melting-point (p.237); alkali halide M.P. data table (p.238); MFₙ layer/network structures (p.239, resolved on re-rasterization at 250 DPI — see §4.7); solubility molar-value table, bicarbonate solid-state exception (pp.240–241) | §4.2, 4.3, 4.6, 4.7 | INCORPORATED (all pages, including p.239) |
| `cbvj.pdf`, `Chemical Bonding (E)/1–12.pdf` | Already fully screened (422/422 pages, prior turns); **re-screened this pass against your expanded keyword list** (`fajan, polaris*, covalent character, ionic character, pseudo noble, d10, cucl, agcl, lii, lif, alcl3, becl2, halide, melting point, solubility, thermal stability`) | 12 additional pages flagged; individually opened: `cbvj.pdf` p.99 (pseudo-noble-gas cation, shielding order s>p>d>f — **duplicate**, already incorporated via p.100 in §2.1); p.118 (colour trends: PbI₂/PbCl₂, HgI₂/HgCl₂, AgCl/AgBr/AgI — **genuinely new**, now incorporated above); p.126 (solubility-down-group ordering for perchlorate/chlorate/sulfite/sulfate/thiosulfate/chromate series — real content, but belongs to Part 3 §3.6 scope, not Part 4; **flagged as PENDING**, not force-fit here); p.13, p.34, p.58, p.61, p.73, p.129, p.135, p.140 (matched only on short substrings "lif"/"lii" inside unrelated OCR-garbled words, e.g. p.13 is actually about hydride boiling points — **false positives, confirmed by opening each, no genuine Fajans/polarisation content**) | §4.5 (colour example); Part 3 (pending addition) | INCORPORATED (p.118); PENDING LATER PART (p.126 → retrofit into Part 3 §3.6 when that Part is next revised); IRRELEVANT (p.99 duplicate, pp.13/34/58/61/73/129/135/140 false positives) |

---

*Part 4 complete. Continuing to Part 5 (Bond Parameters, Electronegativity, Dipole Moment).*
## Part 5 — Bond Parameters and Molecular Polarity

### 5.1 Bond Length

**Bond length** is the equilibrium internuclear distance $r_0$ introduced in §1.2 — the separation at which the potential-energy curve reaches its minimum. It is measured directly (X-ray diffraction, microwave/rotational spectroscopy) and can also be estimated as the sum of the two atoms' **covalent radii**, each defined as half the bond length in a symmetric homonuclear molecule of that element (e.g., $r_{\mathrm{cov}}(\mathrm{Cl}) = \tfrac{1}{2} d(\mathrm{Cl-Cl})$).

**Bond order and bond length.** For a given pair of atoms, higher bond order means more shared electron density concentrated between the nuclei (§2.2), which pulls the nuclei closer together — bond length falls as bond order rises. Verified numerically (`Chemical_Bonding_Kohinoor_.pdf` p.142):

$$\mathrm{C{\equiv}C \; (BO=3,\ C_2H_2) < C{=}C \; (BO=2,\ C_2H_4) < C{\cdots}C \; (BO=1.5,\ C_6H_6) < C{-}C \; (BO=1,\ C_2H_6)}$$

in bond length (shortest to longest), and equivalently for the carbon–oxygen series:

$$\mathrm{CO \; (BO=3) < CO_2 \; (BO=2) < CO_3^{2-} \; (BO=1.33)}$$

in bond length. This is the same relationship stated in Worked Example 2.3's resonance discussion (fractional bond order in $\mathrm{NO_3^-}$, bond order $4/3$) and will recur as the organizing principle for bond-length ordering questions throughout Part 13.

### 5.2 Bond Angle

Bond angle is the angle subtended at the central atom between two of its bonds. It is controlled primarily by electron-domain repulsion (developed fully as VSEPR theory in Part 9); here it is introduced only as a measurable bond parameter, with the general statement that increasing lone-pair character on the central atom, or increasing s-character in the bonding hybrid orbital, systematically affects the angle (Bent's rule, Part 8) — both threads are picked up in full in their dedicated Parts.

### 5.3 Bond Dissociation Enthalpy and Mean Bond Enthalpy

**Bond dissociation enthalpy** is the energy required to break one specific bond in a specific molecule into gaseous atoms/fragments, holding everything else fixed. For a polyatomic molecule with several chemically identical-looking bonds, the dissociation enthalpy of the *first* bond broken is generally different from that of the *second*, *third*, etc., because breaking one bond changes the electronic environment of the remaining ones.

**Mean bond enthalpy** is the *average* of the successive dissociation enthalpies for chemically equivalent bonds in a given type of molecule, and it is this averaged quantity — not any single dissociation step — that is tabulated as "the" C–H bond enthalpy, O–H bond enthalpy, etc., for use in Hess's-law-type enthalpy estimates.

> **Important Conceptual Distinction** — Bond dissociation enthalpy (one specific, measurable bond-breaking step) and mean bond enthalpy (an average over several such steps for a class of bonds) are frequently conflated. A mean bond enthalpy is an estimate useful for approximate calculations; it is not the exact energy of any one real bond-breaking event in a specific molecule.

Bond enthalpy is systematically affected by:
- **Bond order** — higher order, stronger bond (§5.1's ordering logic applies equally to bond strength as to bond length: $\mathrm{C \equiv C > C = C > C - C}$ in bond enthalpy).
- **Atomic size** — smaller atoms generally give shorter, stronger bonds (more effective orbital overlap at closer range, §1.2).
- **Bond polarity** — a polar bond is often (though not universally) somewhat stronger than the purely covalent, non-polar prediction would suggest, because the ionic-resonance-energy contribution (Part 6) adds extra stabilization.

**Worked example 5.1 — Numerical bond-length/BDE cross-check**

*Problem:* Using the data $r$(HF) shorter than $r$(HCl), and $D$(HF) $>$ $D$(HCl) $>$ $D$(HBr) $>$ $D$(HI) (all confirmed against `Chemical_Bonding_Kohinoor_.pdf` p.144's tabulated X–H bond-length/dissociation-energy data), explain the trend.

*Reasoning:* Descending the halogen group, atomic (and hence covalent) radius increases substantially (F<Cl<Br<I), so H–X bond length increases correspondingly. Longer bond length means less effective orbital overlap (§1.2's potential-energy-well argument: a shallower, wider well for a longer, weaker bond), so bond dissociation enthalpy falls in step.

*Conclusion:* $r$(H–F) $<$ $r$(H–Cl) $<$ $r$(H–Br) $<$ $r$(H–I), while $D$(H–F) $>$ $D$(H–Cl) $>$ $D$(H–Br) $>$ $D$(H–I) — bond length and bond enthalpy move in *opposite* directions along this series, which is the general rule (shorter ⇒ stronger) rather than an exception.

### 5.4 Electronegativity

**Electronegativity** is the relative tendency of an atom, within a molecule, to attract the shared pair of a covalent bond toward itself. It is a relational property — meaningful only in the context of a bond to another specific atom, unlike an isolated-atom property such as ionization energy.

**Pauling's scale** defines electronegativity operationally from the "excess" bond energy of a polar A–B bond over the geometric mean of the A–A and B–B bond energies — the physical idea being that if A and B had *identical* electronegativity, the A–B bond would simply be the average of the two homonuclear bond strengths; any *extra* stabilization beyond that average reflects the additional ionic-resonance-energy contribution from unequal sharing (Part 6 revisits this same "extra stabilization from charge separation" idea in the context of resonance energy generally).

$$\chi_A - \chi_B \propto \sqrt{E_{AB} - \sqrt{E_{AA}\cdot E_{BB}}}$$

Electronegativity, as a general trend, increases across a period (increasing nuclear charge, roughly constant shielding, so valence electrons are held more tightly) and decreases down a group (increasing atomic size and shielding outweigh the increased nuclear charge).

### 5.5 Bond Polarity, Dipole Moment, and Percentage Ionic Character

**Bond polarity** arises whenever two bonded atoms differ in electronegativity: the shared electron pair is not shared equally, and a partial negative charge $\delta^-$ develops on the more electronegative atom, with a corresponding partial positive charge $\delta^+$ on the other.

**Dipole moment** quantifies this charge separation:

$$\mu = q \times d$$

where $q$ is the magnitude of the separated charge and $d$ is the distance between the charge centres. Dipole moment is a **vector quantity**, conventionally drawn from the less electronegative to the more electronegative atom (i.e., pointing toward the negative end), measured in **debye** ($1\text{ D} = 10^{-18}\text{ esu cm} = 3.33\times10^{-30}\text{ C m}$).

**Bond moment vs. molecular dipole moment.** For a diatomic molecule, the bond moment *is* the molecular dipole moment. For a polyatomic molecule, the overall molecular dipole moment is the **vector sum** of every individual bond moment *and* every lone-pair moment present — this is the direct link between dipole moment (a bulk, measurable property) and molecular shape (Part 9), since vector addition depends entirely on the geometric arrangement of the bonds and lone pairs.

**Lone-pair moment.** A lone pair occupying a pure $s$ or pure $p$ orbital contributes nothing to the net dipole moment (an $s$ orbital is spherically symmetric; a pure $p$ orbital's two lobes point in exactly opposite directions and cancel). A lone pair occupying a **hybrid** orbital, however, is asymmetric (§1.8-style "one lobe small, one lobe large" hybrid-orbital shape) and contributes a real, often substantial, moment directed from the small lobe toward the large lobe.

**Worked example 5.2 — Why NH₃ has a much larger dipole moment than NF₃, despite similar bond-electronegativity differences**

*Problem:* $\Delta\chi(\mathrm{N-H}) \approx 0.9$ and $\Delta\chi(\mathrm{N-F}) \approx 1.0$ — comparable electronegativity differences — yet $\mu(\mathrm{NH_3}) = 1.47\text{ D}$ while $\mu(\mathrm{NF_3}) = 0.24\text{ D}$, a six-fold difference. Explain.

*Reasoning:* In both molecules, N carries a lone pair in a hybrid orbital pointing away from the three bonded atoms, contributing a lone-pair moment $\mu_L$ directed away from the bonding face (toward the "top" of the pyramid, in the direction of the lone pair). The bond-moment resultant $\mu_R$ (vector sum of the three N–X bond moments) also points along this same axis, but its *direction relative to N* depends on which atom is more electronegative:
- In $\mathrm{NH_3}$, N is more electronegative than H, so each N–H bond moment points *toward* N (away from the H atoms). This resultant $\mu_R$ points in the *same general direction* as the lone-pair moment $\mu_L$ — **they add**, giving a large net dipole moment.
- In $\mathrm{NF_3}$, F is more electronegative than N, so each N–F bond moment points *away from* N (toward the F atoms) — the *opposite* direction to the $\mathrm{NH_3}$ case. This resultant **opposes** the lone-pair moment $\mu_L$ — the two largely **cancel**, leaving only a small net dipole moment.

*Conclusion:* the six-fold difference is not primarily a story about electronegativity-difference magnitude (which is comparable in both cases) — it is a story about the *relative direction* of the bond-moment resultant versus the lone-pair moment, which flips depending on whether the central atom is more or less electronegative than its substituents. The same reasoning applies directly to $\mathrm{H_2O}$ ($\mu = 1.84\text{ D}$, bond and lone-pair moments add) vs. $\mathrm{F_2O}$ ($\mu = 0.30\text{ D}$, bond and lone-pair moments oppose).

![Figure 5.1: Dipole vectors in NH3 vs NF3](figures/fig5_1_dipole_nh3_nf3.svg)

**Figure 5.1.** Bond-moment resultant (green) and lone-pair moment (red) add in NH₃ (N more electronegative than the substituent) but oppose in NF₃ (substituent more electronegative than N) — the direction relationship, not the magnitude of $\Delta\chi$ alone, controls the large observed difference in net dipole moment.

*Common mistake:* trying to explain the NH₃-vs-NF₃ dipole moment gap using electronegativity-difference magnitude alone — a genuinely common error, since the magnitudes are in fact similar and the real explanation is entirely about relative vector direction.

**Worked example 5.3 — Calculating percentage ionic character from dipole moment**

*Problem:* The dipole moment of HCl is $1.03\text{ D}$ and the H–Cl bond length is $1.27\text{ Å}$. Calculate the percentage ionic character of the H–Cl bond.

*Concept tested:* the ratio of the *observed* dipole moment to the dipole moment the bond *would have if it were 100% ionic* (i.e., if a full electronic charge $e$ were completely transferred and separated by the actual bond length) gives the fractional ionic character.

*Reasoning:* First calculate the hypothetical 100%-ionic dipole moment, $\mu_{\text{calc}} = e \times d$:

$$\mu_{\text{calc}} = (4.8\times10^{-10}\text{ esu}) \times (1.27\times10^{-8}\text{ cm}) = 6.10\times10^{-18}\text{ esu cm} = 6.10\text{ D}$$

Then:

$$\%\text{ ionic character} = \dfrac{\mu_{\text{obs}}}{\mu_{\text{calc}}}\times 100 = \dfrac{1.03}{6.10}\times100 = 16.9\%$$

*Conclusion:* the H–Cl bond is approximately 17% ionic and correspondingly about 83% covalent — consistent with chlorine's substantial but not extreme electronegativity relative to hydrogen, and a useful concrete anchor figure for calibrating intuition about what "significant but minority ionic character" looks like numerically in a bond usually classified simply as "polar covalent."

*Common mistake:* forgetting that $\mu_{\text{calc}}$ must use the *electronic charge* $e$ (the 100%-ionic, one-full-charge-transferred hypothetical) rather than any other charge value — the percentage ionic character calculation is specifically a comparison against this one well-defined reference point, not a general formula with a free parameter.

### 5.6 Molecular Shape from Dipole Moment — Symmetry and Cancellation

Because molecular dipole moment is a vector sum, a **non-zero measured dipole moment directly rules out any perfectly symmetric geometry** in which the bond moments would cancel exactly, and this becomes a genuine structure-determination tool:

| Molecular type | $\mu = 0$ implies | $\mu \ne 0$ implies |
|---|---|---|
| $\mathrm{AX_2}$ | Linear (e.g., $\mathrm{BeCl_2}$, $\mathrm{XeF_2}$, $\mathrm{CO_2}$) | Bent/angular (e.g., $\mathrm{H_2O}$, $\mathrm{SO_2}$, $\mathrm{SCl_2}$) |
| $\mathrm{AX_3}$ | Trigonal planar (e.g., $\mathrm{BF_3}$, $\mathrm{AlCl_3}$) | Pyramidal or T-shaped (e.g., $\mathrm{NH_3}$; $\mathrm{ClF_3}$) |
| $\mathrm{AX_4}$ | Tetrahedral or square planar (e.g., $\mathrm{CH_4}$; $\mathrm{XeF_4}$) | See-saw (e.g., $\mathrm{SF_4}$) |
| $\mathrm{AX_5}$ | Trigonal bipyramidal (e.g., $\mathrm{PF_5}$) | Square pyramidal (e.g., $\mathrm{XeF_5^+}$) |
| $\mathrm{AX_6}$ | Regular octahedral (e.g., $\mathrm{SF_6}$) | Distorted (any deviation) |

![Figure 5.2: CO2 dipole cancellation](figures/dipoles/fig_dipole_co2.svg)
![Figure 5.3: BF3 dipole cancellation](figures/dipoles/fig_dipole_bf3.svg)
![Figure 5.4: CH4 dipole cancellation](figures/dipoles/fig_dipole_ch4.svg)

**Figures 5.2–5.4.** Three zero-dipole examples spanning steric numbers 2–4: in every case individual bonds are polar, but the symmetric arrangement forces the vector sum to zero — nonpolar bonds are never the reason (CO₂'s C=O and BF₃'s B–F bonds are both substantially polar); geometry is.

![Figure 5.5: H2O dipole reinforcement](figures/dipoles/fig_dipole_h2o.svg)
![Figure 5.6: XeF4 dipole cancellation](figures/dipoles/fig_dipole_xef4.svg)
![Figure 5.7: SF4 net dipole](figures/dipoles/fig_dipole_sf4.svg)
![Figure 5.8: ClF3 net dipole](figures/dipoles/fig_dipole_clf3.svg)

**Figures 5.5–5.8.** H₂O (bond dipoles and lone-pair-axis moment reinforce, §5.5's mechanism), XeF₄ (perfectly cancels despite bearing lone pairs — the *trans* lone-pair placement established in §9.5 is itself symmetric), and SF₄/ClF₃ (asymmetric electron-domain arrangements with no cancelling symmetry, net dipole shown as the resultant vector) — directly connecting each dipole outcome to the specific VSEPR geometry established in Part 9 for that species.

**Worked example 5.4 — Distinguishing cis and trans isomers by dipole moment**

*Problem:* Two isomers of $\mathrm{N_2F_2}$ exist. One has essentially zero dipole moment; the other has a small but distinctly non-zero dipole moment ($\approx 0.16\text{ D}$). Assign each isomer.

*Reasoning:* In the *trans* isomer, the two N–F bond moments point in opposite directions across the N=N axis and cancel exactly by symmetry — $\mu = 0$. In the *cis* isomer, the two N–F bond moments (and the two nitrogen lone-pair moments) point on the *same* side, so they do not cancel — $\mu \ne 0$.

*Conclusion:* the essentially-zero-dipole isomer is *trans*-$\mathrm{N_2F_2}$; the small-but-nonzero-dipole isomer is *cis*-$\mathrm{N_2F_2}$.

*Common mistake:* assuming a "small" non-zero dipole moment must indicate a highly polar or asymmetric structure — here, the *cis* isomer's dipole moment is small in *absolute* terms (0.16 D) precisely because the two contributing moments only partially reinforce each other (they are not aligned in exactly the same direction), even though the molecule is unambiguously non-centrosymmetric. The qualitative conclusion (zero vs. non-zero) is what carries the structural information, not the precise numerical size of a small non-zero value.

> **Exception — a non-zero dipole moment alone does not uniquely fix a structure.** Two different structural isomers of the same molecular formula (not just cis/trans forms of one connectivity) can each have $\mu \ne 0$, so a non-zero reading only *rules out* the symmetric possibility — it does not, by itself, distinguish between multiple asymmetric candidates without additional structural information (e.g., NMR, IR, or independently known connectivity).

### 5.7 Percentage Ionic Character vs. Ionic Character — A Terminology Distinction

**Important Conceptual Distinction:** "ionic character" (qualitative — is the bond better described as more ionic or more covalent, Ketelaar's triangle, §1.4) and "**percentage** ionic character" (a specific, numerically defined quantity, Worked Example 5.3) are related but not interchangeable terms. A bond can be correctly described qualitatively as "predominantly covalent with some ionic character" while also having a precisely calculable percentage ionic character (e.g., HCl's 17%) — the percentage is the quantitative backbone underneath the qualitative label, not a separate concept.

> **Model Limitation** — The percentage-ionic-character calculation (Worked Example 5.3) assumes the bond length used is accurate and that $e \times d$ is a physically meaningful "fully ionic" reference — both reasonable approximations for simple diatomics, but the method becomes progressively less reliable for polyatomic molecules, where the "bond length" of one specific bond within a larger structure may not isolate cleanly from the rest of the molecule's electronic structure, and where a molecule's overall measured dipole moment reflects the *vector sum* of several bonds (§5.6) rather than any single bond in isolation.

### Part 5 Summary

- Bond length and bond order are inversely related (higher order ⇒ shorter bond) for a given pair of atoms; bond length and bond dissociation enthalpy move in the same "shorter is stronger" direction across a homologous series, and in opposite numerical directions across a series where atomic size is the controlling variable (§5.3).
- Electronegativity (Pauling scale) is a relational, bond-context-dependent property, operationally defined from the "extra" stabilization energy of a polar bond beyond the non-polar reference.
- Dipole moment is a vector sum of bond moments and lone-pair moments; whether these add or cancel — not merely the size of the electronegativity difference — controls the resulting net molecular dipole moment (NH₃ vs. NF₃, Worked Example 5.2).
- Percentage ionic character is calculated as $(\mu_{\text{obs}}/\mu_{\text{calc}})\times100$, where $\mu_{\text{calc}} = e \times d$ is the hypothetical fully-ionic reference (Worked Example 5.3, HCl = 17% ionic).
- A zero net dipole moment is a reliable, specific structural signature of a symmetric geometry and is a genuine shape-determination tool, including for distinguishing cis/trans isomers — but a non-zero reading alone only rules out full symmetry, without uniquely fixing the remaining structure.

---

## Source Traceability — Part 5

| Source PDF | Pages | Material found | Destination | Status |
|---|---|---|---|---|
| `CHEMICAL_BONDING.pdf` | §3.14 (Dipole Moment, full section) | Definition, bond moment, lone-pair moment mechanism and magnitude order (sp>sp²>sp³), NH₃/NF₃ and H₂O/F₂O comparisons, %ionic character formula, AX₂–AX₇ shape-from-dipole-moment table, cis/trans N₂F₂, ortho/meta/para disubstituted benzene dipole ordering, special cases (CO's anomalously low dipole moment, mesomeric-effect reversals) | §5.5, §5.6 | INCORPORATED |
| `Chemical_Bonding_Kohinoor_.pdf` | p.120 (of 261) | HCl %ionic character fully worked numerical example — independently re-derived and verified in this pass, arithmetic confirmed correct | Worked Example 5.3 | INCORPORATED |
| `Chemical_Bonding_Kohinoor_.pdf` | p.142 | Bond-order-vs-bond-length data (C₂H₂/C₂H₄/C₆H₆/C₂H₆; CO/CO₂/CO₃²⁻) | §5.1 | INCORPORATED |
| `Chemical_Bonding_Kohinoor_.pdf` | p.144 | X–H bond-length/dissociation-energy data table across halogens | Worked Example 5.1 | INCORPORATED |
| `Chemical_Bonding_Kohinoor_.pdf` | pp.95, 97, 102, 111 | Bond angle vs. %s-character, C–H bond strength in CH₃Cl/CH₃F, P–Cl bond length in fluorochlorophosphoranes, extensive B/C/N back-bonding bond-length table | Flagged as Part 7/8/9 scope (hybridization, back-bonding) | PENDING LATER PART — not force-fit into Part 5 |
| `cbvj.pdf`, `Chemical Bonding (E)/1–12.pdf` | full existing OCR index re-queried (dipole, electronegativity, bond length, bond order, debye, percentage ionic) | No new material beyond what is already logged in the Parts 1–4 matrix under "bond length" hits (all previously confirmed to belong to Part 7/8/9 scope: overlap types, VSEPR steric number) | — | IRRELEVANT TO PART 5 / already logged elsewhere |

---

*Part 5 complete. Continuing to Part 6 (Resonance and Delocalisation).*
## Part 6 — Resonance and Delocalisation

### 6.1 Why a Single Lewis Structure Becomes Insufficient

The Lewis-structure rules of §2.6 sometimes generate **more than one equally valid structure** for the same molecule or ion — same skeleton, same total electron count, same (minimal, correctly-placed) formal charges — differing only in *which* atom bears a double bond or an extra lone pair. $\mathrm{NO_3^-}$ (Worked Example 2.3) was the first example: any one of its three oxygen atoms could equally well be the doubly-bonded one.

When this happens, choosing any *single* one of these structures as "the" structure is actively misleading, because the real, experimentally observed molecule does not match any single candidate — $\mathrm{NO_3^-}$'s three N–O bonds are all experimentally identical in length (§2.6, Worked Example 2.3), not two short and one long as any individual canonical structure would suggest. **Resonance** is the recognition that the true electronic structure is a single, unique hybrid of all such valid contributing structures simultaneously, not a molecule that switches between them.

> **Why? (what resonance actually is, mechanistically)**
> A single Lewis structure localizes each bonding electron pair between one specific pair of atoms. In a resonance-stabilized species, the real electron distribution is **delocalized** — spread out over more than two atoms at once — which is a genuinely lower-energy arrangement than any single localized structure would achieve, precisely because delocalized electrons occupy a larger region of space and are attracted to *more* nuclei simultaneously (the same core stabilization logic as ordinary bond formation, §1.1, now extended from two nuclei to three or more). The energy by which the true delocalized structure is more stable than the *most stable single contributing structure* is called the **resonance energy** (or delocalisation energy).

### 6.2 Rules for Valid Resonance Contributors

Not every structure sharing a molecular formula with another is a valid resonance contributor. Valid canonical structures must satisfy all of the following simultaneously:

1. **Identical arrangement of atomic nuclei (fixed skeleton).** Only the placement of electrons (bonding pairs, lone pairs) may differ between contributors — no atom may move. This is the single most important rule, and the one most often violated by beginners: moving an atom, even slightly, does not generate a resonance structure, it generates a *different compound* (or, if the same formula, a structural isomer, not a resonance form).
2. **Identical number of paired and unpaired electrons.** All contributors must have the same total electron count and, for closed-shell species, no contributor may introduce unpaired electrons that another lacks.
3. **Comparable energy.** Contributors that require large charge separation, place like charges on adjacent atoms, or place negative charge on a less-electronegative atom (§2.6, rules 7–8) are valid in the formal sense but contribute little to the real hybrid — they are "minor" contributors, not equally weighted with the dominant structures.
4. **Each contributor must individually be a chemically reasonable Lewis structure** — correct valence-electron count, satisfying the octet rule (or a recognized, separately justified exception).

**Equivalent vs. non-equivalent contributors.** Contributors are **equivalent** if they are related by a symmetry operation of the molecule (e.g., $\mathrm{NO_3^-}$'s three structures, related by which of the three chemically identical O atoms bears the double bond) — equivalent contributors are, by definition, equally stable and contribute *equally* to the hybrid, and bond-length equalization (§6.4) follows directly. Contributors are **non-equivalent** if they differ in formal-charge distribution, bond arrangement, or stability in a way not related by symmetry (e.g., the two $\mathrm{N_2O}$ structures below) — non-equivalent contributors contribute *unequally*, with the lower-energy (generally lower-formal-charge, better-placed-charge) structure weighted more heavily in the real hybrid.

> **Common Trap** — "More resonance structures always means more stability" is an oversimplification. Only contributors that are individually reasonable (rule 3 and 4 above) add meaningfully to the resonance energy; drawing additional, high-energy, poorly-charge-separated structures does not meaningfully lower the true energy of the hybrid, even though they are, strictly, "formally valid" by rules 1–2.

### 6.3 The Resonance Hybrid and Fractional Bond Order

The **resonance hybrid** is the single, true, weighted-average electronic structure — not a real physical mixture of the separate canonical forms existing at different moments, but the one actual structure the canonical forms are collectively an imperfect notational attempt to represent. For a set of $n$ equivalent contributors, the **average bond order** for a given bond position is (verified against `Chemical_Bonding_Kohinoor_.pdf` p.140):

$$\text{Bond order (averaged)} = \dfrac{\text{number of bonds between that pair of atoms, summed across all contributors}}{\text{total number of contributors}}$$

For $\mathrm{NO_3^-}$: each of the three N–O positions is a double bond in exactly one of the three equivalent contributors and a single bond in the other two, giving bond order $= (1\times2 + 2\times1)/3 = 4/3$ for every N–O bond — matching the intermediate, equal bond length already established in Worked Example 2.3.

> **Common Trap — resonance is not equilibrium, and canonical structures are not interconverting real species.** Do not write $\rightleftharpoons$ between resonance structures (reserved for genuine chemical equilibria between distinct, separately-existing species, §1.4-adjacent) — use only the double-headed resonance arrow $\leftrightarrow$. There is only **one** real molecule/ion with **one** true (delocalized) electronic structure; the several canonical drawings are alternative *notations* for that one structure, not alternative *states* the molecule physically visits over time.

> **Important Conceptual Distinction — resonance vs. tautomerism.** Resonance structures differ only in electron placement over a fixed nuclear skeleton (§6.2, rule 1) and are not separate, isolable species — you cannot "trap" one resonance structure. Tautomers (e.g., keto and enol forms) differ in the actual position of at least one atom (typically a proton) and *are* genuinely distinct, separately-existing (if often rapidly interconverting) chemical species related by an ordinary equilibrium, correctly written with $\rightleftharpoons$. Confusing these two is one of the most consequential terminology errors in this topic, because it leads directly to the "resonance structures rapidly interconvert" misconception explicitly flagged above.

### 6.4 Bond-Length Equalization as Experimental Evidence for Resonance

Because the resonance hybrid is the single true structure, every bond position that is equivalent across all major contributors is observed experimentally as a single, averaged bond length — never as two (or more) distinct lengths corresponding to the individual canonical drawings. This experimental equalization (already used as direct evidence in Worked Example 2.3 for $\mathrm{NO_3^-}$, and numerically confirmed for $\mathrm{CO_3^{2-}}$ below) is the primary real-world justification for treating resonance as a description of one true delocalized structure rather than a notational convenience with no physical content.

### 6.5 Fully Worked Resonance Structures

**Worked example 6.1 — Ozone, O₃ (non-equivalent lone-pair/bonding arrangement, equivalent overall contributors)**

Total valence electrons $= 3(6) = 18$. Skeleton: bent O–O–O (central O bonded to two terminal O). Two equivalent canonical structures exist, related by which terminal O bears the double bond:

Central O: 1 lone pair, one O=O double bond, one O–O single bond ($N=2, B=6$): $FC = 6-2-3 = +1$.
Doubly-bonded terminal O: 2 lone pairs ($N=4, B=4$): $FC = 6-4-2 = 0$.
Singly-bonded terminal O: 3 lone pairs ($N=6, B=2$): $FC = 6-6-1 = -1$.

Sum $= +1+0-1 = 0$ ✓ (neutral molecule). The two contributors are equivalent (related by the molecule's own mirror symmetry), so each O–O bond has average bond order $3/2$, consistent with the experimentally observed O–O bond length in ozone (128 pm) lying between a typical O–O single bond (148 pm) and O=O double bond (121 pm).

*Common mistake:* drawing ozone as $\mathrm{O=O=O}$ (both bonds double, no charge separation) — this uses $4+4+4(\text{lone pairs on ends})+0 = $ let us check: two double bonds $=8$ bonding electrons, terminal O's would need 2 lone pairs each ($4+4=8$ non-bonding), central O 0 lone pairs; total $=8+8=16 \ne 18$, failing the valence-electron count outright, and additionally leaving the central O with only 8 electrons but *zero* lone pairs while requiring $sp$ hybridization inconsistent with ozone's known bent (not linear) shape (Part 9). This structure is simply wrong, not merely a minor contributor — a useful reminder that the valence-electron count check (§2.6, rule 1) must be applied to *every* candidate structure, not assumed satisfied by symmetry alone.

**Worked example 6.2 — Carbonate, CO₃²⁻ (three equivalent contributors)**

Total valence electrons $= 4 + 3(6) + 2 = 24$. C central, bonded to three O; one C=O double bond and two C–O single bonds, three equivalent resonance structures (double bond rotating among the three O atoms).

C: $B=8$ (one double + two single bonds), $N=0$: $FC = 4-0-4 = 0$.
Doubly-bonded O: $N=4, B=4$: $FC=0$.
Each singly-bonded O (×2): $N=6, B=2$: $FC = -1$.

Sum $= 0+0-1-1 = -2$ ✓. Average C–O bond order $= (1\times2+2\times1)/3 = 4/3$ for every bond — and indeed all three C–O bonds in $\mathrm{CO_3^{2-}}$ are experimentally equal (129 pm), intermediate between a C–O single bond (143 pm) and C=O double bond (120 pm), the same pattern already established for $\mathrm{NO_3^-}$.

**Worked example 6.3 — Bicarbonate, HCO₃⁻ (resonance restricted by the added H)**

Total valence electrons $= 1 + 4 + 3(6) + 1 = 24$. Structure: C bonded to one –OH group (O–H single bond, O also single-bonded to C), one C=O double bond, and one C–O⁻ single bond; **only two** of the three oxygens (the non-hydroxyl ones) participate in resonance with each other — the hydroxyl oxygen's bonding is fixed by the H atom.

C: $B=8, N=0$: $FC=0$. Hydroxyl O (bonded to C and H): $N=4, B=4$: $FC=6-4-2=0$. Doubly-bonded O: $FC=0$. Singly-bonded (anionic) O: $N=6,B=2$: $FC=-1$.

Sum $=0+0+0-1=-1$ ✓. **Only the two non-hydroxyl C–O bonds are resonance-equalized** (average bond order $3/2$ between just those two positions); the C–OH bond is chemically and structurally distinct (a genuine single bond, not part of the delocalized resonance system) — this is the direct, worked illustration of why HCO₃⁻ is a useful case for the general point that resonance equalizes only the bonds that are genuinely equivalent across the valid contributors, not every bond in the ion indiscriminately.

**Worked example 6.4 — N₂O (non-equivalent contributors, unequal weighting)**

Total valence electrons $= 2(5)+6 = 16$. Linear skeleton N–N–O (**not** N–O–N — a frequently tested connectivity trap). Two non-equivalent canonical structures:

*(a)* $\mathrm{{:}N{\equiv}N{-}O{:}}$: terminal N ($B=6,N=2$): $FC=5-2-3=0$; central N ($B=8,N=0$): $FC=5-0-4=+1$; O ($B=2,N=6$): $FC=6-6-1=-1$. Sum $=0+1-1=0$ ✓.
*(b)* $\mathrm{{:}N{=}N{=}O{:}}$: terminal N ($B=4,N=4$): $FC=5-4-2=-1$; central N ($B=8,N=0$): $FC=+1$; O ($B=4,N=4$): $FC=6-4-2=0$. Sum $=-1+1+0=0$ ✓.

Both are individually valid, but they are **non-equivalent** — structure (a) places the formal negative charge on O (more electronegative, favoured by §2.6 rule 7) while structure (b) places it on the terminal N (less electronegative, disfavoured). By the same electronegativity-placement logic applied throughout §2.6 and Worked Example 2.6 (SCN⁻), **structure (a) is the major contributor**, consistent with $\mathrm{N_2O}$'s common depiction as $\mathrm{N \equiv N^+ {-} O^-}$ in most standard references, though real N₂O shows measurable contribution from both forms (its N–N bond, at 113 pm, is shorter than a typical N=N double bond, ~125 pm, and closer to the N≡N triple-bond length in structure (a), consistent with (a) dominating but not being the sole contributor).

**Worked example 6.5 — SO₂ and SO₃, contrasted**

$\mathrm{SO_2}$ (18 valence electrons): bent, S with 1 lone pair, one S=O double bond and one S–O single bond (two equivalent resonance structures, double bond alternating between the two O atoms). S: $N=2, B=6$: $FC=6-2-3=+1$. Doubly-bonded O: $FC=0$. Singly-bonded O: $FC=6-6-1=-1$. Sum $=+1+0-1=0$ ✓. Average S–O bond order $3/2$.

$\mathrm{SO_3}$ (24 valence electrons): trigonal planar, and — unlike $\mathrm{SO_2}$ — the simplest valid Lewis structure already places **three S=O double bonds** directly (S: $B=12, N=0$: $FC=6-0-6=0$; each O: $N=4,B=4$: $FC=0$; sum $=0$ ✓), giving bond order $2$ for every S–O bond **without needing resonance to explain the equal bond lengths** — the symmetric all-double-bond structure is already the most stable single contributor and already fully consistent with the observed $D_{3h}$ symmetry and equal S–O bond lengths (142 pm, shorter than $\mathrm{SO_2}$'s averaged 143 pm S–O bond order-$3/2$ length, consistent with $\mathrm{SO_3}$'s higher bond order).

> **Compare** — $\mathrm{SO_2}$ genuinely *requires* resonance (two non-identical-looking but equivalent contributors) to explain its equal bond lengths, while $\mathrm{SO_3}$'s equal bond lengths follow already from a *single*, symmetric, expanded-octet structure. This is a useful discipline-check: before invoking resonance, always first ask whether a single valid Lewis structure already explains the observed symmetry — resonance is invoked only when it is genuinely necessary, not reflexively for every molecule with more than one heteroatom.

**Worked example 6.6 — Oxo-anions of chlorine: ClO₂⁻, ClO₃⁻, ClO₄⁻**

All three follow the same pattern as $\mathrm{SO_3}$ above — the lowest-formal-charge structure places as many Cl=O double bonds as the expanded octet permits, with resonance then equalizing the remaining bond(s):

$\mathrm{ClO_2^-}$ (20 valence e⁻): one Cl=O, one Cl–O, 2 lone pairs on Cl (two equivalent resonance forms). Cl: $N=4,B=6$: $FC=7-4-3=0$. Double-bonded O: $FC=0$. Single-bonded O: $FC=-1$. Sum $=-1$ ✓. Average Cl–O bond order $3/2$.

$\mathrm{ClO_3^-}$ (26 valence e⁻): two Cl=O, one Cl–O, 1 lone pair on Cl (three equivalent resonance forms). Cl: $N=2, B=10$: $FC=7-2-5=0$. Doubly-bonded O (×2): $FC=0$. Singly-bonded O: $FC=-1$. Sum $=-1$ ✓. Average Cl–O bond order $= (2\times2+1\times1)/3 = 5/3$.

$\mathrm{ClO_4^-}$ (32 valence e⁻): three Cl=O, one Cl–O, no lone pair on Cl (four equivalent resonance forms). Cl: $N=0,B=14$: $FC=7-0-7=0$. Doubly-bonded O (×3): $FC=0$. Singly-bonded O: $FC=-1$. Sum $=-1$ ✓. Average Cl–O bond order $=(3\times2+1\times1)/4=7/4$.

*JEE Advanced Insight:* this series is a clean, self-consistent illustration that increasing the number of terminal O atoms on the same central atom (with the same central-atom charge accommodation) systematically increases the *average* bond order per Cl–O bond, which is the direct explanation for why Cl–O bond length shortens smoothly across $\mathrm{ClO^- > ClO_2^- > ClO_3^- > ClO_4^-}$ — a frequently tested bond-length ordering question, now derivable from first principles rather than requiring memorization.

**Worked example 6.7 — Cyanate, OCN⁻ (linear, cross-referencing SCN⁻)**

Total valence electrons $= 6+4+5+1 = 16$. Linear O–C–N skeleton. Dominant structure (by the same electronegativity-placement reasoning as $\mathrm{SCN^-}$, Worked Example 2.6, and $\mathrm{N_2O}$, Worked Example 6.4, above): $\mathrm{O{=}C{=}N^-}$. O: $N=4,B=4$: $FC=6-4-2=0$. C: $N=0,B=8$: $FC=4-0-4=0$. N: $N=4,B=4$: $FC=5-4-2=-1$. Sum $=0+0-1=-1$ ✓ — negative formal charge correctly placed on N, the more electronegative of the two terminal atoms compared to C, consistent with the same rule used throughout this Part.

### 6.6 Resonance in Odd-Electron Species

Odd-electron species (§2.7c) can also show resonance. $\mathrm{NO_2}$ (already introduced in §2.10) is the standard example: two equivalent contributors interchange which oxygen carries the N=O double bond and which carries the $-1$ formal charge (mirroring the $\mathrm{O_3}$ pattern above), so the negative charge and the π bonding are delocalized over both oxygens — while the **unpaired electron remains principally on nitrogen** in both major contributors (minor contributors place some radical density on O). This N-centred radical density is exactly why $\mathrm{NO_2}$ dimerizes through an **N–N bond**, giving $\mathrm{O_2N{-}NO_2}$ ($\mathrm{N_2O_4}$) — consistent with §2.7c, which already attributed the dimerization to the pairing of the two N-centred odd electrons.

### 6.7 Limitations of Simplistic Resonance Rules

1. **Formal charge minimization alone does not always identify the true major contributor** (§2.6's own caveat, revisited): in cases where several structures have comparably small formal charges, additional factors — actual bond strength trends, experimental bond-length data, and (beyond the scope of simple electron counting) computed electron-delocalization energies — are needed to assign relative weighting with confidence.
2. **Not every pair of "similar-looking" structures is a valid resonance pair** — §6.2's skeleton-fixed rule is absolute; a common error is treating structural or geometric isomers (genuinely different compounds) as if they were resonance forms of one compound.
3. **Resonance energy is not directly measurable as a single clean experimental quantity** — it is typically *inferred* indirectly, by comparing an experimentally measured property (such as heat of hydrogenation, or lattice energy via the Born–Haber-cycle-style comparison already used for ionic-vs-covalent character in §3.4) against a hypothetical non-delocalized reference structure's predicted value; the difference is attributed to resonance stabilization, but this inference depends on how the non-resonating reference is modelled.

### Part 6 Summary

- Resonance describes one real, delocalized electronic structure using several fixed-skeleton, electron-arrangement-only canonical drawings; the double-headed arrow ($\leftrightarrow$) and the explicit statement "these are not interconverting real species" are both essential, not optional, notation.
- Valid contributors share atomic positions and total electron count; equivalent contributors (related by molecular symmetry) weight equally, non-equivalent contributors weight by relative stability (formal charge magnitude and placement, §2.6's rules 7–8 reused directly).
- Average bond order $=$ (bonds at that position, summed over all contributors) $/$ (number of contributors) — directly explains experimentally observed bond-length equalization, worked explicitly for O₃, CO₃²⁻, HCO₃⁻ (partial equalization only), N₂O, SO₂ (resonance-requiring) vs. SO₃ (single-structure-sufficient), and the ClO₂⁻/ClO₃⁻/ClO₄⁻ series (systematic bond-order-driven bond-length trend).
- Resonance is categorically distinct from both chemical equilibrium (separate, isolable species, $\rightleftharpoons$) and tautomerism (genuine atom/proton repositioning, also $\rightleftharpoons$) — conflating these is the single most consequential terminology error in this topic.

---

## Source Traceability — Part 6

| Source PDF | Pages | Material found | Destination | Status |
|---|---|---|---|---|
| `Chemical_Bonding_Kohinoor_.pdf` | p.140 (of 261) | Resonance definition, average-bond-order formula (verified and directly used), CO₂ bond-length-intermediate example (not force-fit, CO₂ is not itself a resonance case — noted and correctly excluded), CO₃²⁻ equal-bond-length statement | §6.1, §6.3 | INCORPORATED |
| `Chemical_Bonding_Kohinoor_.pdf` | p.215, p.237 (SCN keyword hits) | Cross-reference confirmation only — same content already incorporated via Worked Example 2.6 in Part 2 | — | DUPLICATE — already covered in §2.6 |
| `Chemical_Bonding_Kohinoor_.pdf` | pp.74, 171 | π-electron delocalisation effects, VBT limitations (already used in Part 2's §2.9 cross-reference) | — | DUPLICATE — already covered |
| `CHEMICAL_BONDING.pdf` | (full text checked; no dedicated resonance section exists in this source's table of contents, §3.1–3.34) | — | — | IRRELEVANT — source does not cover resonance as a separate topic; Part 6 is therefore built primarily from Kohinoor plus independently-derived, hand-verified structures rather than heavily sourced from this PDF |
| `cbvj.pdf`, `Chemical Bonding (E)/1–12.pdf` | full existing OCR index re-queried (resonance, canonical, delocali, hybrid structure) | No hits beyond what is already logged (SCN-related pages already covered in Part 2's matrix) | — | IRRELEVANT TO PART 6 |
| Independently derived (not sourced from any single PDF) | — | O₃, CO₃²⁻, HCO₃⁻, SO₂, SO₃, N₂O, ClO₂⁻/ClO₃⁻/ClO₄⁻, OCN⁻ — all electron counts and formal charges computed and self-checked before writing | §6.5, Worked Examples 6.1–6.7 | INCORPORATED, independently verified |

---

*Part 6 complete. Continuing to Part 7 (Valence Bond Theory and Orbital Overlap).*
## Part 7 — Valence Bond Theory and Orbital Overlap

### 7.1 The Overlap Concept

Valence bond theory (VBT) describes covalent bond formation as arising from the **overlap** of atomic orbitals, each contributing one unpaired electron of opposite spin. As two atoms approach, their orbitals begin to occupy a shared region of space; within that shared (overlapping) region, the wave functions of the two atomic orbitals combine, concentrating electron density between the two nuclei — the same physical outcome already established qualitatively in §1.1 and §2.2, now given a specific orbital-level mechanism.

Two conditions must both be satisfied for overlap to be **constructive** (bond-forming) rather than destructive:

1. **Same sign (phase) of the two wave function lobes** in the overlapping region. Combining lobes of the same sign reinforces the wave function, raising electron density between the nuclei. Combining lobes of opposite sign causes destructive interference, creating a **node** (a region of zero electron density) between the nuclei — this does not lower the system's energy and does not constitute a bond.

![Figure 7.2a: s-s bonding overlap](figures/orbitals/fig_overlap_ss_bonding.svg)
![Figure 7.2b: s-s antibonding overlap](figures/orbitals/fig_overlap_ss_antibonding.svg)

**Figure 7.2.** Same-phase overlap (7.2a) reinforces electron density between the nuclei — bonding. Opposite-phase overlap (7.2b) creates a node between the nuclei — antibonding, higher in energy. This same phase logic is what generates every bonding/antibonding molecular-orbital pair developed rigorously in Part 10.

2. **Correct relative orientation in space**, so that the lobes involved actually point toward each other along the region where overlap is being evaluated — a bond is not formed simply because two atoms are close together; the specific orbitals available must be oriented so their lobes genuinely overlap.

> **Why? (mechanism, not just geometry)**
> Constructive, same-phase overlap physically means the two atoms' electron waves reinforce each other in the internuclear region, which — by the same energy-lowering logic first introduced for the potential-energy curve (§1.2) — concentrates negative charge where it can simultaneously attract both positive nuclei, lowering the system's total energy relative to the separated atoms. Covalent bond energy therefore has two contributing sources: the ordinary electrostatic attraction between each nucleus and the now-shared electron density, **and** an additional stabilization arising from the pairing of two electrons of opposite spin in the same overlapping region (a purely quantum-mechanical effect with no classical electrostatic analogue, sometimes called exchange stabilization). Both contributions are captured together in VBT's single overlap picture, even though only the first has an intuitive classical analogy.

### 7.2 Sigma (σ) and Pi (π) Bonds

Overlap is classified by its geometric character relative to the internuclear axis:

- **Sigma (σ) bond** — overlap occurs **head-on**, directly along the internuclear axis, giving electron density that is cylindrically symmetric about that axis. Every single bond is a σ bond, and every multiple bond contains exactly one σ bond.
- **Pi (π) bond** — overlap occurs **laterally** (sideways), between $p$ (or $d$) orbitals whose lobes are oriented *perpendicular* to the internuclear axis. This produces electron density concentrated *above and below* (or in front of and behind) the internuclear axis, with a **nodal plane containing the internuclear axis itself** — π electron density is zero exactly along the line joining the nuclei, in sharp contrast to σ density, which is greatest exactly along that line.

![Figure 7.1: Orbital overlap types](figures/fig7_1_orbital_overlap_types.svg)

**Figure 7.1.** (a)–(c) show three types of σ (head-on) overlap; (d) shows π (lateral) overlap, with its characteristic nodal plane along the internuclear axis.

**Relative overlap effectiveness.** For comparable internuclear distances, overlap effectiveness (and hence bond strength) follows:

$$p\text{–}p\ (\sigma) > s\text{–}p\ (\sigma) > s\text{–}s\ (\sigma) > p\text{–}p\ (\pi)$$

![Figure 7.3a: s-p bonding overlap](figures/orbitals/fig_overlap_sp_bonding.svg)
![Figure 7.3b: s-p antibonding overlap](figures/orbitals/fig_overlap_sp_antibonding.svg)
![Figure 7.4a: p-p sigma bonding overlap](figures/orbitals/fig_overlap_pp_sigma_bonding.svg)
![Figure 7.4b: p-p sigma antibonding overlap](figures/orbitals/fig_overlap_pp_sigma_antibonding.svg)
![Figure 7.5a: p-p pi bonding overlap](figures/orbitals/fig_overlap_pp_pi_bonding.svg)
![Figure 7.5b: p-p pi antibonding overlap](figures/orbitals/fig_overlap_pp_pi_antibonding.svg)

**Figures 7.3–7.5.** The complete overlap family, drawn with one consistent convention: blue = one phase, red = the opposite phase, dashed vertical line = node. Comparing 7.4a (p–p σ, head-on, both lobes fully facing) against 7.5a (p–p π, lateral, only lobe edges meeting) makes the overlap-effectiveness ordering above visually direct — σ overlap engages far more orbital area than π overlap at the same internuclear distance, which is the underlying reason a π bond is always weaker than a σ bond between the same two atoms (§7.2, Worked Example 7.1).

![Figure 7.6: sigma vs pi electron density comparison](figures/orbitals/fig_sigma_pi_density_comparison.svg)

**Figure 7.6.** Directly contrasts where electron density sits: concentrated *on* the internuclear axis for σ (cylindrically symmetric, permitting free rotation) versus entirely *off* the axis, above and below, for π (with zero density exactly on the axis) — this is the structural fact underlying Worked Example 7.2's rotation-restriction argument.

This ordering is a direct, verified consequence of orbital shape (`Chemical_Bonding_Kohinoor_.pdf` p.33's "Pauling–Slater extension"): $s$ orbitals are spherically non-directional, so $s$-involving overlap cannot be concentrated as effectively in one specific direction as overlap between two directional $p$ orbitals aligned head-on can be. A $p$–$p$ σ overlap places the two largest, most electron-dense lobes directly facing each other along the bond axis, maximizing the shared region; a $p$–$p$ π overlap, by contrast, only brings the *sides* of the two lobes into contact, giving substantially less shared area for the same internuclear distance — which is why a π bond is always weaker than the σ bond between the same pair of atoms, and why the "second" and "third" bonds of a double or triple bond add progressively less additional strength than the first (σ) bond did.

**Worked example 7.1 — Explaining why a C=C double bond is stronger than, but not twice as strong as, a C–C single bond**

*Problem:* $D(\mathrm{C{-}C}) \approx 346\text{ kJ mol}^{-1}$ (ethane), $D(\mathrm{C{=}C}) \approx 598\text{ kJ mol}^{-1}$ (ethene). Explain why the double bond is stronger, but well short of double the single-bond value.

*Reasoning:* A C=C double bond consists of one σ bond (formed by head-on overlap of $sp^2$ hybrid orbitals, Part 8) plus one π bond (lateral overlap of the unhybridized $p$ orbitals perpendicular to the molecular plane). The σ component contributes roughly the same strength as an ordinary C–C σ bond; the π component adds *additional* bonding, but — per the overlap-effectiveness ordering above — lateral $p$–$p$ overlap is intrinsically less effective than head-on overlap at the same internuclear distance, so the π contribution is smaller than a second σ bond would have been.

*Conclusion:* $D(\mathrm{C=C}) = D_\sigma + D_\pi$, with $D_\pi < D_\sigma$ — giving a double bond that is stronger than a single bond (598 > 346) but not close to double (which would require $D_\pi \approx D_\sigma \approx 346$, predicting $\sim 692$, well above the observed 598).

*Common mistake:* assuming bond enthalpies scale linearly and exactly with bond order (i.e., assuming $D(\mathrm{C=C}) = 2 \times D(\mathrm{C-C})$) — the correct statement is only that bond enthalpy *increases* with bond order, not that it scales proportionally, precisely because σ and π contributions are of different, non-equal magnitude.

**Worked example 7.2 — Why rotation about a C=C double bond is restricted, but rotation about a C–C single bond is free**

*Problem:* Ethane ($\mathrm{C_2H_6}$) rotates freely about its C–C bond at room temperature; ethene ($\mathrm{C_2H_4}$) does not rotate freely about its C=C bond (this restriction is the structural basis of cis/trans isomerism in alkenes). Explain using orbital overlap.

*Reasoning:* A σ bond is cylindrically symmetric about the internuclear axis (§7.2) — rotating one CH₃ group relative to the other about a pure C–C σ bond does not change the *degree* of orbital overlap at all, since the overlapping region remains axially symmetric throughout the rotation, so no energy barrier opposes it. A π bond, by contrast, depends on the lateral alignment of two specific, fixed-orientation $p$ orbitals (§7.2's nodal-plane picture) — rotating one $\mathrm{CH_2}$ group relative to the other about the C=C axis progressively misaligns these $p$ orbitals, reducing overlap and breaking the π bond partway through the rotation (fully breaking it at 90° rotation, where the two $p$ orbitals become mutually perpendicular and overlap drops to zero).

*Conclusion:* free rotation is a σ-bond-only phenomenon; any π-bond character between two atoms locks their relative orientation, because rotation directly and continuously degrades π overlap in a way it cannot degrade σ overlap.

### 7.3 Multiple Bonds — Explicit π-Bond Bookkeeping

A single bond contains one σ bond (0 π bonds). A double bond contains one σ + one π bond. A triple bond contains one σ + two π bonds (the second π bond forms from a *second* pair of mutually perpendicular $p$ orbitals, one on each atom, oriented perpendicular both to the internuclear axis and to the first π bond) — this is the direct structural basis for the $\mathrm{N \equiv N}$ triple bond in $\mathrm{N_2}$ (one σ + two mutually perpendicular π bonds, using all three $2p$ orbitals on each N atom together with the σ-forming orbital) and the shape (Part 9) of the electron-domain picture used throughout this chapter.

### 7.4 Limitations of Valence Bond Theory

VBT, in its simple overlap-only form, has real, well-defined limitations:

1. **It does not predict magnetic behaviour reliably.** VBT's simple electron-pairing picture of $\mathrm{O_2}$ (all electrons paired, Lewis-structure-consistent, §2.10's Common Trap box) predicts a diamagnetic molecule; $\mathrm{O_2}$ is experimentally paramagnetic. This is the same failure already flagged for the simple Lewis structure in §1.7 and §2.10 — VBT, built on essentially the same electron-pairing logic, inherits it. Resolving this requires molecular orbital theory (Part 10).
2. **It does not, on its own, explain bonding in electron-deficient compounds.** VBT's overlap picture assumes each bond arises from a localized pair of electrons shared between exactly two atoms — this framework has to be explicitly extended (the 3-centre–2-electron bridge-bond picture, Worked Example 2.7) to describe diborane and related electron-deficient/multicentre-bonded species; ordinary two-atom overlap language does not suffice.
3. **It is mathematically less rigorous than a full quantum treatment.** VBT (in the form used at this level) does not derive bond properties from first-principles solution of the Schrödinger equation for the whole molecule — it is a physically motivated, chemically intuitive approximation, not an exact theory, and its predictions (e.g., relative overlap effectiveness) are qualitative/ordinal rather than exactly quantitative.
4. **It struggles with delocalized bonding.** Species with resonance (Part 6) or extended π systems are, strictly, not well described by VBT's localized-bond-pair picture without additional resonance bookkeeping layered on top — VBT and resonance theory are used *together* precisely because VBT alone assumes each bonding pair is localized between one specific pair of atoms.

> **Model Limitation** — VBT is the theory that most directly *motivates* hybridization (Part 8) and the qualitative overlap-strength orderings used throughout bond-parameter discussions (Part 5), and it remains an extremely useful, intuitive first-approximation framework for predicting bond formation, relative strength, and geometry-related restrictions (like the σ/π rotation distinction above). Its specific, well-characterized failures (magnetism, electron deficiency, exact quantitation) are exactly why molecular orbital theory (Part 10) is developed as a separate, complementary framework rather than a simple replacement — each theory is more useful for different classes of question, and recognizing which theory a given question is really testing is itself a JEE Advanced skill.

### Part 7 Summary

- Constructive orbital overlap requires matching phase (same sign) and correct spatial orientation; overlap concentrates electron density between the nuclei, lowering system energy via both ordinary electrostatic attraction and spin-pairing (exchange) stabilization.
- σ bonds (head-on overlap, cylindrically symmetric, present in every bond) permit free rotation; π bonds (lateral overlap, nodal plane along the internuclear axis, present only in double/triple bonds) restrict rotation, because rotation directly degrades the required $p$-orbital alignment.
- Relative overlap effectiveness, $p$–$p(\sigma) > s$–$p(\sigma) > s$–$s(\sigma) > p$–$p(\pi)$, directly explains why multiple bonds are stronger than single bonds but not proportionally stronger (Worked Example 7.1).
- VBT's core limitations — failure to predict $\mathrm{O_2}$'s paramagnetism, inability to describe electron-deficient/multicentre bonding without extension, qualitative rather than exactly quantitative predictions, and difficulty with delocalized systems — are the direct motivation for Parts 8 (hybridization, built on VBT) and 10 (molecular orbital theory, VBT's complementary alternative).

---

## Source Traceability — Part 7

| Source PDF | Pages | Material found | Destination | Status |
|---|---|---|---|---|
| `Chemical_Bonding_Kohinoor_.pdf` | p.33, p.34 (of 261) | Overlap definition, two-component bond-energy origin (electrostatic + spin-pairing), Pauling–Slater directional-concentration rule, same-sign/orientation requirement for constructive overlap | §7.1, §7.2 | INCORPORATED |
| `CHEMICAL_BONDING.pdf` | (full text checked; no dedicated standalone VBT section beyond the octet/Lewis-theory material already used in Parts 1–2) | — | — | IRRELEVANT — source does not treat VBT/orbital overlap as a separate topic |
| `cbvj.pdf`, `Chemical Bonding (E)/1–12.pdf` | full existing OCR index re-queried (overlap, sigma, pi bond, sp, hybrid, orbital) | `Chemical Bonding (E)/2.pdf` p.13 (σ/π/δ overlap types, already logged in the Part 1–2 matrix) | §7.2 (confirmatory) | DUPLICATE — already logged |
| `Topic Wise Questions/Overlappingtheorylevel0.pdf` | all 8 pp. | Overlap-type identification questions (used only as a check that the theory above covers the tested scope, not as a source of specific new facts; no verbatim content reproduced) | — | INCORPORATED (scope-check only) |
| Independently derived | — | Worked Examples 7.1–7.2 (C=C bond-strength and rotation-restriction reasoning) — standard, independently verifiable chemistry, cross-checked against accepted bond-enthalpy data | §7.2 | INCORPORATED, independently verified |

---

*Part 7 complete. Continuing to Part 8 (Hybridisation).*
## Part 8 — Hybridisation

### 8.1 Why Hybridisation Was Introduced

Consider methane, $\mathrm{CH_4}$. Carbon's ground-state configuration is $1s^22s^22p^2$ — only **two** unpaired $2p$ electrons, which would predict a maximum covalency of 2, not the observed 4. Even granting that one $2s$ electron can be promoted to the empty $2p_z$ orbital (giving an excited-state configuration $2s^12p_x^12p_y^12p_z^1$, four unpaired electrons, consistent with covalency 4), pure unhybridized orbitals still fail: three C–H bonds would form by $2p$–$1s$ overlap and the fourth by $2s$–$1s$ overlap. These are geometrically and energetically different overlaps (§7.2's overlap-effectiveness ordering: $s$–$p$ overlap is more effective than $s$–$s$ overlap), which would predict **three C–H bonds of one strength and length, and a fourth of a different strength and length, at unpredictable, non-tetrahedral angles**.

Experimentally, all four C–H bonds in methane are identical in length and strength, and all six H–C–H angles equal $109.5°$. Pure atomic orbitals cannot explain this; **hybridisation** — the mathematical mixing of atomic orbitals of comparable energy on the same atom to produce a new set of equivalent hybrid orbitals — resolves the discrepancy by construction: mixing one $2s$ and three $2p$ orbitals produces four **equivalent** $sp^3$ hybrid orbitals, each with identical shape, energy, and (25% $s$ + 75% $p$) character, oriented tetrahedrally by the mathematics of the mixing itself.

> **Why? (what "equivalent" actually means here)**
> The four $sp^3$ hybrid orbitals are not four different orbitals that happen to look similar — they are four mathematically identical linear combinations of the same starting $2s, 2p_x, 2p_y, 2p_z$ orbitals, differing from each other only in the *sign combination* used in the mixing, which is exactly what forces them to point in four different, symmetric (tetrahedral) directions while remaining otherwise identical. This is why all four resulting C–H bonds must be identical: they are formed from four *provably* identical hybrid orbitals overlapping with four identical H $1s$ orbitals.

### 8.2 Features of Hybrid Orbitals

1. **The number of hybrid orbitals produced equals the number of atomic orbitals mixed** — mixing one $s$ and three $p$ orbitals gives exactly four $sp^3$ hybrids, never more or fewer; this is a direct consequence of hybrid orbitals being linear combinations (a basis-set-preserving transformation), not new orbitals created from nothing.
2. **Each hybrid orbital has one large lobe and one small lobe** — the large lobe, pointing away from the other hybrid orbitals, is used for bonding (or holds a lone pair); the small lobe on the opposite side is generally not involved in bonding.
3. **%s character controls orbital shape, energy, and bond consequences** (Table 8.1) — as %s character rises, the orbital becomes more compact/bulkier and lower in energy (since $s$ orbitals are, on average, closer to and more strongly attracted by the nucleus than $p$ orbitals of the same shell); as %p character rises, the orbital becomes longer and thinner and higher in energy.

| Hybridisation | %s | %p | %d |
|---|---:|---:|---:|
| $sp$ | 50 | 50 | — |
| $sp^2$ | 33.3 | 66.7 | — |
| $sp^3$ | 25 | 75 | — |
| $sp^3d$ | 20 | 60 | 20 |
| $sp^3d^2$ | 16.7 | 50 | 33.3 |

**Table 8.1.** Percentage $s$, $p$, $d$ character by hybridisation type (verified against `CHEMICAL_BONDING.pdf` §3.5, Table 3.2).

![Figure 8.1: Hybrid orbital shapes vs %s character](figures/fig8_1_hybrid_orbital_shapes.svg)

### 8.3 Consequences of %s Character — Bond Length, Bond Strength, Bond Angle

**Bond length and strength.** Higher %s character means the bonding electron pair, on average, sits closer to the nucleus (more "s-like"), which shortens the resulting bond and — because closer, more concentrated overlap is generally more effective (§7.2) — also strengthens it.

**Bond angle.** Higher %s character in the hybrid orbitals used for bonding corresponds to larger inter-orbital angles: $sp$ (50% s) gives $180°$, $sp^2$ (33.3% s) gives $120°$, $sp^3$ (25% s) gives $109.5°$. This is not a coincidence but a mathematical consequence of how many equivalent directions a given mixture of orbitals can be split into while remaining maximally separated (minimizing electron-pair repulsion, the same qualitative logic developed fully as VSEPR in Part 9) — more $p$ character (which is directional and repulsion-sensitive) forces the hybrid orbitals into a geometry with *smaller* angles between them, while more $s$ character (non-directional) permits *larger* angles.

**Worked example 8.1 — Bond-angle/bond-length correlation in CHF₃ vs CH₂F₂** (cross-checked against `Chemical_Bonding_Kohinoor_.pdf` p.95, 102)

*Problem:* In $\mathrm{CHF_3}$, the H–C–F angle is smaller than the corresponding H–C–F angle in $\mathrm{CH_2F_2}$. Explain using Bent's rule (§8.5 below) and %s-character reasoning together.

*Reasoning:* Fluorine, highly electronegative, preferentially withdraws electron density through the C–F bond, which (Bent's rule) causes carbon to direct **more p-character** toward the more electronegative F substituents and correspondingly **more s-character** toward the less electronegative H substituent(s). $\mathrm{CHF_3}$ has three C–F bonds competing for p-character (leaving relatively little for each), while $\mathrm{CH_2F_2}$ has only two — meaning each C–F bond in $\mathrm{CHF_3}$ carries a *higher* share of p-character than in $\mathrm{CH_2F_2}$.

*Conclusion:* higher p-character between the two F-containing bonds in $\mathrm{CHF_3}$ compresses the F–C–F angle (and correspondingly opens the H–C–F angle less than in $\mathrm{CH_2F_2}$, where less p-character is concentrated on the fewer C–F bonds) — this bond-angle distortion is a direct, worked illustration of Bent's rule operating through the %s-character mechanism established in this section.

*Common mistake:* attributing this angle difference to electronegativity alone via the simple VSEPR argument ("more electronegative substituent, smaller angle at that substituent, larger elsewhere") without connecting it to the underlying %s-character redistribution mechanism — the VSEPR-level statement and the Bent's-rule/hybridisation-level explanation are describing the *same* phenomenon at two different levels of depth, and JEE Advanced increasingly expects the deeper (Bent's rule) explanation.

### 8.4 The Conventional Hybridisation Types

| Type | Steric number | Geometry | Example |
|---|---:|---|---|
| $sp$ | 2 | Linear | $\mathrm{BeCl_2}$, $\mathrm{CO_2}$ |
| $sp^2$ | 3 | Trigonal planar | $\mathrm{BF_3}$, $\mathrm{CO_3^{2-}}$ |
| $sp^3$ | 4 | Tetrahedral | $\mathrm{CH_4}$, $\mathrm{NH_4^+}$ |
| $sp^3d$ | 5 | Trigonal bipyramidal | $\mathrm{PCl_5}$ |
| $sp^3d^2$ | 6 | Octahedral | $\mathrm{SF_6}$ |
| $sp^3d^3$ | 7 | Pentagonal bipyramidal | $\mathrm{IF_7}$ |
| $dsp^2$ | 4 | Square planar | (transition-metal complexes, conventional treatment) |

![Figure 8.2: sp hybridisation](figures/orbitals/fig_hybrid_sp.svg)
![Figure 8.3: sp2 hybridisation](figures/orbitals/fig_hybrid_sp2.svg)
![Figure 8.4: sp3 hybridisation](figures/orbitals/fig_hybrid_sp3.svg)

**Figures 8.2–8.4.** Each shows the parent orbitals mixing into the resulting hybrid set, with the leftover unhybridized $p$ orbital(s) marked explicitly for $sp$ and $sp^2$ (these are exactly the orbitals used for π bonding in Part 7's overlap language) — and each carries the same model-status reminder, because this point cannot be overstated: hybridisation constructs directed orbitals mathematically; it is not a literal sequence of physical reshaping.

![Figure 8.5: dsp2 conventional model](figures/orbitals/fig_hybrid_dsp2.svg)
![Figure 8.6: sp3d conventional model](figures/orbitals/fig_hybrid_sp3d.svg)
![Figure 8.7: sp3d2 conventional model](figures/orbitals/fig_hybrid_sp3d2.svg)
![Figure 8.8: d2sp3 conventional model](figures/orbitals/fig_hybrid_d2sp3.svg)

**Figures 8.5–8.8.** The four $d$-orbital-involving conventional types, each explicitly boxed with the same qualification: these are examination/geometry bookkeeping tools (§2.7b's hypervalency caveat applies identically here), not literal descriptions of which orbitals are "really" used. Figure 8.8 makes the point sharpest — $d^2sp^3$ and $sp^3d^2$ predict the *identical* octahedral geometry, and are distinguished from each other only within the conventional inner-/outer-orbital coordination-complex framework, never by geometry alone.

The **steric number** — number of atoms bonded to the central atom plus number of lone pairs on it — is calculated by the systematic electron-counting method already introduced implicitly through valence-electron counting (§2.6): total valence electrons of the central atom and all attached atoms (adjusted for charge) are divided among σ-bond pairs and central-atom lone pairs; the sum of (bonded atoms) + (lone pairs) gives the steric number, which fixes the hybridisation directly via the table above. This is developed into a complete geometric framework, with lone-pair placement rules for each steric number, in Part 9.

### 8.5 Bent's Rule

**Bent's rule:** the more electronegative substituent on a central atom preferentially bonds through the hybrid orbital with **less s-character** (more p-character), while a lone pair preferentially occupies the hybrid orbital with **more s-character**.

> **Why? (the underlying reason, not just the statement)**
> A more electronegative substituent pulls the shared bonding electron density toward itself, away from the central atom. The central atom therefore "loses less" by directing that particular bond through an orbital with a high energy cost per unit of s-character retained (i.e., a low-s-character, p-rich orbital) — since s-character is precisely the "expensive," strongly-nucleus-attracted character that is most wasted on a bond where the electron density is being pulled away regardless. Conversely, a lone pair — entirely retained by the central atom, attracted only by its own nucleus — benefits maximally from being placed in the most s-rich (most tightly, favourably held) orbital available.

This is the same physical reasoning already used quantitatively in §8.3 (Worked Example 8.1) and is the general principle underlying the trigonal-bipyramidal axial/equatorial electronegativity preferences developed fully in Part 9.

### 8.6 Non-Equivalent Hybrid Orbitals

Not every set of hybrid orbitals on a given atom is equivalent. In $sp^3d$ hybridisation (trigonal bipyramidal electron geometry), the two axial orbitals and three equatorial orbitals are **not** equivalent to each other — the axial set is better described as having more $p$/$d$ character and the equatorial set more $s$/$p$ character, which is the direct structural basis of Bent's rule's application to trigonal-bipyramidal molecules (more electronegative substituents preferring the axial positions, lone pairs preferring equatorial) — developed with full worked structures in Part 9.

> **Important Conceptual Distinction — hybridisation model vs. actual molecular-orbital description.** Hybridisation is a **mathematical model** constructed specifically to rationalize observed bond equivalence and geometry using a valence-bond-theory framework; it is not a directly observable physical process, and the "hybridized state" of an atom cannot be detected spectroscopically as an intermediate stage on the way from atom to molecule (it never actually exists as a separate physical state). A more complete, first-principles description of the same molecules is available through molecular orbital theory (Part 10), which does not require the hybridisation concept at all — the two frameworks are complementary tools suited to different questions (hybridisation for predicting local geometry and comparing bond-parameter trends; MOT for predicting bond order, magnetism, and overall electronic structure), not competing claims about which one is "really" happening inside the molecule.

### 8.7 Limitations and Traps in Hybridisation Assignment

1. **Third-period-and-beyond central atoms with small, weakly-electronegative attached atoms may show little or no real hybridisation**, even when the conventional geometry-matching hybridisation label is still assigned for exam purposes. $\mathrm{PH_3}$, $\mathrm{AsH_3}$, $\mathrm{SbH_3}$, $\mathrm{H_2S}$, $\mathrm{H_2Se}$, and $\mathrm{H_2Te}$ show bond angles very close to $90°$ rather than the $\sim107$–$109°$ expected from $sp^3$ hybridisation — because the energy cost of promoting and mixing orbitals for a heavier central atom is not repaid by sufficiently strong bonds to a weakly-electronegative substituent like H, so the central atom bonds using nearly pure $p$ orbitals instead (bond angle close to the un-hybridized $p$-orbital angle of $90°$), with the lone pair sinking into an almost pure, non-hybridized $s$ orbital.
2. **Assigning "the" hybridisation of an atom in a resonance-stabilized or odd-electron species can be genuinely ambiguous** — different canonical resonance structures may formally suggest slightly different local hybridisation, and the real, delocalized structure (Part 6) is not perfectly captured by assigning one single hybridisation label.
3. **Hybridisation is a *local*, central-atom-centred model — it says nothing directly about overall molecular symmetry, magnetism, or bond order** beyond the geometry it predicts; conflating "I have assigned a hybridisation" with "I have fully described the bonding" is a common but incomplete habit this Part is specifically written to correct, given §8.6's explicit caveat above.

### Part 8 Summary

- Hybridisation is a mathematical mixing model introduced specifically to explain observed bond equivalence and geometry that pure, unhybridized atomic orbitals cannot account for (methane's four identical C–H bonds, Worked motivating example, §8.1).
- %s character systematically controls hybrid-orbital shape, bond length, bond strength, and the angle between hybrid orbitals — higher %s gives shorter/stronger bonds and larger inter-orbital angles.
- Bent's rule (more electronegative substituent → less s-character orbital; lone pair → more s-character orbital) is the mechanistic explanation underlying many bond-angle distortion and trigonal-bipyramidal axial/equatorial preference questions, worked explicitly for CHF₃ vs. CH₂F₂.
- Hybridisation is explicitly a model, not a directly observable physical state — real molecules do not pass through a detectable "hybridized atom" stage, and heavier central atoms bonded to weakly electronegative substituents (PH₃, H₂S, etc.) show bond angles indicating essentially *no* real hybridisation despite the conventional label still being assigned.

---

## Source Traceability — Part 8

| Source PDF | Pages | Material found | Destination | Status |
|---|---|---|---|---|
| `CHEMICAL_BONDING.pdf` | §3.5 (Valence Bond Theory / hybridisation subsection, full text) | Motivating methane example, features of hybrid orbitals, %s/%p/%d character table (Table 3.2, reproduced as Table 8.1), steric-number calculation method | §8.1–8.4 | INCORPORATED |
| `Chemical_Bonding_Kohinoor_.pdf` | p.95, p.97, p.102 (of 261) | Bond-angle-vs-%s-character worked data, CH₃Cl/CH₃F bond-strength comparison, CHF₃/CH₂F₂ angle data used for Worked Example 8.1 | §8.3 | INCORPORATED |
| `CHEMICAL_BONDING.pdf` | §3.6 (Bent's rule statement within the VSEPR section) | Bent's rule statement and axial/equatorial %s-character mechanism (already partially used in Part 2's back-bonding discussion; full geometric application reserved for Part 9) | §8.5, §8.6 | INCORPORATED (mechanism); PENDING LATER PART (full geometric worked structures → Part 9) |
| `cbvj.pdf` | p.40 (previously logged in Parts 1–2 matrix) | PH₃/AsH₃/PF₃ back-bonding and Lewis-base-order data, Drago's rule context (no-hybridisation heavier-central-atom case) | §8.7 | INCORPORATED (confirmatory, cross-referencing already-logged content) |

---

*Part 8 complete. Continuing to Part 9 (VSEPR Theory and Molecular Geometry).*
## Part 9 — VSEPR Theory and Molecular Geometry

### 9.1 From Sidgwick–Powell to Gillespie's VSEPR

Sidgwick and Powell (1940) first proposed that molecular shape could be predicted purely from the *number* of electron pairs (bonding and lone) in the central atom's valence shell, treating all pairs as equivalent and mutually repelling, arranged to be as far apart as possible. Gillespie (1957) refined this into **VSEPR** (Valence Shell Electron Pair Repulsion) theory by recognizing that not all electron pairs repel *equally* — the refinement that gives VSEPR its real predictive power over the cruder Sidgwick–Powell starting point.

**The VSEPR repulsion hierarchy** (verified against `CHEMICAL_BONDING.pdf` §3.6):

$$\text{lone pair–lone pair} > \text{lone pair–bond pair} > \text{bond pair–bond pair}$$
$$\text{double bond–double bond} > \text{double bond–single bond} > \text{single bond–single bond}$$

> **Why? (the physical reason for the hierarchy, not just its statement)**
> A lone pair is attracted by only **one** nucleus (the central atom's), so its electron cloud is less tightly confined and spreads over a wider angular region than a bond pair, which is attracted by **two** nuclei simultaneously and is correspondingly pulled into a narrower, more confined region. A wider, more diffuse lone-pair cloud produces stronger angular repulsion against its neighbours than a confined bond pair does — this is the single physical fact underlying the entire repulsion hierarchy above, and it is the same fact already used (in different language) as the driving mechanism behind Bent's rule (§8.5: lone pairs occupy the most s-character-rich, most tightly nucleus-bound orbital available, precisely because they are single-nucleus-attracted and benefit most from being held close). A double bond, similarly, has a higher local electron density than a single bond (more shared electrons in the same general region), so it behaves as a "fatter" repelling domain than a single bond.

### 9.2 Steric Number and the AXₘEₙ Framework

The **steric number** (already introduced mechanically in §8.4) is the count of atoms bonded to the central atom plus the count of lone pairs on it. **Electron-pair (or "electron-domain") geometry** is the arrangement predicted by the steric number alone, treating every domain (bond or lone pair) as equivalent for the purpose of determining the underlying symmetric framework; **molecular geometry** is the shape actually observed, which is the electron-pair geometry with lone-pair positions removed from the description (since lone pairs are not directly observable in a structure determination) — the same skeleton, but named according to only the *atoms* now visible.

> **Important Conceptual Distinction — electron-pair geometry vs. molecular geometry.** These are frequently and consequentially confused. $\mathrm{NH_3}$ has *tetrahedral* electron-pair geometry (4 domains: 3 bonds + 1 lone pair) but *pyramidal* molecular geometry (only the 3 N and H atoms are "seen" in a structural description; the lone pair, while real and influential on the angle, does not count as a vertex of the named molecular shape). Getting this distinction right is essential for every worked structure in this Part.

**Table 9.1 — Complete geometry table, steric number 2–7**

| Steric number | Electron-pair geometry | Bond angles (ideal) |
|---:|---|---|
| 2 | Linear | $180°$ |
| 3 | Trigonal planar | $120°$ |
| 4 | Tetrahedral | $109.5°$ |
| 5 | Trigonal bipyramidal | axial–equatorial $90°$; equatorial–equatorial $120°$; axial–axial $180°$ |
| 6 | Octahedral | adjacent $90°$; opposite $180°$ |
| 7 | Pentagonal bipyramidal | axial–axial $180°$; axial–equatorial $90°$; equatorial–equatorial $72°$ |

![Parent geometries](figures/geometries/fig_vsepr_parent_linear.svg)
![Parent geometries](figures/geometries/fig_vsepr_parent_trigonal_planar.svg)
![Parent geometries](figures/geometries/fig_vsepr_parent_tetrahedral.svg)
![Parent geometries](figures/geometries/fig_vsepr_parent_trigonal_bipyramidal.svg)
![Parent geometries](figures/geometries/fig_vsepr_parent_octahedral.svg)
![Parent geometries](figures/geometries/fig_vsepr_parent_pentagonal_bipyramidal.svg)

**Figures 9.P1–9.P6.** The six parent electron-pair geometries corresponding to Table 9.1, drawn with a single consistent convention throughout this chapter: ordinary line = bond in the page plane, solid wedge = bond toward the viewer, hashed wedge = bond behind the plane. Every derived (lone-pair-containing) geometry in the rest of this Part is a modification of one of these six parents — worth returning to this set as a reference while working through §9.3–9.6.

### 9.3 Worked Structures — Steric Numbers 2–4

**$\mathrm{BeCl_2}$** ($AX_2$, steric number 2, sp): linear, $\mathrm{Cl-Be-Cl}$, $180°$, no lone pairs on Be — electron-pair geometry = molecular geometry (no lone pairs to distinguish them).

**$\mathrm{BF_3}$** ($AX_3$, steric number 3, sp²): trigonal planar, all F–B–F angles $120°$, no lone pair on B.

**$\mathrm{CH_4}$** ($AX_4$, steric number 4, sp³): tetrahedral, all H–C–H angles $109.5°$, no lone pairs on C.

**$\mathrm{NH_3}$** ($AX_3E_1$, steric number 4, sp³): tetrahedral electron-pair geometry, **pyramidal** molecular geometry; H–N–H angle compressed to $\approx107°$ (lone pair, wider angular spread per §9.1, compresses the bond–bond angle below the ideal $109.5°$).

**$\mathrm{H_2O}$** ($AX_2E_2$, steric number 4, sp³): tetrahedral electron-pair geometry, **bent/angular** molecular geometry; H–O–H angle compressed further, to $\approx104.5°$ — **two** lone pairs (rather than $\mathrm{NH_3}$'s one) produce two lone-pair–bond-pair repulsions plus one lone-pair–lone-pair repulsion (the single strongest repulsion type, §9.1), compressing the angle even more than in $\mathrm{NH_3}$.

> **Compare** — the ordering $\mathrm{CH_4\ (109.5°) > NH_3\ (107°) > H_2O\ (104.5°)}$ across isoelectronic-shell AXₘEₙ species with steric number 4 is the standard, frequently-tested worked demonstration that **more lone pairs on the same central atom monotonically compress the remaining bond angle** — and it directly follows from, rather than merely illustrates, the repulsion hierarchy of §9.1.

![Figure 9.3: CH4, NH3, H2O compression sequence](figures/geometries/fig_vsepr_ch4_nh3_h2o.svg)

**Figure 9.3.** All three species share tetrahedral electron-pair geometry (steric number 4), but molecular geometry and bond angle both change as lone pairs replace bond pairs: tetrahedral (0 LP) → pyramidal (1 LP) → bent (2 LP), with the H–X–H angle compressing at each step. This is the direct visual counterpart to the numerical trend stated above.

### 9.4 Worked Structures — Steric Number 5 (Trigonal Bipyramidal)

Steric number 5 is the first case where **not all positions are equivalent**: the trigonal bipyramid has two distinct site types — **axial** (two positions, $180°$ apart, each making $90°$ angles with all three equatorial positions) and **equatorial** (three positions, $120°$ apart from each other, $90°$ from both axial positions). An axial position experiences three $90°$ neighbour interactions; an equatorial position experiences only two $90°$ neighbour interactions (plus two $120°$ interactions, which are much weaker). **Equatorial sites are therefore the lower-repulsion, energetically preferred sites for a lone pair** (§9.1's hierarchy: fewer strong $90°$ neighbours to repel against) — matching Bent's rule (§8.5) exactly, since the equatorial orbital set also carries more s-character.

**$\mathrm{PCl_5}$** ($AX_5$, steric number 5, sp³d): trigonal bipyramidal, no lone pairs — electron-pair geometry = molecular geometry.

![Figure 9.4: PCl5 trigonal bipyramidal](figures/geometries/fig_vsepr_pcl5.svg)

**$\mathrm{SF_4}$** ($AX_4E_1$, steric number 5, sp³d): **see-saw** molecular geometry, lone pair equatorial (Figure 9.1). The observed F(axial)–S–F(axial) angle is compressed to $\approx173°$ (not the ideal $180°$) and the F(eq)–S–F(eq) angle to $\approx102°$ (not the ideal $120°$), both distortions caused by the single equatorial lone pair pushing the remaining bond pairs slightly away from their ideal positions.

![Figure 9.1: SF4 see-saw structure](figures/fig9_1_sf4_seesaw.svg)

**$\mathrm{ClF_3}$** ($AX_3E_2$, steric number 5, sp³d): **T-shaped** molecular geometry, both lone pairs equatorial (minimizing lone-pair–lone-pair repulsion by keeping them $120°$ apart rather than closer, and each lone pair minimizes its $90°$-neighbour count by being equatorial). Observed F–Cl–F angle $\approx87.5°$ (compressed from $90°$ by the two equatorial lone pairs).

![Figure 9.5: ClF3 T-shaped](figures/geometries/fig_vsepr_clf3.svg)

**$\mathrm{XeF_2}$** ($AX_2E_3$, steric number 5, sp³d): **linear** molecular geometry — with three lone pairs, all three occupy the equatorial positions (the only arrangement that places every lone pair in a low-repulsion equatorial site simultaneously), leaving the two bonded F atoms in the two axial positions, $180°$ apart. This is a clean, frequently-tested illustration that a highly lone-pair-rich steric-number-5 species reduces to a simple linear molecular geometry, precisely because the lone pairs, not the bonds, claim every equatorial site.

![Figure 9.6: XeF2 linear with 3 equatorial lone pairs](figures/geometries/fig_vsepr_xef2.svg)

**Figure 9.4–9.6.** All three drawn with the same axial(wedge/dash)/equatorial(in-plane) convention as the parent trigonal-bipyramidal geometry (Figure 9.P4), so the progressive lone-pair occupation of equatorial sites — 0 in PCl₅, 1 in SF₄, 2 in ClF₃, 3 in XeF₂ — is directly visually comparable across the series.

**$\mathrm{I_3^-}$ and $\mathrm{ICl_2^-}$** — both isoelectronic with $\mathrm{XeF_2}$ in electron-domain terms (central I with 3 lone pairs, 2 bonded atoms), both linear by the identical reasoning; dedicated figures and the three-centre–four-electron qualitative treatment are given in §9.7 alongside the other isoelectronic-shape examples.

### 9.5 Worked Structures — Steric Number 6 (Octahedral)

All six positions in an ideal octahedron are equivalent (unlike the trigonal bipyramid's axial/equatorial split) — but once a lone pair occupies one position, the remaining positions are no longer all equivalent relative to it (adjacent, $90°$ positions vs. the single opposite, $180°$ position).

**$\mathrm{SF_6}$** ($AX_6$, steric number 6, sp³d²): regular octahedral, no lone pairs.

![Figure 9.7: SF6 octahedral](figures/geometries/fig_vsepr_sf6.svg)

**$\mathrm{IF_5}$** ($AX_5E_1$, steric number 6, sp³d²): **square pyramidal** molecular geometry. The single lone pair (occupying the position trans to the apical F) pushes the four basal F atoms *away* from itself, up toward the apical F: the apical–basal F–I–F angles compress to $\approx81.9°$ (from the ideal $90°$), with the central I atom sitting slightly below the basal plane.

![Figure 9.8: IF5 square pyramidal](figures/geometries/fig_vsepr_if5.svg)

**$\mathrm{XeF_4}$** ($AX_4E_2$, steric number 6, sp³d²): **square planar** molecular geometry (Figure 9.2). With two lone pairs, the lowest-repulsion arrangement places them **mutually trans** (opposite, $180°$ apart) — any other arrangement (e.g., $90°$ apart) would create a strong lone-pair–lone-pair repulsion in addition to the weaker lone-pair–bond-pair repulsions, so the *trans* placement is strongly preferred, leaving a perfectly symmetric, undistorted square planar array of F atoms.

![Figure 9.2: XeF4 square planar structure](figures/fig9_2_xef4_square_planar.svg)

**$\mathrm{ICl_4^-}$** — isoelectronic in domain terms with $\mathrm{XeF_4}$ (steric number 6, 2 lone pairs), also square planar by identical reasoning.

### 9.6 Worked Structures — Steric Number 7 and the XeF₆ Anomaly

**$\mathrm{IF_7}$** ($AX_7$, steric number 7, sp³d³): pentagonal bipyramidal, no lone pairs — five equatorial F atoms at $72°$ intervals, two axial F atoms at $180°$ to each other.

![Figure 9.9: IF7 pentagonal bipyramidal](figures/geometries/fig_vsepr_if7.svg)

**$\mathrm{XeF_6}$** ($AX_6E_1$, steric number 7): this is the standing exception worth flagging explicitly. Simple VSEPR reasoning (steric number 7, one lone pair) would predict a **pentagonal pyramidal** molecular geometry (lone pair occupying one of the seven positions of a pentagonal bipyramid). The molecule is experimentally close to, but not exactly, a **distorted octahedron** — the lone pair behaves as though it occupies a face of the octahedron rather than a distinct seventh vertex, and $\mathrm{XeF_6}$ is understood to exist as a rapidly-interconverting equilibrium mixture of several nearly-equivalent slightly-distorted-octahedral structures, with the lone pair's position best described as "stereochemically active but delocalized across several near-equivalent sites" rather than fixed at one sharp position. This contrasts with anions such as $\mathrm{[SbCl_6]^{3-}}$, $\mathrm{[TeCl_6]^{2-}}$, and $\mathrm{[ICl_6]^-}$, which *are* observed as essentially perfect, undistorted octahedra — in these cases the lone pair is described as **stereochemically inactive**, occupying a non-directional, spherically-symmetric $s$-type orbital that does not distort the surrounding octahedral geometry at all.

> **Exception** — $\mathrm{XeF_6}$ is the clearest single illustration in this entire chapter that simple VSEPR electron-counting, while an excellent first-approximation tool, does not always correctly predict the *exact* observed geometry — the lone pair's stereochemical activity (does it distort the shape, or not?) depends on subtle energetic factors beyond simple domain-counting, and must be checked against experimental structural data rather than assumed from the AXₘEₙ formula alone.

![Figure 9.10: XeF6 conventional model with explicit distortion caveat](figures/geometries/fig_vsepr_xef6_qualified.svg)

**Figure 9.10.** Deliberately boxed warning on the figure itself, not just in the caption: this sketch shows only the naive AX₆E steric-number-7 starting point. Treat every angle in this specific figure as illustrative, not as a claim about the real, fluxional structure.

### 9.7 Isoelectronic Species and Shape Transfer

Species with the same steric number and the same number of lone pairs on the central atom (i.e., the same $AX_mE_n$ formula) adopt the **same** molecular geometry, regardless of the specific identity of the central or terminal atoms — this is the direct practical payoff of the electron-domain-counting framework, and it is what makes VSEPR predictive rather than merely descriptive. $\mathrm{CO_2}$, $\mathrm{BeCl_2}$, $\mathrm{XeF_2}$, and $\mathrm{I_3^-}$ are all linear, despite belonging to entirely different parts of the periodic table and different bonding descriptions, precisely because each reduces to an $AX_2$ (steric number 2) or $AX_2E_3$ (steric number 5, but still linear per §9.4) domain count.

![Figure 9.11: XeO3 trigonal pyramidal](figures/geometries/fig_vsepr_xeo3.svg)

**$\mathrm{XeO_3}$** ($AX_3E_1$, steric number 4): trigonal pyramidal, directly analogous in domain-count terms to $\mathrm{NH_3}$ (§9.3) despite the very different atoms involved — the conventional localized Xe=O double-bond drawing is a bookkeeping representation, not a claim about the complete modern electronic structure (the same caveat already established for expanded-octet species generally, §2.7b).

![Figure 9.12: XeOF4 square pyramidal](figures/geometries/fig_vsepr_xeof4.svg)

**$\mathrm{XeOF_4}$** ($AX_5E_1$, steric number 6): square pyramidal, directly analogous to $\mathrm{IF_5}$ (§9.5) — the lone pair sits trans to the unique apical atom (here O rather than F), and the basal-plane bond angle compresses slightly away from the lone pair by the same mechanism established for $\mathrm{IF_5}$.

![Figure 9.13: I3- linear](figures/geometries/fig_vsepr_i3minus.svg)
![Figure 9.14: ICl2- linear](figures/geometries/fig_vsepr_icl2minus.svg)

**$\mathrm{I_3^-}$ and $\mathrm{ICl_2^-}$** — both isoelectronic with $\mathrm{XeF_2}$ in electron-domain terms (central atom with 3 lone pairs, 2 bonded atoms), both linear by the identical reasoning, and both describable qualitatively (beyond the simple Lewis picture) via a delocalized three-centre–four-electron bonding scheme across the linear framework — the anionic-species analogue of the neutral $\mathrm{XeF_2}$ case, worth recognizing as the same shape-transfer principle applied to a charged system.

### 9.8 Symmetry and Dipole Moment — the Direct Link to Part 5

This is the direct payoff of §5.6's dipole-moment shape-determination table, now with the underlying VSEPR structures fully derived: a molecule's calculated zero or non-zero dipole moment is a *consequence* of the molecular geometry established in this Part, via vector cancellation of the individual bond moments (and any lone-pair moments) — $\mathrm{XeF_4}$'s square planar, centrosymmetric structure guarantees $\mu=0$ by symmetry alone (every Xe–F bond moment is exactly cancelled by the opposite one), while $\mathrm{SF_4}$'s see-saw structure has no such cancelling symmetry, guaranteeing $\mu \ne 0$.

### 9.9 Limitations of VSEPR

1. **VSEPR predicts idealized shapes; real structures show systematic, explainable distortions** (already worked explicitly above — $\mathrm{SF_4}$'s $173°$/$102°$ angles, $\mathrm{ClF_3}$'s $87.5°$ angle, $\mathrm{IF_5}$'s $81.9°$ basal angles) driven by the electronegativity and multiple-bond effects layered on top of the basic domain count (§9.1's full hierarchy, not just the lone-pair-vs-bond-pair headline rule).
2. **It does not, by itself, explain *why* a lone pair might be stereochemically inactive in one case ($\mathrm{[SbCl_6]^{3-}}$) but active in a closely related case ($\mathrm{XeF_6}$)** — this requires additional orbital-energy reasoning beyond simple domain-counting (§9.6).
3. **It says nothing about bond order, magnetism, or overall stability** — VSEPR is a shape-prediction tool built on the same electron-pair-counting logic as VBT (Part 7), and inherits VBT's inability to address magnetic behaviour or genuinely delocalized bonding without external input from resonance (Part 6) or MOT (Part 10).
4. **Multiple-bond and electronegativity effects can compete, and the *net* observed distortion requires tracking both simultaneously** (§9.1's double-bond and electronegativity clauses) — a common error is applying only the lone-pair-vs-bond-pair rule and ignoring the additional, sometimes comparably large, multiple-bond or electronegativity contribution to a specific observed angle.

### Part 9 Summary

- VSEPR refines the cruder Sidgwick–Powell "count electron pairs" idea with an explicit repulsion hierarchy (lone pair–lone pair > lone pair–bond pair > bond pair–bond pair; double bond > single bond), grounded physically in how tightly each domain type is confined by its attracting nucleus/nuclei.
- Electron-pair geometry (from steric number alone) and molecular geometry (what is structurally observed, lone pairs excluded from the name) are frequently and consequentially different — NH₃ and H₂O are the standing worked illustrations.
- Steric numbers 5 and 6 introduce genuinely non-equivalent site types (axial/equatorial; and, once occupied, adjacent/opposite), with lone pairs preferentially occupying the lower-$90°$-neighbour-count sites — directly connected to Bent's rule (Part 8) via the shared underlying s-character mechanism.
- XeF₆ is the standing, explicitly-flagged exception where simple domain-counting does not cleanly predict the exact observed (fluxional, near-octahedral) structure — a genuine, not merely pedagogical, VSEPR limitation.
- Molecular geometry, established in this Part, is the direct structural input to the dipole-moment shape-determination framework of Part 5 — the two Parts are two ends of the same argument, not independent topics.

---

## Source Traceability — Part 9

| Source PDF | Pages | Material found | Destination | Status |
|---|---|---|---|---|
| `CHEMICAL_BONDING.pdf` | §3.6 (Valence Shell Electron Pair Repulsion Theory, full section, including Tables 3.3, 3.4 and Figures 3.4–3.7) | Sidgwick–Powell/Gillespie history, full repulsion hierarchy, steric-number worked geometry table, SF₄/ClF₃/XeF₂/PCl₃F₂/PCl₂F₃/XeO₂F₂/XeF₄/IF₅/XeF₆ structures with exact experimental bond angles, Bent's rule axial/equatorial mechanism, XeF₆ fluxional-structure discussion, [SbCl₆]³⁻/[TeCl₆]²⁻/[ICl₆]⁻ stereochemically-inactive lone pair comparison | §9.1–9.6, §9.9 | INCORPORATED |
| `Chemical Bonding (E)/5.pdf` | pp.9–12 (of 15, previously flagged) | Steric-number counting method (confirmatory of §8.4/§9.2, no new content beyond what CHEMICAL_BONDING.pdf already supplied) | §9.2 (confirmatory) | DUPLICATE — already covered |
| `cbvj.pdf` | p.40 (previously logged) | N(CH₃)₃/P(SiH₃)₃/N(SiH₃)₃ pyramidal-vs-planar comparison (back-bonding effect on geometry) | Cross-referenced from Part 2 | DUPLICATE — already covered |
| Independently derived | — | Table 9.1 (complete steric-number 2–7 geometry table), Worked structures §9.3–9.7 organized and cross-verified against standard bond-angle literature values | §9.2–9.7 | INCORPORATED, independently verified |

---

*Part 9 complete. Continuing to Part 10 (Molecular Orbital Theory).*
## Part 10 — Molecular Orbital Theory

### 10.1 The LCAO Method

Molecular orbital theory (MOT) treats electrons as belonging to the **whole molecule**, not to individual atoms or localized bonds — a fundamentally different starting assumption from VBT's localized-overlap picture (Part 7). A molecular orbital wave function is constructed as a **linear combination of atomic orbitals (LCAO)**:

$$\psi_{\text{MO}} = c_1\psi_A + c_2\psi_B$$

For two atomic orbitals combining, exactly **two** molecular orbitals must result (conservation of the total number of orbitals, the same "in equals out" bookkeeping already used for hybridisation, §8.2):

$$\psi_{\text{bonding}} = N(\psi_A + \psi_B) \qquad \psi_{\text{antibonding}} = N'(\psi_A - \psi_B)$$

**Conditions for effective LCAO combination** (the MOT-level restatement of the constructive-overlap conditions already established in §7.1):
1. The combining atomic orbitals must be of **comparable energy**.
2. They must **overlap** effectively (sufficient spatial proximity and orientation).
3. They must have **matching symmetry** about the internuclear axis.

### 10.2 Bonding, Antibonding Orbitals, and Nodes

The **bonding** combination ($\psi_A + \psi_B$, same-sign addition) produces constructive interference, concentrating electron density between the nuclei — this is lower in energy than the separate atomic orbitals by a stabilization amount $\Delta$. The **antibonding** combination ($\psi_A - \psi_B$, opposite-sign combination) produces destructive interference, creating a **node** (a plane of exactly zero electron density) between the nuclei — this is higher in energy than the separate atomic orbitals by the same amount $\Delta$, since removing electron density from the internuclear region reduces the attraction holding the nuclei together.

Filling a bonding orbital **stabilizes** the molecule; filling an antibonding orbital (marked with an asterisk, e.g., $\sigma^*$, $\pi^*$) **destabilizes** it. Since both bonding and antibonding orbitals arise from the same starting pair of atomic orbitals, filling *both completely* (as in a hypothetical $\mathrm{He_2}$, §10.4) cancels the stabilization exactly, predicting **no net bond** — this is the direct MOT explanation for why $\mathrm{He_2}$ does not exist, succeeding exactly where the simple octet/Lewis picture gives no explanation at all (helium already has a complete valence shell in the Lewis picture, and Lewis theory has nothing further to say about why two complete-shell atoms fail to bond).

### 10.3 σ and π Molecular Orbitals

Exactly as in VBT (§7.2), MOs are classified by their symmetry about the internuclear axis: **σ** MOs (from head-on $s$–$s$, $s$–$p$, or $p$–$p$ combination) are cylindrically symmetric about the axis; **π** MOs (from lateral $p$–$p$ combination) have a nodal plane containing the internuclear axis. The bonding/antibonding distinction applies independently to each: $\sigma, \sigma^*, \pi, \pi^*$ are four distinct orbital types, each with its own energy level.

### 10.4 Homonuclear Diatomic Molecules — Building Up the Series

Following the Aufbau principle and Hund's rule (exactly as for atomic electron configurations), electrons fill the available MOs from lowest to highest energy. The **standard filling order** for light diatomics (Li₂ through N₂) places the $\pi 2p$ orbitals *below* $\sigma 2p_x$:

$$\sigma1s < \sigma^*1s < \sigma2s < \sigma^*2s < \pi2p_y{=}\pi2p_z < \sigma2p_x < \pi^*2p_y{=}\pi^*2p_z < \sigma^*2p_x$$

while for O₂ and F₂ (and, by extension, Ne₂), the order **reverses** for the $2p$-derived orbitals, placing $\sigma2p_x$ *below* $\pi2p_y{=}\pi2p_z$:

$$\sigma1s < \sigma^*1s < \sigma2s < \sigma^*2s < \sigma2p_x < \pi2p_y{=}\pi2p_z < \pi^*2p_y{=}\pi^*2p_z < \sigma^*2p_x$$

> **Why? (s–p mixing, the actual mechanism behind the order change — not just a memorized rule)**
> The $2s$ and $2p_x$ orbitals both have the correct symmetry to interact with each other directly (both are symmetric about the internuclear axis), and when the energy gap between the $2s$ and $2p$ atomic orbitals is **small enough**, this cross-interaction ("s–p mixing") pushes $\sigma2s$ and $\sigma2p_x$ further apart than they would be without mixing — lowering $\sigma2s$ (and $\sigma^*2s$) further and raising $\sigma2p_x$ (and $\sigma^*2p_x$) further, specifically because two orbitals of the same symmetry repel each other in energy (a general quantum-mechanical non-crossing-rule effect). This raises $\sigma2p_x$ high enough to sit *above* the (unaffected, different-symmetry) $\pi2p$ orbitals for Li through N. Across the period, the $2s$–$2p$ energy gap widens sharply (`CHEMICAL_BONDING.pdf` §3.11 gives the verified values: $\Delta E(2s-2p)$ in eV — Li 1.8, Be 2.8, B 4.5, C 5.3, N 6.0, **O 15.0**, F 20.5, Ne 26.7), and once the gap becomes large enough (O onward), s–p mixing becomes negligible, $\sigma2p_x$ drops back below $\pi2p$, and the "normal," unmixed ordering is restored.

**Table 10.1 — Complete homonuclear diatomic series, verified electron configurations, bond order, and magnetism**

| Species | Total e⁻ | Configuration (beyond core, mixed order where applicable) | Bond order | Magnetic character |
|---|---:|---|---:|---|
| $\mathrm{H_2^+}$ | 1 | $\sigma1s^1$ | 0.5 | Paramagnetic |
| $\mathrm{H_2}$ | 2 | $\sigma1s^2$ | 1 | Diamagnetic |
| $\mathrm{H_2^-}$ | 3 | $\sigma1s^2\sigma^*1s^1$ | 0.5 | Paramagnetic |
| $\mathrm{He_2^+}$ | 3 | $\sigma1s^2\sigma^*1s^1$ | 0.5 | Paramagnetic (exists, detected spectroscopically) |
| $\mathrm{He_2}$ | 4 | $\sigma1s^2\sigma^*1s^2$ | 0 | Does not exist (§10.2) |
| $\mathrm{Li_2}$ | 6 | KK, $\sigma2s^2$ | 1 | Diamagnetic |
| $\mathrm{Be_2}$ | 8 | KK, $\sigma2s^2\sigma^*2s^2$ | 0 | Does not exist as a stable diatomic |
| $\mathrm{B_2}$ | 10 | KK, $\sigma2s^2\sigma^*2s^2\pi2p_y^1\pi2p_z^1$ | 1 | **Paramagnetic** (Hund's rule fills the degenerate π orbitals singly first — correctly predicted only with the mixed s–p order) |
| $\mathrm{C_2}$ | 12 | KK, $\sigma2s^2\sigma^*2s^2\pi2p_y^2\pi2p_z^2$ | 2 | Diamagnetic |
| $\mathrm{N_2}$ | 14 | KK, $\sigma2s^2\sigma^*2s^2\pi2p_y^2\pi2p_z^2\sigma2p_x^2$ | 3 | Diamagnetic |
| $\mathrm{O_2}$ | 16 | KK, $\sigma2s^2\sigma^*2s^2\sigma2p_x^2\pi2p_y^2\pi2p_z^2\pi^*2p_y^1\pi^*2p_z^1$ | 2 | **Paramagnetic** |
| $\mathrm{O_2^+}$ | 15 | as O₂, remove one $\pi^*$ electron | 2.5 | Paramagnetic |
| $\mathrm{O_2^-}$ | 17 | as O₂, add one more $\pi^*$ electron | 1.5 | Paramagnetic |
| $\mathrm{O_2^{2-}}$ | 18 | as O₂, both $\pi^*$ orbitals filled | 1 | Diamagnetic |
| $\mathrm{F_2}$ | 18 | KK, $\sigma2s^2\sigma^*2s^2\sigma2p_x^2\pi2p_y^2\pi2p_z^2\pi^*2p_y^2\pi^*2p_z^2$ | 1 | Diamagnetic |
| $\mathrm{N_2^+}$ | 13 | as N₂, remove one $\sigma2p_x$ electron | 2.5 | Paramagnetic |
| $\mathrm{N_2^-}$ | 15 | as N₂, add one $\pi^*$ electron | 2.5 | Paramagnetic |

![Figure 10.2: B2 MO diagram](figures/mot/fig_mo_b2.svg)
![Figure 10.3: C2 MO diagram](figures/mot/fig_mo_c2.svg)
![Figure 10.4: N2 MO diagram](figures/mot/fig_mo_n2.svg)

**Figures 10.2–10.4.** The B₂–N₂ mixed-ordering template (π2p below σ2pz), with electron filling shown explicitly for each species. B₂'s two electrons split singly across the degenerate π2p pair (Hund's rule) — this is Worked Example 10.1's diagnostic case, visible directly here rather than only in the table.

![Figure 10.5: O2 MO diagram](figures/mot/fig_mo_o2_full.svg)
![Figure 10.6: F2 MO diagram](figures/mot/fig_mo_f2.svg)

**Figures 10.5–10.6.** The O₂–F₂ unmixed-ordering template (σ2pz below π2p) — note this is a *different* orbital ordering from Figures 10.2–10.4, not the same template relabelled. O₂'s two π*2p electrons occupy the degenerate pair singly (Hund's rule), directly producing the paramagnetism that neither the Lewis structure (§1.7) nor VBT (§7.4) can predict.

![Figure 10.7: Oxygen ion series comparison](figures/mot/fig_mo_oxygen_ion_series.svg)

**Figure 10.7.** The single most useful comparison panel in this Part: only the π* occupancy changes across the four-species series, and that one number alone determines bond order, relative bond length, relative bond strength, and magnetic character simultaneously — visible directly by counting arrows across the four panels rather than by re-deriving each species from scratch.

Bond order is calculated throughout as:

$$\text{Bond order} = \dfrac{N_b - N_a}{2}$$

where $N_b$ is the number of electrons in bonding orbitals and $N_a$ the number in antibonding orbitals — a direct, quantitative generalization of the qualitative "count the shared pairs" bond-order idea already used in §5.1 and §6.3, now made rigorous by explicitly weighing bonding contributions against antibonding ones rather than simply counting shared electrons.

![Figure 10.1: MO diagram of O2](figures/fig10_1_mo_o2.svg)

**Figure 10.1.** O₂ uses the *unmixed* ordering ($\sigma2p_x$ below $\pi2p$, since O's $2s$–$2p$ gap of 15.0 eV is too large for significant s–p mixing). Two electrons occupy the degenerate $\pi^*2p_y, \pi^*2p_z$ orbitals singly (Hund's rule) — this pair of unpaired electrons is the direct MOT explanation for paramagnetism that neither the simple Lewis structure (§1.7, §2.10) nor simple VBT (§7.4) can provide.

**Worked example 10.1 — Explaining the B₂ paramagnetism prediction, and why it requires the mixed ordering**

*Problem:* $\mathrm{B_2}$ is experimentally paramagnetic. Show that this is correctly predicted only by the *mixed* (s–p-mixed) MO ordering, not by the unmixed ordering.

*Reasoning:* B₂ has 6 valence electrons (beyond the $K$-shell core) to place in the $2s$/$2p$-derived MOs. Under the **mixed** ordering ($\pi2p$ below $\sigma2p_x$): after filling $\sigma2s^2\sigma^*2s^2$ (4 electrons), the remaining 2 electrons enter the degenerate $\pi2p_y, \pi2p_z$ pair — by Hund's rule, one electron in each, **unpaired**, correctly predicting paramagnetism. Under the (incorrect, for B₂) **unmixed** ordering ($\sigma2p_x$ below $\pi2p$): the remaining 2 electrons would instead fill $\sigma2p_x^2$ completely — **paired**, incorrectly predicting diamagnetism.

*Conclusion:* the experimentally observed paramagnetism of $\mathrm{B_2}$ is direct, decisive evidence for the s–p-mixed orbital ordering in light diatomics (Li₂–N₂) — this is a genuinely diagnostic worked example, not merely an illustrative one, since the two ordering models make different, experimentally distinguishable predictions for this specific molecule.

*Common mistake:* applying the O₂/F₂-family (unmixed) ordering uniformly to *all* homonuclear diatomics, including B₂, C₂, and N₂ — a very common error, since only the heavier half of the second-period series (O, F) actually uses the unmixed order.

### 10.5 Ions and Excited States — Electron Removal and Addition

Removing an electron from a bonding orbital *decreases* bond order (weakens, lengthens the bond); removing an electron from an antibonding orbital *increases* bond order (strengthens, shortens the bond) — the opposite-direction consequence of the bonding/antibonding energy-sign distinction (§10.2) applied to ionization specifically.

**Worked example 10.2 — Bond-order and bond-length change on ionizing N₂ vs. O₂**

*Problem:* Removing one electron from N₂ to form N₂⁺ *increases* the N–N bond length (110 pm → 112 pm). Removing one electron from O₂ to form O₂⁺ *decreases* the O–O bond length (121 pm → 112 pm). Explain the difference using MOT.

*Reasoning:* In N₂ (s–p-mixed ordering, §10.4; HOMO is $\sigma2p_x$, a **bonding** orbital), removing an electron from this bonding HOMO *lowers* bond order from 3 to 2.5 — bond order decreases, so bond length should increase and bond strength decrease on ionization. In O₂ (unmixed ordering, HOMO is $\pi^*2p$, an **antibonding** orbital), removing an electron from this antibonding HOMO *raises* bond order from 2 to 2.5 — bond order increases, so bond length should decrease and bond strength increase on ionization.

*Conclusion:* whether ionization strengthens or weakens a bond depends entirely on whether the electron removed came from a bonding or antibonding orbital — this is determined directly by which MO is the HOMO for that specific molecule, which in turn depends on the specific orbital-filling order (§10.4) for that molecule. This is a general, testable principle, not a pair of facts to memorize independently: **always identify the HOMO's bonding/antibonding character first**, and the bond-order (and hence bond-length) consequence of ionization follows immediately.

*Common mistake:* assuming ionization always weakens a bond (true for most main-group molecular cations formed by removing a bonding electron, but false whenever the HOMO is antibonding, as in O₂, F₂, and the superoxide/peroxide-type species of Table 10.1).

### 10.6 Heteronuclear Diatomics — NO and CO

**NO**: $5+6=11$ valence electrons (NO has 15 electrons *in total*, counting the two $1s^2$ cores — conflating the total count with the valence count is a genuine exam error worth guarding against; the valence configuration $\sigma2s^2\,\sigma^*2s^2\,\sigma2p^2\,\pi2p^4\,\pi^*2p^1$ uses exactly 11 electrons), filled using the same general ordering pattern as the homonuclear O₂/F₂-family (appropriate since N and O are adjacent, comparable-energy atoms), giving one unpaired electron in a $\pi^*$ orbital — **NO is paramagnetic**, and because this unpaired electron sits in a relatively high-energy, delocalized antibonding orbital (the HOMO), NO's first ionization energy (891 kJ mol⁻¹) is *lower* than either constituent atom's own ionization energy (N: 1402; O: 1314 kJ mol⁻¹) — removing an electron from an already-high-energy antibonding MO costs less than removing one from either atom's more tightly-bound orbitals. Ionizing NO to $\mathrm{NO^+}$ removes this antibonding electron, **raising** bond order from 2.5 to 3.0 and correspondingly **shortening** the bond (115 pm → 106 pm) — directly the same bonding-vs-antibonding-HOMO logic from Worked Example 10.2, now applied to a heteronuclear case.

**CO**: because C and O differ substantially in electronegativity (unlike the homonuclear cases), the simple symmetric LCAO combination is no longer strictly valid — the MOs are weighted more heavily toward the more electronegative O for bonding orbitals and more heavily toward C for the higher-energy orbitals, and the highest-occupied MO in CO is essentially a **non-bonding** orbital localized mostly on C. Ionizing CO (removing this largely non-bonding C-centred electron) causes only a small bond-length change (112.8 pm → 111.5 pm, a slight *decrease*, since even a "non-bonding" MO retains some bonding character in the real, non-idealized molecule) — consistent with CO's very high bond order (3, matching its Lewis-structure triple bond, §2.5's Worked Example 2.1) being only weakly perturbed by removing an electron from an orbital that is not strongly bonding or antibonding to begin with.

> **Important Conceptual Distinction — bonding, antibonding, and nonbonding orbitals.** A **nonbonding** MO (relevant specifically to heteronuclear cases like CO, and to lone pairs in polyatomic MO treatments beyond this Part's scope) is one that is essentially unchanged in energy from the parent atomic orbital — neither stabilized (bonding) nor destabilized (antibonding) by the LCAO combination, typically because the relevant atomic orbitals lack a symmetry-matched partner of comparable energy on the other atom to combine with constructively or destructively. This is distinct from a **lone pair** in the Lewis/VBT sense (§2.2) only in *framework* — both describe electron density essentially localized on one atom, but MOT's nonbonding-orbital language is the rigorous version of the same underlying physical idea.

### 10.7 Limitations of Elementary MO Diagrams

1. **The simple LCAO-based diagrams used here are qualitative**, giving correct orbital *ordering* and *bond-order* predictions for the second-period series and simple heteronuclear cases, but not exact, first-principles quantitative energies — a genuinely complete treatment requires solving the molecular Schrödinger equation numerically.
2. **They become substantially more complex for polyatomic molecules**, where MOs are delocalized over three or more atoms simultaneously (directly connecting back to the resonance/delocalization language of Part 6 — MOT provides the rigorous underlying picture that resonance theory approximates using multiple localized Lewis structures).
3. **The s–p mixing crossover point (§10.4) is itself an approximation** — the *exact* energy gap at which mixing becomes negligible is a matter of degree, not a sharp switch, and the O₂/F₂-vs-Li₂–N₂ split, while an extremely reliable rule at this level, is a simplified summary of a continuous underlying trend (the $\Delta E(2s\text{-}2p)$ values of §10.4 rise smoothly, not in a single step, across the period).

### Part 10 Summary

- MOT builds molecular orbitals as linear combinations of atomic orbitals over the whole molecule (not localized bonds, contrasting directly with VBT, Part 7); bonding combinations stabilize, antibonding combinations destabilize, and filling both completely (He₂) predicts — correctly — no net bond.
- The light (Li₂–N₂) and heavy (O₂–F₂) halves of the second-period series use *different* orbital fillings orders because of s–p mixing, whose strength is set by the $2s$–$2p$ energy gap; this is not an arbitrary memorized split but a direct, verifiable consequence (Worked Example 10.1, B₂'s paramagnetism) of a specific physical mechanism.
- Bond order $=(N_b-N_a)/2$ correctly predicts O₂'s paramagnetism (the historic first success of MOT over simple Lewis/VBT pictures) and correctly predicts, case by case, whether ionization strengthens or weakens a given bond depending on whether the HOMO removed is bonding, antibonding, or (for heteronuclear cases like CO) essentially nonbonding.
- MOT and VBT are complementary, not competing: VBT/hybridisation is more directly useful for local geometry (Parts 8–9); MOT is essential wherever magnetism, bond order in ions, or genuinely delocalized bonding must be predicted correctly.

---

## Source Traceability — Part 10

| Source PDF | Pages | Material found | Destination | Status |
|---|---|---|---|---|
| `CHEMICAL_BONDING.pdf` | §3.9–3.13 (Molecular Orbital Method, LCAO, homonuclear and heteronuclear worked treatment, full text) | LCAO derivation, bonding/antibonding energy-level diagrams, complete worked electron configurations H₂⁺ through F₂ and O₂⁻/O₂²⁻/N₂⁺/N₂⁻, ΔE(2s-2p) verified numerical table (Li 1.8 – Ne 26.7 eV), full NO and CO heteronuclear treatment with ionization-energy and bond-length data | §10.1–10.7, Table 10.1 | INCORPORATED |
| `cbvj.pdf`, `Chemical Bonding (E)/1–12.pdf` | existing OCR index re-queried (LCAO, molecular orbital, bond order, sigma star, pi star, paramagnetic, diamagnetic) | No new hits beyond what is already logged | — | IRRELEVANT TO PART 10 |
| Independently derived | — | Table 10.1 fully reconstructed and self-checked (bond order arithmetic verified for every entry); Worked Examples 10.1–10.2 constructed to specifically test the mixed-vs-unmixed ordering distinction | §10.4–10.5 | INCORPORATED, independently verified |

---

*Part 10 complete. Continuing to Part 11 (Hydrogen Bonding and Intermolecular Forces).*
## Part 11 — Hydrogen Bonding and Intermolecular Forces

### 11.1 Why Intermolecular Forces Are Needed at All

Kinetic theory's simplest model treats gas molecules as non-interacting. Real gases liquefy and solidify, which is direct evidence that some attractive force acts **between** already-complete molecules, over and above the covalent/ionic bonding that holds each molecule's own atoms together (§1.4's classification table, revisited here in full depth). These forces are collectively termed **van der Waals forces** and are categorically weaker than covalent, ionic, or even hydrogen bonds (§1.4's table), but they are what determines bulk physical properties — melting point, boiling point, viscosity, solubility — for molecular substances.

### 11.2 The Three van der Waals Interactions

**(a) Dipole–dipole interaction (Keesom forces).** Two polar molecules orient so that oppositely-charged ends attract — either head-to-tail or antiparallel, depending on molecular shape — with the interaction strength falling off as $1/r^3$ (verified against `CHEMICAL_BONDING.pdf` §3.30's energy-distance table). This is the direct extension of the single-bond dipole-moment concept (Part 5) to *intermolecular*, rather than intramolecular, electrostatics.

**(b) Dipole-induced dipole interaction (Debye forces).** A polar molecule's electric field can distort (polarize — the same physical mechanism as anion polarisation, §4.2, now acting on a whole neutral, non-ionic molecule rather than an anion) the electron cloud of a nearby non-polar molecule, inducing a temporary dipole that is then attracted to the permanent dipole. This is the mechanism behind noble-gas solubility in water and the formation of **clathrate hydrates** ($\mathrm{Ar\cdot6H_2O}$, $\mathrm{Kr\cdot6H_2O}$, $\mathrm{Xe\cdot6H_2O}$) — larger, more polarizable noble gas atoms are more strongly induced and more soluble, giving the solubility order $\mathrm{He < Ne < Ar < Kr < Xe}$ (source-verified, `cbvj.pdf` pp.8–9). Helium and neon, being too small and weakly polarizable, do not form stable clathrate cages.

**(c) Instantaneous dipole–induced dipole interaction (London dispersion forces).** Even a genuinely non-polar molecule or atom has, at any instant, a fluctuating, momentarily asymmetric electron distribution (electrons are in constant motion, not frozen in a perfectly symmetric average position) — this instantaneous dipole induces a corresponding dipole in a neighbouring atom/molecule, and the resulting attraction, averaged over time, is non-zero. This is the **only** attractive force available between genuinely non-polar species (e.g., $\mathrm{H_2}$, $\mathrm{He}$, $\mathrm{N_2}$), and it is present in *every* system, polar or non-polar, solid, liquid, or gas.

![Figure 11.7: London dispersion](figures/intermolecular/fig_imf_london_dispersion.svg)
![Figure 11.8: Dipole-dipole interaction](figures/intermolecular/fig_imf_dipole_dipole.svg)
![Figure 11.9: Dipole-induced dipole interaction](figures/intermolecular/fig_imf_dipole_induced_dipole.svg)
![Figure 11.10: Ion-dipole interaction, hydration](figures/intermolecular/fig_imf_ion_dipole.svg)
![Figure 11.11: Full interaction comparison panel](figures/intermolecular/fig_imf_comparison_master.svg)

**Figures 11.7–11.11.** The complete interaction family in one consistent visual language: solid bonds = covalent, green dashed = the intermolecular/ion-molecule attraction itself, δ+/δ− = partial (not full ionic) charge. Figure 11.10 makes explicit what §3.6's hydration enthalpy discussion described only in words: water's O (δ−) end orients toward cations, its H (δ+) end toward anions. Figure 11.11's comparison table carries its own explicit qualification — the ordering shown is a general guide only, not a rigid universal ranking.

London forces increase with:
- **Number of polarizable electrons / molecular weight** — more electrons give a larger, more easily distorted electron cloud, hence a larger instantaneous dipole.
- **Molecular surface area available for contact** — more contact area allows more simultaneous induced-dipole interactions.

**Worked example 11.1 — Why boiling point increases down the halogen and noble-gas groups**

*Problem:* $\mathrm{F_2}$ is a gas, $\mathrm{Cl_2}$ is a gas, $\mathrm{Br_2}$ is a liquid, and $\mathrm{I_2}$ is a solid at room temperature (all non-polar, homonuclear diatomics). Explain, and contrast with the case where molecular weight is held roughly constant but branching changes.

*Reasoning:* Down the halogen group, both the number of electrons and the molecular weight increase substantially (F₂ = 38 amu, I₂ = 254 amu), directly increasing the polarizability and hence the London dispersion attraction between molecules — stronger intermolecular attraction requires more thermal energy to overcome, raising both melting and boiling points, eventually crossing from gas to liquid to solid at room temperature across the series.

*Conclusion:* $\mathrm{I_2 > Br_2 > Cl_2 > F_2}$ in melting/boiling point, purely a London-dispersion-driven trend (none of these molecules has a permanent dipole moment, so Keesom and Debye forces play no role) — the standard, frequently-tested illustration that **for non-polar species, London dispersion alone controls the trend**, and molecular weight/electron count is the correct variable to track.

*Common mistake:* invoking "van der Waals forces" generically without specifying *which* of the three types is actually operative — for these specifically non-polar molecules, only London dispersion applies, and citing dipole–dipole (Keesom) forces here would be incorrect, since $\mathrm{I_2}$ has no permanent dipole moment.

**Worked example 11.2 — Branching decreases boiling point at fixed molecular weight**

*Problem:* $n$-pentane boils higher than iso-pentane, which boils higher than neo-pentane, despite all three being $\mathrm{C_5H_{12}}$ (identical molecular weight and electron count).

*Reasoning:* Since molecular weight is fixed, the controlling variable shifts to **molecular surface area** (§11.2's second London-force factor): the linear, unbranched $n$-pentane has the largest surface area available for intermolecular contact, while the compact, highly-branched, nearly spherical neo-pentane has the smallest.

*Conclusion:* $n\text{-pentane} > \text{iso-pentane} > \text{neo-pentane}$ in boiling point — a clean illustration that London dispersion depends on *two* separate variables (molecular weight/electron count, *and* surface area/shape), and a question holding one fixed is specifically testing the other.

### 11.3 Hydrogen Bonding

**Conditions for hydrogen bonding:** a hydrogen atom must be covalently bonded to a small, highly electronegative atom (N, O, or F — the standard donor set) *and* there must be a nearby atom (also typically N, O, or F, occasionally Cl in specific contexts) bearing a lone pair to accept the interaction. The H–X bond is highly polarized ($\delta^+$ on H, since X is far more electronegative), and this small, exposed, positively-polarized H nucleus is strongly attracted to a neighbouring lone pair.

$$\mathrm{X{-}H \cdots {:}Y} \qquad (X, Y = \mathrm{N, O, F\ typically})$$

> **Why? (why H specifically, and not other small, electropositive-relative-to-X atoms)**
> Hydrogen is unique in having **no inner shielding shell at all** — when its single electron is pulled away toward X, the resulting exposed nucleus is a bare proton with no inner electron cloud left to soften the resulting positive charge concentration, unlike any other element's partially-positive end (which always retains at least one inner filled shell shielding the nucleus). This exceptionally concentrated, unshielded positive charge is what allows H to approach a neighbouring lone pair closely enough to form an interaction (10–40 kJ mol⁻¹, §1.4's table) substantially stronger than an ordinary dipole–dipole interaction, while still remaining far weaker than a genuine covalent bond (150–950 kJ mol⁻¹) — hydrogen bonding is a special, H-specific case of dipole–dipole interaction, not a fundamentally different force (`cbvj.pdf` p.4 explicitly frames it this way: "H-bonding is a special type of dipole-dipole interaction").

**Intermolecular vs. intramolecular hydrogen bonding.** An **intermolecular** hydrogen bond forms *between* separate molecules (e.g., between two HF molecules, or between water molecules, Figure 11.2) and tends to *raise* melting/boiling point (extra energy needed to separate the associated molecules) and *increase* viscosity (associated molecules resist flowing past each other). An **intramolecular** hydrogen bond forms *within* a single molecule (e.g., in $o$-nitrophenol, between the phenolic O–H and an adjacent nitro group oxygen) and, because it satisfies the H-bonding capacity internally rather than linking separate molecules together, generally *lowers* melting/boiling point relative to the corresponding molecule capable only of intermolecular H-bonding (e.g., $p$-nitrophenol, which cannot form the same intramolecular interaction due to geometry, and instead engages in extensive intermolecular H-bonding).

> **Important Conceptual Distinction — intermolecular vs. intramolecular hydrogen bonding** produces *opposite* effects on melting/boiling point precisely because one *links separate molecules together* (raising the energy needed to separate them) while the other *ties up the H-bonding capacity within one molecule* (removing that capacity from intermolecular association) — this is the standard $o$/$p$-nitrophenol worked comparison, and the reasoning generalizes to any ortho/para-disubstituted pair where one isomer's geometry permits intramolecular bonding and the other's does not.

![Figure 11.6: Intramolecular vs intermolecular hydrogen bonding, o- vs p-nitrophenol](figures/intermolecular/fig_hbond_intra_vs_inter.svg)

**Figure 11.6.** Side-by-side structural comparison: the ortho isomer's geometry permits a favourable ring closure (intramolecular, consuming the H-bonding capacity internally), while the para isomer's geometry cannot form that same ring, leaving its donor group free for intermolecular association — directly producing the opposite boiling-point/solubility consequences stated in the box above. This comparison is valid specifically within this closely related isomer pair, not as a universal rule independent of molecular mass or other competing interactions.

### 11.4 Association and the Anomalous Properties of Water, HF, Ammonia, and Related Compounds

![Figure 11.2: Water hydrogen-bond network](figures/intermolecular/fig_hbond_water_network.svg)

**Water's extensive H-bonding network** (Figure 11.2) — each molecule can simultaneously donate two H-bonds (through its two H atoms) and accept two (through its two O lone pairs) — gives water anomalously high melting/boiling points, high viscosity, high surface tension, and a uniquely open, low-density crystalline solid structure (ice), in which every water molecule is tetrahedrally hydrogen-bonded to four neighbours, leaving substantial open space and making ice *less* dense than liquid water — a well-known anomaly directly traceable to this specific 4-fold H-bonding geometry.

**Worked example 11.3 — Why HF, not HCl/HBr/HI, has the anomalously highest boiling point in its series** (verified pattern, `cbvj.pdf` p.13: "$\mathrm{H_2O > H_2Te > H_2Se > H_2S}$")

![Figure 11.3: HF chain association](figures/intermolecular/fig_hbond_hf_chain.svg)

**Figure 11.3.** Repeated H–F···H–F association gives HF a zig-zag chain structure in the condensed phase — the structural basis of the anomaly worked through immediately below.

*Problem:* Within Group 17 hydrides, boiling point normally rises down the group (§11.2's London-dispersion argument: heavier, more polarizable atoms), giving the expected order $\mathrm{HCl < HBr < HI}$. Yet **HF** breaks this pattern, boiling *higher* than HCl despite being the *lightest* member. Explain — and note the closely analogous pattern for Group 16 hydrides, where $\mathrm{H_2O}$ boils anomalously higher than $\mathrm{H_2S}$, even though $\mathrm{H_2Te > H_2Se > H_2S}$ follows the expected London-dispersion order among the heavier members.

*Reasoning:* HF (and $\mathrm{H_2O}$, and $\mathrm{NH_3}$) are the specific hydrides of the *most* electronegative, smallest atoms capable of the strongest possible hydrogen bonding (§11.3's conditions are most strongly satisfied precisely for N, O, F). This additional, substantial H-bonding contribution (10–40 kJ mol⁻¹ per interaction, extensively networked as in Figure 11.2) outweighs the otherwise-expected London-dispersion-driven trend for the lightest member of each hydride series, producing the characteristic "anomalous spike" at the top of each group when boiling point is plotted against period for Group 15, 16, and 17 hydrides.

*Conclusion:* the general London-dispersion trend (heavier = higher boiling point) applies *within* the non-hydrogen-bonded members of a series (HCl < HBr < HI; H₂S < H₂Se < H₂Te), but is overridden specifically at the top of Groups 15–17 by hydrogen bonding, which is itself strongest for the smallest, most electronegative donor/acceptor atoms (N, O, F) — a case where two competing trends (dispersion, increasing down the group; H-bonding, strongest only at the very top) must both be tracked, with H-bonding dominating only for the single lightest member.

*Common mistake:* stating "HF has the highest boiling point because fluorine is most electronegative" without connecting this to the *mechanism* (strongest H-bonding, §11.3's shielding-based explanation) — electronegativity alone, without the H-bonding-specific reasoning, does not actually explain *why* this produces an anomalously high boiling point rather than simply a strongly polar-covalent molecule with an otherwise unremarkable dispersion-driven boiling point.

**Two further worked structural examples of intermolecular hydrogen bonding, beyond the water/HF cases above:**

![Figure 11.4: Ethanol intermolecular hydrogen bonding](figures/intermolecular/fig_hbond_alcohol_association.svg)

**Figure 11.4.** Only the polar –OH group participates directly in hydrogen bonding; the nonpolar alkyl chain does not. This is why ethanol (b.p. 78°C) boils far higher than dimethyl ether (b.p. −24°C) despite both having the formula $\mathrm{C_2H_6O}$ — the ether has no O–H donor group at all, so it cannot hydrogen-bond to itself the way an alcohol can (it can still *accept* a hydrogen bond from a donor like water, but cannot donate one).

![Figure 11.5: Carboxylic acid cyclic dimer](figures/intermolecular/fig_hbond_carboxylic_acid_dimer.svg)

**Figure 11.5.** Two simultaneous O–H···O=C hydrogen bonds close an eight-membered ring — this cyclic dimer is the direct structural explanation for carboxylic acids' anomalously high boiling points and their tendency to show close to double their true molar mass when measured by colligative methods in non-polar solvents (the "dimer" behaves as a single kinetic unit).

### 11.5 Ion–Dipole and Ion-Induced Dipole Interactions

**Ion–dipole interaction** is the attraction between a full ion and the partial charge of a polar molecule — the mechanism directly underlying the hydration/solvation processes already treated quantitatively in §3.6 (ion–dipole interaction is, precisely, what "hydration enthalpy" measures at the molecular level) and depicted with the polar solvent orienting its negative end toward cations and positive end toward anions.

**Ion-induced dipole interaction** is the attraction between a full ion and a dipole it induces in an otherwise non-polar neighbour — the mechanism behind polyhalide ion formation (e.g., $\mathrm{I_3^-}$, $\mathrm{ICl_2^-}$, already encountered structurally in §9.4): an iodide ion (I⁻) induces a dipole in a neutral $\mathrm{I_2}$ molecule, allowing them to associate. Stability of polyhalide ions follows the anion's polarizability directly ($\mathrm{F_3^- < Cl_3^- < Br_3^- < I_3^-}$), since a more polarizable neighbour is more strongly induced and hence more strongly bound.

**Table 11.1 — Relative strength and distance-dependence of intermolecular/ion-molecule interactions** (verified against `CHEMICAL_BONDING.pdf` §3.30–3.31)

| Interaction type | Energy–distance dependence |
|---|---|
| Ion–dipole | $1/r^2$ |
| Dipole–dipole | $1/r^3$ |
| Ion–induced dipole | $1/r^4$ |
| Dipole–induced dipole | $1/r^6$ |
| London dispersion | $1/r^6$ |

All these interactions fall off far more steeply with distance than the ordinary ionic-lattice Coulombic attraction ($1/r$, §3.4) — a direct, quantitative confirmation of why van der Waals-type interactions are inherently short-range, only significant when molecules are already close together (as in condensed phases), unlike lattice-scale electrostatics, which (via the Madelung-constant summation of §3.4) meaningfully extends over the whole crystal.

### Part 11 Summary

- Intermolecular forces (collectively van der Waals: dipole–dipole/Keesom, dipole-induced dipole/Debye, and London dispersion) act between complete molecules and are always weaker than the covalent/ionic bonds within a molecule, but they control bulk physical properties.
- London dispersion, present in *every* system, depends on polarizability (electron count/molecular weight) and surface area — both variables are independently testable (Worked Examples 11.1, 11.2).
- Hydrogen bonding is mechanistically a special, unusually strong case of dipole–dipole interaction, unique to H because it has no inner shielding shell; intermolecular H-bonding raises melting/boiling point (linking separate molecules), while intramolecular H-bonding lowers it (satisfying bonding capacity internally) — the standing $o$/$p$-nitrophenol illustration.
- The anomalously high boiling points of HF, H₂O, and NH₃ within their respective hydride series reflect H-bonding dominating over the otherwise-expected London-dispersion trend specifically at the top of Groups 15–17 (Worked Example 11.3), not electronegativity alone.
- Ion–dipole and ion-induced dipole interactions extend the same framework to ion–molecule systems, directly underlying hydration enthalpy (Part 3) and polyhalide-ion stability, and all intermolecular/ion–molecule interactions fall off far more steeply with distance than lattice-scale Coulombic attraction.

---

## Source Traceability — Part 11

| Source PDF | Pages | Material found | Destination | Status |
|---|---|---|---|---|
| `cbvj.pdf` | pp.1–15 (originally logged as PENDING in the Part 1–2 matrix; now drafted here as planned) | Full dipole–dipole (Keesom)/dipole-induced dipole (Debye)/London dispersion definitions, clathrate hydrate formation and noble-gas solubility order, H-bonding mechanism ("special type of dipole-dipole interaction"), Group 15/16/17 hydride boiling-point anomaly data, branched-alkane boiling-point comparisons, halogen boiling/melting point trend | §11.2–11.4 | INCORPORATED (resolves the PENDING flag from the Part 1–2 matrix) |
| `CHEMICAL_BONDING.pdf` | §3.30–3.31 (Weak Forces; Interactions between Ions and Covalent Molecules, full text) | Energy–distance relationships for all five interaction types (Table 11.1), ion–dipole/ion-induced dipole mechanism, polyhalide ion stability order, Lennard-Jones potential context | §11.5, Table 11.1 | INCORPORATED |
| Independently derived | — | Worked Examples 11.1–11.3 organized and cross-checked against standard physical-property data | §11.2, 11.4 | INCORPORATED, independently verified |

---

*Part 11 complete. Continuing to Part 12 (Metallic Bonding).*
## Part 12 — Metallic Bonding and Related Solid-State Ideas

### 12.1 The Electron-Sea Model

Metals consist of a regular lattice of positive metal-ion cores immersed in a "sea" of delocalized valence electrons that belong to the crystal as a whole, not to any individual atom or bond — the direct structural extension of the delocalization concept already developed for resonance (Part 6) and MOT (Part 10), now applied across an entire macroscopic lattice rather than one small molecule. Metallic bonding arises from the electrostatic attraction between this mobile electron sea and the fixed positive ion cores.

![Figure 12.1: Electron-sea model](figures/metallic/fig_metallic_electron_sea.svg)

**Figure 12.1.** A qualitative schematic only — the electron positions shown are illustrative of delocalization, not a literal count or exact instantaneous position of every valence electron.

> **Why? (why electrons delocalize across the whole lattice rather than localizing in bonds)**
> Metal atoms are electropositive with relatively few valence electrons and, often, several empty valence-shell orbitals available at accessible energy (§1.4's classification: neither atom in a metal-metal contact wants to hold electrons tightly). Rather than forming a large number of ordinary two-centre bonds (which each localized bond would only weakly stabilize, given how few electrons are available per atom), the valence electrons spread over the *entire* lattice, occupying a continuum of very closely-spaced molecular-orbital-like energy levels (§12.3) — this maximizes the total stabilization achievable from a limited electron supply, exactly analogous to how a resonance-delocalized structure (Part 6) is more stable than any single localized contributor, now scaled up from one molecule to an entire crystal.

### 12.2 Metallic Properties Explained by the Electron Sea

| Property | Explanation |
|---|---|
| High electrical conductivity | Delocalized electrons are free to move throughout the lattice; applying a potential difference causes a net drift of these mobile electrons, constituting a current |
| High thermal conductivity | The same mobile electrons carry kinetic energy rapidly through the lattice when one region is heated |
| Metallic lustre | Mobile electrons readily absorb photons across a broad range of visible wavelengths and immediately re-emit them as the electron falls back to its original level, giving the characteristic reflective sheen (at all viewing angles, unlike the shininess of some non-metals visible only at grazing angles) |

![Figure 12.6: Thermal conduction](figures/metallic/fig_metallic_thermal_conduction.svg)

**Figure 12.6.** Two carriers of thermal energy shown distinctly: mobile electrons (blue dots, net transport hot → cold) and lattice vibrations (red marks, larger amplitude at the hot end). Electrons scatter constantly — not ballistic, unimpeded travel — and the relative electron/lattice-vibration contribution genuinely varies between metals and with temperature.

![Figure 12.7: Metallic lustre](figures/metallic/fig_metallic_lustre.svg)

**Figure 12.7.** Incident light (gold arrows) absorbed and re-emitted (blue arrows) by the collective response of mobile/band electrons, not a single isolated-atom transition. Real optical behaviour (why copper is reddish, why gold is golden) depends on band structure, frequency response, and surface condition beyond this simple qualitative picture.
| Malleability and ductility | Because metallic bonding is **non-directional** (unlike covalent bonds), one layer of metal ions can slide past another under stress without breaking specific bonds — the electron sea simply re-adjusts around the new ion positions, in sharp contrast to an ionic lattice (§3.7), where shifting one layer brings like-charged ions into direct, strongly repulsive contact and causes brittle fracture rather than deformation |

![Figure 12.2: Electrical conduction, net drift](figures/metallic/fig_metallic_electrical_conduction.svg)

**Figure 12.2.** Individual electrons move randomly and scatter constantly off the vibrating lattice (the microscopic origin of electrical resistance) — an applied field superimposes only a small *net* drift on that much larger random motion, not unimpeded free flow.

**Worked example 12.1 — Contrasting the mechanical failure modes of metallic and ionic solids**

*Problem:* A metal can be hammered into a sheet (malleable) without shattering, while an ionic crystal shatters when struck. Explain the structural origin of this difference.

*Reasoning:* In a metal, applying shear stress shifts one plane of metal-ion cores relative to its neighbour; since the delocalized electron sea has no fixed directional preference (it simply redistributes to maintain overall attraction to whichever ion is nearby), the shifted structure remains bonded, just slightly deformed — bonding is preserved through the deformation. In an ionic crystal (§3.7), the same shear shift brings previously-alternating +/− ions into direct like-charge contact (+ next to +, or − next to −), which is strongly repulsive rather than attractive, and the crystal fractures cleanly along that plane rather than deforming.

*Conclusion:* the malleable-vs-brittle distinction is a direct structural consequence of *directionality*: metallic bonding's non-directional electron sea tolerates layer-sliding; ionic bonding's fixed, alternating-charge lattice does not.

![Figure 12.4: Malleability vs ionic brittleness](figures/metallic/fig_metallic_malleability_ductility.svg)

**Figure 12.4.** Side-by-side under identical applied stress: the metal's electron sea readjusts around the shifted ion positions (still bonded); the ionic crystal's shift brings like charges into direct contact (repulsion, fracture) — the visual counterpart to the reasoning above.

### 12.3 From Molecular Orbitals to Bands

Extending the MOT logic of Part 10 from a two-atom diatomic to a chain of $n$ metal atoms: combining $n$ atomic orbitals of the same type produces $n$ molecular orbitals, spanning a range from strongly bonding to strongly antibonding, with (for large $n$) the energy spacing between adjacent orbitals becoming vanishingly small — effectively a continuous **band** of allowed energy levels rather than a set of discrete, separated levels.

![Figure 12.3: Band formation from 1 to N atoms](figures/metallic/fig_band_formation.svg)

**Figure 12.3.** The same orbital-splitting logic already used for H₂, He₂, Li₂, etc. (Part 10), scaled up: 1 atom → 1 level; 2 atoms → 2 levels (bonding + antibonding); 4 atoms → 4 closely-spaced levels; N atoms (a real crystal) → an effectively continuous band. This is not a new phenomenon, only MOT applied at macroscopic scale.

For a metal like lithium (one valence electron per atom, $2s^1$), only the lower half of this band (the bonding half) is filled — leaving the upper half of the same band **empty and immediately accessible**, so that only a negligible amount of energy is needed to promote an electron into an unoccupied, mobile level. This is the direct band-theory explanation for metallic conduction: **conduction requires an accessible empty level essentially adjacent in energy to the highest filled level.**

### 12.4 Conductors, Insulators, and Semiconductors

| Category | Band structure | Conductivity behaviour |
|---|---|---|
| Conductor (metal) | Partially filled band, or filled and empty bands overlap | High conductivity; decreases slightly with increasing temperature (lattice vibrations increasingly scatter the mobile electrons) |
| Insulator | Full valence band, large energy gap to the next (empty) band | Essentially no conduction; the gap is too large for any practical fraction of electrons to be thermally promoted |
| Intrinsic semiconductor | Full valence band, but a **small** energy gap to the next band | Small, temperature-*increasing* conductivity, as thermal energy promotes a growing (though still small) fraction of electrons across the gap |

![Figure 12.5: Conductor, semiconductor, insulator band comparison](figures/metallic/fig_band_conductor_semiconductor_insulator.svg)

**Figure 12.5.** The three cases side by side in one consistent visual language: conductor bands overlap (no gap at all); semiconductor has a small gap crossable by ordinary thermal energy; insulator has a large gap that ordinary thermal energy cannot practically cross. No numerical band-gap values are asserted — only the qualitative small/large distinction this chapter's depth requires.

Beryllium ($2s^2$, a filled sub-band if treated as an isolated $2s$ band) is a metal, not an insulator, specifically because its $2s$-derived band **overlaps in energy** with the otherwise-empty $2p$-derived band — this overlap is what supplies the essential "accessible empty level adjacent to the highest filled level" condition, even though the simple electron-count argument (2 electrons, a "complete" $2s$ shell) would naively suggest an insulator.

> **Model Limitation** — This Part deliberately stops at the qualitative band picture sufficient to explain metallic bonding's core properties (conductivity, malleability, lustre) and the conductor/insulator/semiconductor distinction at the depth this chapter requires; the detailed treatment of doping, p-type/n-type semiconductors, and specific defect-driven conduction mechanisms belongs to the dedicated Solid State chapter and is not duplicated here.

### Part 12 Summary

- Metallic bonding is delocalization scaled up from the molecule (resonance, Part 6; MOT, Part 10) to the entire crystal lattice: mobile valence electrons throughout, attracted to fixed positive ion cores.
- Conductivity, thermal conductivity, and lustre all trace directly to the electron sea's mobility; malleability and ductility trace to metallic bonding's non-directional character, contrasted explicitly with ionic bonding's brittle, directional-repulsion failure mode (Worked Example 12.1).
- Scaling MOT to $n$ atoms produces continuous energy bands rather than discrete levels; metallic conduction requires an empty level immediately accessible in energy above the highest filled level — satisfied either by a partially-filled band (alkali metals) or by band overlap (Be).

---

## Source Traceability — Part 12

| Source PDF | Pages | Material found | Destination | Status |
|---|---|---|---|---|
| `CHEMICAL_BONDING.pdf` | §3.32–3.34 (The Metallic Bond, Theories of Bonding in Metals, Conductors/Insulators/Semiconductors, full text) | Electron-sea model, free-electron theory (Drude/Lorentz), VB-theory-of-metals resonance treatment, MO/band theory buildup from Li₂ to Liₙ, Be band-overlap explanation, conductor/insulator/semiconductor band comparison | §12.1–12.4 | INCORPORATED |
| Independently derived | — | Worked Example 12.1 (metallic vs. ionic mechanical failure mode) constructed to directly cross-reference §3.7's existing ionic-brittleness material | §12.2 | INCORPORATED, independently verified |

---

*Part 12 complete. Continuing to Part 13 (Integrated JEE Advanced Applications).*
## Part 13 — Integrated JEE Advanced Applications

This Part deliberately introduces no new theory — every question below is answered entirely using material already developed in Parts 1–12, cross-referenced explicitly, because integrated JEE Advanced questions are exactly this: recognizing which of several previously-learned tools applies, and applying more than one together.

### 13.1 Single-Correct

**Q1.** The correct order of N–O bond length in $\mathrm{NO_2^+}$, $\mathrm{NO_2}$, and $\mathrm{NO_2^-}$ is:
(A) $\mathrm{NO_2^+ < NO_2 < NO_2^-}$ (B) $\mathrm{NO_2^- < NO_2 < NO_2^+}$ (C) $\mathrm{NO_2 < NO_2^+ < NO_2^-}$ (D) All equal

*Reasoning:* From §2.10, average N–O bond order: $\mathrm{NO_2^+}$ (linear, two N=O double bonds, bond order 2 each, Worked structure §2.10) $>$ $\mathrm{NO_2}$ (bond order between 1 and 2, resonance-averaged, §6.6) $>$ $\mathrm{NO_2^-}$ (bond order between 1 and 2 but with more single-bond character due to the extra electron pair, §2.10). Higher bond order ⇒ shorter bond (§5.1). **Answer: (A)**, since higher bond order corresponds to shorter length and $\mathrm{NO_2^+}$ has the highest bond order.

**Q2.** Which of the following has a **zero** dipole moment?
(A) $\mathrm{SF_4}$ (B) $\mathrm{ClF_3}$ (C) $\mathrm{XeF_4}$ (D) $\mathrm{IF_5}$

*Reasoning:* From §9.4–9.5 and §5.6, only structures with a centrosymmetric or otherwise fully-cancelling bond-moment arrangement give $\mu=0$. $\mathrm{SF_4}$ (see-saw), $\mathrm{ClF_3}$ (T-shaped), and $\mathrm{IF_5}$ (square pyramidal) are all asymmetric, $\mu \ne 0$. $\mathrm{XeF_4}$ (square planar, Figure 9.2) is centrosymmetric — every Xe–F bond moment is exactly cancelled by the opposite one. **Answer: (C)**.

### 13.2 Multiple-Correct

**Q3.** Which of the following statements are correct?
(A) $\mathrm{B_2}$ is paramagnetic because of s–p mixing (§10.4). (B) The Born–Landé equation's close numerical fit to experiment for alkali halides proves the bonding is 100% ionic (§3.4). (C) A coordinate bond, once formed, cannot be distinguished from an ordinary covalent bond by any physical measurement (§2.4). (D) Resonance structures of $\mathrm{NO_3^-}$ physically interconvert rapidly at room temperature (§6.3).

*Reasoning:* (A) **Correct** — Worked Example 10.1 shows this explicitly. (B) **Incorrect** — §3.4's Model Limitation box explicitly warns against this exact inference; the equation is self-compensating. (C) **Correct** — §2.4's NH₄⁺ discussion establishes this directly. (D) **Incorrect** — §6.3's Common Trap box explicitly prohibits this framing; there is one real hybrid structure, not interconversion. **Answer: (A), (C)**.

**Q4.** Which of the following pairs are correctly matched by the *same* underlying physical mechanism?
(A) NH₃ vs. NF₃ dipole moment difference — and — Bent's rule bond-angle distortion in CHF₃ vs CH₂F₂. (B) Pseudo-noble-gas cation polarizing power — and — d-block maximum covalency via 3d→4p excitation. (C) O₂ paramagnetism (MOT) — and — B₂ paramagnetism (MOT). (D) Ice's low density — and — CsCl's 8:8 coordination.

*Reasoning:* (A) **Correct** — both trace to the same underlying issue of how substituent electronegativity redistributes s/p character and hence vector direction/magnitude (§5.5, §8.3, same mechanism at different scales). (C) **Correct** — both are direct, structurally analogous consequences of degenerate π-type orbitals being singly filled by Hund's rule (§10.4), even though they occur via different orbital-filling orders (unmixed for O₂, mixed for B₂). (B) is a mismatch — pseudo-noble-gas polarizing power (§4.4) is a *shielding* effect, unrelated to *maximum covalency via d-orbital availability* (a completely different, expanded-octet-type mechanism, §2.7b). (D) is a mismatch — ice's density anomaly is a hydrogen-bonding geometric consequence (§11.4); CsCl's coordination is a radius-ratio packing consequence (§3.15-adjacent, unrelated mechanism). **Answer: (A), (C)**.

### 13.3 Assertion–Reason

**Q5.** **Assertion:** The lattice enthalpy of $\mathrm{MgO}$ is much greater than that of $\mathrm{NaCl}$.
**Reason:** The ionic radii of $\mathrm{Mg^{2+}}$ and $\mathrm{O^{2-}}$ are smaller than those of $\mathrm{Na^+}$ and $\mathrm{Cl^-}$, and the charges are higher.

*Reasoning:* Both statements are true (§3.5, Worked Example 3.2: lattice energy $\propto z^+z^-$ and $\propto 1/r_0$, and both charge and size favour MgO here), and the Reason **correctly and completely explains** the Assertion (both the charge-product and size contributions to the Born–Landé equation point the same direction for this specific pair). **Answer: both true, Reason is the correct explanation of Assertion.**

**Q6.** **Assertion:** $\mathrm{XeF_6}$ is predicted by simple VSEPR to be pentagonal pyramidal, but is experimentally close to a distorted octahedron.
**Reason:** The lone pair in $\mathrm{XeF_6}$ is stereochemically inactive, exactly as in $\mathrm{[SbCl_6]^{3-}}$.

*Reasoning:* The Assertion is true (§9.6). The Reason is **false** — §9.6 explicitly distinguishes $\mathrm{XeF_6}$ (lone pair *stereochemically active but delocalized/fluxional*, causing the observed distortion) from $\mathrm{[SbCl_6]^{3-}}$-type anions (lone pair genuinely *inactive*, giving an *undistorted* octahedron) — these are explicitly the two contrasted cases in that section, not the same case. **Answer: Assertion true, Reason false.**

### 13.4 Matrix-Match

**Q7.** Match each species (Column I) with its correct magnetic character and bond order (Column II), drawing only on Table 10.1.

| Column I | Column II |
|---|---|
| (A) $\mathrm{O_2^{2-}}$ | (P) Paramagnetic, bond order 2.5 |
| (B) $\mathrm{N_2}$ | (Q) Diamagnetic, bond order 1 |
| (C) $\mathrm{O_2^+}$ | (R) Paramagnetic, bond order 1.5 |
| (D) $\mathrm{O_2^-}$ | (S) Diamagnetic, bond order 3 |

*Reasoning (directly from Table 10.1):* $\mathrm{O_2^{2-}}$: both degenerate $\pi^*$ orbitals completely filled — bond order $(8-6)/2 = 1$, no unpaired electrons, **diamagnetic** → (Q). $\mathrm{N_2}$: bond order 3, all electrons paired, diamagnetic → (S). $\mathrm{O_2^+}$: one $\pi^*$ electron — bond order $(8-3)/2 = 2.5$, one unpaired electron, paramagnetic → (P). $\mathrm{O_2^-}$: three $\pi^*$ electrons (one degenerate orbital paired, one singly occupied) — bond order $(8-5)/2 = 1.5$, one unpaired electron, paramagnetic → (R). **Answer: (A)-(Q), (B)-(S), (C)-(P), (D)-(R).**

*Common mistake:* assuming every oxygen-family species must be paramagnetic because O₂ is — $\mathrm{O_2^{2-}}$ (peroxide) is diamagnetic precisely because the added electrons complete the $\pi^*$ pair; the magnetic character must be read off the actual filling, never off the parent molecule.

### 13.5 Integer/Numerical

**Q8.** The dipole moment of a hypothetical diatomic molecule X–Y is $2.4$ D, and its bond length is $1.00$ Å. Calculate the percentage ionic character (nearest integer), using the method of Worked Example 5.3.

*Reasoning:* $\mu_{\text{calc}} = e \times d = (4.8\times10^{-10}\text{ esu})(1.00\times10^{-8}\text{ cm}) = 4.8\times10^{-18}\text{ esu cm} = 4.8\text{ D}$. $\%\text{ionic character} = (2.4/4.8)\times100 = 50\%$.

**Answer: 50**.

**Q9.** How many of the following species are **paramagnetic**: $\mathrm{O_2}$, $\mathrm{N_2}$, $\mathrm{O_2^-}$, $\mathrm{B_2}$, $\mathrm{C_2}$, $\mathrm{NO}$, $\mathrm{CO}$, $\mathrm{F_2}$?

*Reasoning:* From Table 10.1 and §10.6: $\mathrm{O_2}$ (P), $\mathrm{N_2}$ (D), $\mathrm{O_2^-}$ (P), $\mathrm{B_2}$ (P), $\mathrm{C_2}$ (D), $\mathrm{NO}$ (P), $\mathrm{CO}$ (D, isoelectronic with N₂, same bonding pattern), $\mathrm{F_2}$ (D). Paramagnetic count: $\mathrm{O_2, O_2^-, B_2, NO}$ = 4.

**Answer: 4**.

### 13.6 Comprehension

*Passage:* A student examines three species: $\mathrm{X = SO_3}$, $\mathrm{Y = SO_2}$, $\mathrm{Z = SO_4^{2-}}$.

**Q10.** Which of X, Y, Z requires resonance to explain its equal bond lengths, and which does not?

*Reasoning:* From §6.5 (Worked Example 6.5) and §2.5 (Worked Example 2.2): $\mathrm{SO_2}$ (Y) genuinely requires two resonance contributors to equalize its two S–O bonds. $\mathrm{SO_3}$ (X) does not strictly require resonance — a single symmetric structure with three S=O double bonds already gives equal bond lengths by molecular symmetry alone. $\mathrm{SO_4^{2-}}$ (Z) requires resonance among four equivalent contributors (extending the same logic as $\mathrm{CO_3^{2-}}$, Worked Example 6.2, to a tetrahedral rather than trigonal-planar case) to equalize all four S–O bonds.

**Q11.** Rank X, Y, Z by average S–O bond order.

*Reasoning:* $\mathrm{SO_3}$: bond order 2 (three S=O, no resonance-averaging needed, §6.5). $\mathrm{SO_2}$: bond order 1.5 (two equivalent resonance contributors, one S=O + one S–O each, §6.5). $\mathrm{SO_4^{2-}}$: using the minimal-formal-charge structure with two S=O and two S–O⁻ (§2.5, Worked Example 2.2's preferred structure), bond order $= (2\times2+2\times1)/4 = 1.5$.

**Answer:** $\mathrm{SO_3\ (2) > SO_2 = SO_4^{2-}\ (1.5)}$ — a genuinely counter-intuitive result worth flagging explicitly: despite $\mathrm{SO_4^{2-}}$ having more oxygen atoms and a higher negative charge, its *average* S–O bond order is the *same* as $\mathrm{SO_2}$'s, not higher, because the extra oxygens in $\mathrm{SO_4^{2-}}$ are accommodated partly through additional single, not double, bonds.

> **JEE Advanced Insight — the single most valuable habit from this integrated Part.** Every one of Q1–Q11 above was solved by **identifying which specific Part's tool applies**, not by fresh derivation. The core skill this chapter has been built to teach is not memorizing 200 individual facts, but recognizing — quickly and correctly — which of a small number of underlying mechanisms (energy minimization, formal charge, electronegativity-driven polarization, orbital overlap effectiveness, electron-domain repulsion, bonding/antibonding orbital character) is actually being tested in an unfamiliar-looking question.

### Part 13 Summary

This Part has deliberately introduced zero new chemistry — every question above was answered by direct application of a specific, cross-referenced tool from Parts 1–12, which is itself the point: JEE Advanced integration is the skill of correctly identifying which established tool a novel-looking question is actually testing, not a separate body of additional content to learn.

---

## Source Traceability — Part 13

| Source PDF | Pages | Material found | Destination | Status |
|---|---|---|---|---|
| Independently constructed | — | All 11 questions (Q1–Q11) newly written, each cross-referencing specific sections/worked-examples from Parts 1–12 rather than drawn from or paraphrasing any single source question bank, per the instruction not to reproduce source questions | §13.1–13.6 | INCORPORATED, independently constructed and internally cross-checked against the cited sections |
| `Topic Wise Questions/` (all five files) | Format/scope reference only | Used only to confirm the required question-format variety (single-correct, multi-correct, assertion-reason, matrix-match, integer, comprehension) was actually represented in this Part — no specific question content copied | — | Scope-check only, not a content source |

---

## Chapter-Level Concept Map and Visual Summary

![Concept map](figures/concept-maps/fig_chemical_bonding_concept_map.svg)

**Concept Map.** The organizing claim of this entire chapter, stated once at the top: electron distribution and total-energy lowering determine bonding, structure, and properties. Every arrow below it traces a specific, already-derived relationship — electron-domain arrangement → molecular geometry (Part 9); bonding/antibonding occupancy → bond order and magnetism (Part 10); charge and radius → lattice enthalpy (Part 3); polarisation → covalent character (Part 4) — not a generic "everything connects to everything" diagram.

![Visual summary part 1](figures/concept-maps/fig_chemical_bonding_visual_summary_1.svg)
![Visual summary part 2](figures/concept-maps/fig_chemical_bonding_visual_summary_2.svg)

**Visual Summary.** A compact, two-panel, last-minute revision overview of the single most load-bearing fact from each Part — deliberately not a restatement of everything covered, only the one idea each Part's worked examples most depend on.

## Chapter-Level Closing Note

Parts 1–13 are now complete as a connected sequence, saved individually (`chemical_bonding_part01-03.md` through `chemical_bonding_part13.md`) and merged into `chemical_bonding_complete.md`. The source-to-content matrix and progress ledger are updated to reflect this closing state.
