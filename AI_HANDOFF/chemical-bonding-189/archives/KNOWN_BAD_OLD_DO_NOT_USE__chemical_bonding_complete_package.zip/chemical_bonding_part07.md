## Part 7 — Valence Bond Theory and Orbital Overlap

### 7.1 The Overlap Concept

Valence bond theory (VBT) describes covalent bond formation as arising from the **overlap** of atomic orbitals, each contributing one unpaired electron of opposite spin. As two atoms approach, their orbitals begin to occupy a shared region of space; within that shared (overlapping) region, the wave functions of the two atomic orbitals combine, concentrating electron density between the two nuclei — the same physical outcome already established qualitatively in §1.1 and §2.2, now given a specific orbital-level mechanism.

Two conditions must both be satisfied for overlap to be **constructive** (bond-forming) rather than destructive:

1. **Same sign (phase) of the two wave function lobes** in the overlapping region. Combining lobes of the same sign reinforces the wave function, raising electron density between the nuclei. Combining lobes of opposite sign causes destructive interference, creating a **node** (a region of zero electron density) between the nuclei — this does not lower the system's energy and does not constitute a bond.

![Figure 7.2a: s-s bonding overlap](figures/orbitals/fig_overlap_ss_bonding.svg)
![Figure 7.2b: s-s antibonding overlap](figures/orbitals/fig_overlap_ss_antibonding.svg)

**Figure 7.2.** Same-phase overlap (7.2a) reinforces electron density between the nuclei — bonding. Opposite-phase overlap (7.2b) creates a node between the nuclei — antibonding, higher in energy. This same phase logic is what generates every bonding/antibonding molecular-orbital pair developed rigorously in Part 10.

2. **Correct relative orientation in space**, so that the lobes involved actually point toward each other along the region where overlap is being evaluated — a bond is not formed simply because two atoms are close together; the specific orbitals available must be oriented so their lobes genuinely overlap.

> **Why? (mechanism, not just geometry)**
> Constructive, same-phase overlap physically means the two atoms' electron waves reinforce each other in the internuclear region, which — by the same energy-lowering logic first introduced for the potential-energy curve (§1.2) — concentrates negative charge where it can simultaneously attract both positive nuclei, lowering the system's total energy relative to the separated atoms. Covalent bond energy therefore has two contributing sources: the ordinary electrostatic attraction between each nucleus and the now-shared electron density, **and** an additional stabilization arising from the pairing of two electrons of opposite spin in the same overlapping region (a purely quantum-mechanical effect with no classical electrostatic analogue, sometimes called exchange stabilization). Both contributions are captured together in VBT's single overlap picture, even though only the first has an intuitive classical analogy.

### 7.2 Sigma (σ) and Pi (π) Bonds

Overlap is classified by its geometric character relative to the internuclear axis:

- **Sigma (σ) bond** — overlap occurs **head-on**, directly along the internuclear axis, giving electron density that is cylindrically symmetric about that axis. Every single bond is a σ bond, and every multiple bond contains exactly one σ bond.
- **Pi (π) bond** — overlap occurs **laterally** (sideways), between $p$ (or $d$) orbitals whose lobes are oriented *perpendicular* to the internuclear axis. This produces electron density concentrated *above and below* (or in front of and behind) the internuclear axis, with a **nodal plane containing the internuclear axis itself** — π electron density is zero exactly along the line joining the nuclei, in sharp contrast to σ density, which is greatest exactly along that line.

![Figure 7.1: Orbital overlap types](figures/fig7_1_orbital_overlap_types.svg)

**Figure 7.1.** (a)–(c) show three types of σ (head-on) overlap; (d) shows π (lateral) overlap, with its characteristic nodal plane along the internuclear axis.

**Relative overlap effectiveness.** For comparable internuclear distances, overlap effectiveness (and hence bond strength) follows:

$$p\text{–}p\ (\sigma) > s\text{–}p\ (\sigma) > s\text{–}s\ (\sigma) > p\text{–}p\ (\pi)$$

![Figure 7.3a: s-p bonding overlap](figures/orbitals/fig_overlap_sp_bonding.svg)
![Figure 7.3b: s-p antibonding overlap](figures/orbitals/fig_overlap_sp_antibonding.svg)
![Figure 7.4a: p-p sigma bonding overlap](figures/orbitals/fig_overlap_pp_sigma_bonding.svg)
![Figure 7.4b: p-p sigma antibonding overlap](figures/orbitals/fig_overlap_pp_sigma_antibonding.svg)
![Figure 7.5a: p-p pi bonding overlap](figures/orbitals/fig_overlap_pp_pi_bonding.svg)
![Figure 7.5b: p-p pi antibonding overlap](figures/orbitals/fig_overlap_pp_pi_antibonding.svg)

**Figures 7.3–7.5.** The complete overlap family, drawn with one consistent convention: blue = one phase, red = the opposite phase, dashed vertical line = node. Comparing 7.4a (p–p σ, head-on, both lobes fully facing) against 7.5a (p–p π, lateral, only lobe edges meeting) makes the overlap-effectiveness ordering above visually direct — σ overlap engages far more orbital area than π overlap at the same internuclear distance, which is the underlying reason a π bond is always weaker than a σ bond between the same two atoms (§7.2, Worked Example 7.1).

![Figure 7.6: sigma vs pi electron density comparison](figures/orbitals/fig_sigma_pi_density_comparison.svg)

**Figure 7.6.** Directly contrasts where electron density sits: concentrated *on* the internuclear axis for σ (cylindrically symmetric, permitting free rotation) versus entirely *off* the axis, above and below, for π (with zero density exactly on the axis) — this is the structural fact underlying Worked Example 7.2's rotation-restriction argument.

This ordering is a direct, verified consequence of orbital shape (`Chemical_Bonding_Kohinoor_.pdf` p.33's "Pauling–Slater extension"): $s$ orbitals are spherically non-directional, so $s$-involving overlap cannot be concentrated as effectively in one specific direction as overlap between two directional $p$ orbitals aligned head-on can be. A $p$–$p$ σ overlap places the two largest, most electron-dense lobes directly facing each other along the bond axis, maximizing the shared region; a $p$–$p$ π overlap, by contrast, only brings the *sides* of the two lobes into contact, giving substantially less shared area for the same internuclear distance — which is why a π bond is always weaker than the σ bond between the same pair of atoms, and why the "second" and "third" bonds of a double or triple bond add progressively less additional strength than the first (σ) bond did.

**Worked example 7.1 — Explaining why a C=C double bond is stronger than, but not twice as strong as, a C–C single bond**

*Problem:* $D(\mathrm{C{-}C}) \approx 346\text{ kJ mol}^{-1}$ (ethane), $D(\mathrm{C{=}C}) \approx 598\text{ kJ mol}^{-1}$ (ethene). Explain why the double bond is stronger, but well short of double the single-bond value.

*Reasoning:* A C=C double bond consists of one σ bond (formed by head-on overlap of $sp^2$ hybrid orbitals, Part 8) plus one π bond (lateral overlap of the unhybridized $p$ orbitals perpendicular to the molecular plane). The σ component contributes roughly the same strength as an ordinary C–C σ bond; the π component adds *additional* bonding, but — per the overlap-effectiveness ordering above — lateral $p$–$p$ overlap is intrinsically less effective than head-on overlap at the same internuclear distance, so the π contribution is smaller than a second σ bond would have been.

*Conclusion:* $D(\mathrm{C=C}) = D_\sigma + D_\pi$, with $D_\pi < D_\sigma$ — giving a double bond that is stronger than a single bond (598 > 346) but not close to double (which would require $D_\pi \approx D_\sigma \approx 346$, predicting $\sim 692$, well above the observed 598).

*Common mistake:* assuming bond enthalpies scale linearly and exactly with bond order (i.e., assuming $D(\mathrm{C=C}) = 2 \times D(\mathrm{C-C})$) — the correct statement is only that bond enthalpy *increases* with bond order, not that it scales proportionally, precisely because σ and π contributions are of different, non-equal magnitude.

**Worked example 7.2 — Why rotation about a C=C double bond is restricted, but rotation about a C–C single bond is free**

*Problem:* Ethane ($\mathrm{C_2H_6}$) rotates freely about its C–C bond at room temperature; ethene ($\mathrm{C_2H_4}$) does not rotate freely about its C=C bond (this restriction is the structural basis of cis/trans isomerism in alkenes). Explain using orbital overlap.

*Reasoning:* A σ bond is cylindrically symmetric about the internuclear axis (§7.2) — rotating one CH₃ group relative to the other about a pure C–C σ bond does not change the *degree* of orbital overlap at all, since the overlapping region remains axially symmetric throughout the rotation, so no energy barrier opposes it. A π bond, by contrast, depends on the lateral alignment of two specific, fixed-orientation $p$ orbitals (§7.2's nodal-plane picture) — rotating one $\mathrm{CH_2}$ group relative to the other about the C=C axis progressively misaligns these $p$ orbitals, reducing overlap and breaking the π bond partway through the rotation (fully breaking it at 90° rotation, where the two $p$ orbitals become mutually perpendicular and overlap drops to zero).

*Conclusion:* free rotation is a σ-bond-only phenomenon; any π-bond character between two atoms locks their relative orientation, because rotation directly and continuously degrades π overlap in a way it cannot degrade σ overlap.

### 7.3 Multiple Bonds — Explicit π-Bond Bookkeeping

A single bond contains one σ bond (0 π bonds). A double bond contains one σ + one π bond. A triple bond contains one σ + two π bonds (the second π bond forms from a *second* pair of mutually perpendicular $p$ orbitals, one on each atom, oriented perpendicular both to the internuclear axis and to the first π bond) — this is the direct structural basis for the $\mathrm{N \equiv N}$ triple bond in $\mathrm{N_2}$ (one σ + two mutually perpendicular π bonds, using all three $2p$ orbitals on each N atom together with the σ-forming orbital) and the shape (Part 9) of the electron-domain picture used throughout this chapter.

### 7.4 Limitations of Valence Bond Theory

VBT, in its simple overlap-only form, has real, well-defined limitations:

1. **It does not predict magnetic behaviour reliably.** VBT's simple electron-pairing picture of $\mathrm{O_2}$ (all electrons paired, Lewis-structure-consistent, §2.10's Common Trap box) predicts a diamagnetic molecule; $\mathrm{O_2}$ is experimentally paramagnetic. This is the same failure already flagged for the simple Lewis structure in §1.7 and §2.10 — VBT, built on essentially the same electron-pairing logic, inherits it. Resolving this requires molecular orbital theory (Part 10).
2. **It does not, on its own, explain bonding in electron-deficient compounds.** VBT's overlap picture assumes each bond arises from a localized pair of electrons shared between exactly two atoms — this framework has to be explicitly extended (the 3-centre–2-electron bridge-bond picture, Worked Example 2.7) to describe diborane and related electron-deficient/multicentre-bonded species; ordinary two-atom overlap language does not suffice.
3. **It is mathematically less rigorous than a full quantum treatment.** VBT (in the form used at this level) does not derive bond properties from first-principles solution of the Schrödinger equation for the whole molecule — it is a physically motivated, chemically intuitive approximation, not an exact theory, and its predictions (e.g., relative overlap effectiveness) are qualitative/ordinal rather than exactly quantitative.
4. **It struggles with delocalized bonding.** Species with resonance (Part 6) or extended π systems are, strictly, not well described by VBT's localized-bond-pair picture without additional resonance bookkeeping layered on top — VBT and resonance theory are used *together* precisely because VBT alone assumes each bonding pair is localized between one specific pair of atoms.

> **Model Limitation** — VBT is the theory that most directly *motivates* hybridization (Part 8) and the qualitative overlap-strength orderings used throughout bond-parameter discussions (Part 5), and it remains an extremely useful, intuitive first-approximation framework for predicting bond formation, relative strength, and geometry-related restrictions (like the σ/π rotation distinction above). Its specific, well-characterized failures (magnetism, electron deficiency, exact quantitation) are exactly why molecular orbital theory (Part 10) is developed as a separate, complementary framework rather than a simple replacement — each theory is more useful for different classes of question, and recognizing which theory a given question is really testing is itself a JEE Advanced skill.

### Part 7 Summary

- Constructive orbital overlap requires matching phase (same sign) and correct spatial orientation; overlap concentrates electron density between the nuclei, lowering system energy via both ordinary electrostatic attraction and spin-pairing (exchange) stabilization.
- σ bonds (head-on overlap, cylindrically symmetric, present in every bond) permit free rotation; π bonds (lateral overlap, nodal plane along the internuclear axis, present only in double/triple bonds) restrict rotation, because rotation directly degrades the required $p$-orbital alignment.
- Relative overlap effectiveness, $p$–$p(\sigma) > s$–$p(\sigma) > s$–$s(\sigma) > p$–$p(\pi)$, directly explains why multiple bonds are stronger than single bonds but not proportionally stronger (Worked Example 7.1).
- VBT's core limitations — failure to predict $\mathrm{O_2}$'s paramagnetism, inability to describe electron-deficient/multicentre bonding without extension, qualitative rather than exactly quantitative predictions, and difficulty with delocalized systems — are the direct motivation for Parts 8 (hybridization, built on VBT) and 10 (molecular orbital theory, VBT's complementary alternative).

---

## Source Traceability — Part 7

| Source PDF | Pages | Material found | Destination | Status |
|---|---|---|---|---|
| `Chemical_Bonding_Kohinoor_.pdf` | p.33, p.34 (of 261) | Overlap definition, two-component bond-energy origin (electrostatic + spin-pairing), Pauling–Slater directional-concentration rule, same-sign/orientation requirement for constructive overlap | §7.1, §7.2 | INCORPORATED |
| `CHEMICAL_BONDING.pdf` | (full text checked; no dedicated standalone VBT section beyond the octet/Lewis-theory material already used in Parts 1–2) | — | — | IRRELEVANT — source does not treat VBT/orbital overlap as a separate topic |
| `cbvj.pdf`, `Chemical Bonding (E)/1–12.pdf` | full existing OCR index re-queried (overlap, sigma, pi bond, sp, hybrid, orbital) | `Chemical Bonding (E)/2.pdf` p.13 (σ/π/δ overlap types, already logged in the Part 1–2 matrix) | §7.2 (confirmatory) | DUPLICATE — already logged |
| `Topic Wise Questions/Overlappingtheorylevel0.pdf` | all 8 pp. | Overlap-type identification questions (used only as a check that the theory above covers the tested scope, not as a source of specific new facts; no verbatim content reproduced) | — | INCORPORATED (scope-check only) |
| Independently derived | — | Worked Examples 7.1–7.2 (C=C bond-strength and rotation-restriction reasoning) — standard, independently verifiable chemistry, cross-checked against accepted bond-enthalpy data | §7.2 | INCORPORATED, independently verified |

---

*Part 7 complete. Continuing to Part 8 (Hybridisation).*
