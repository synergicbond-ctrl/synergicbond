# Chemical Bonding Notes — Structure Validation Report

> **INDEPENDENT AUDIT NOTICE (2026-07-18).** This document predates the independent chemistry accuracy audit of 2026-07-18 and its verification claims must be read together with `chemical_bonding_correction_log.md` and `chemical_bonding_independent_validation.md`, which supersede any conflicting claim here. In particular, the pre-audit "chemistry checked/verified" labels did not catch the errors listed in the correction log (most notably the NO valence-electron count in Part 10, corrected from 15 to 11).


Data below is pulled directly from the already-computed and self-checked tables in §2.10 (Structure Verification Panel), §6.5 (resonance worked examples), and §9.3–9.6 (VSEPR worked structures) — not re-estimated. "Figure" column is marked `—` where the species is fully specified in a text table/worked example but has no dedicated standalone image; per the Visual Audit, only a subset of species have dedicated figures so far.

| Species | Electron count | Formal-charge sum | Lone pairs shown | Geometry | Bond angles | Dipole treatment | Figure | Status |
|---|---:|---:|---|---|---|---|---|---|
| H₂ | 2 | 0 | none | Linear (trivial) | — | Nonpolar (μ=0, homonuclear) | — | VALIDATED |
| Cl₂ | 14 | 0 | 3 per Cl | Linear (trivial) | — | Nonpolar | — | VALIDATED |
| O₂ | 12 | 0 (Lewis) | 2 per O | Linear (trivial) | — | Nonpolar | fig10_1 (MOT, not Lewis) | MODEL LIMITATION EXPLAINED — Lewis structure predicts diamagnetic; real O₂ is paramagnetic, resolved only by MOT (§10.4) |
| N₂ | 10 | 0 | 1 per N | Linear (trivial) | — | Nonpolar | — | VALIDATED |
| HCl | 8 | 0 | 3 on Cl | Linear (trivial) | — | Polar, μ=1.03 D (Worked Example 5.3) | — | VALIDATED |
| H₂O | 8 | 0 | 2 on O | Bent (AX₂E₂) | ~104.5° | Polar, μ=1.84 D | — | VALIDATED |
| NH₃ | 8 | 0 | 1 on N | Pyramidal (AX₃E) | ~107° | Polar, μ=1.47 D (Worked Example 5.2) | fig5_1 (comparison panel) | VALIDATED |
| CH₄ | 8 | 0 | none | Tetrahedral (AX₄) | 109.5° | Nonpolar (μ=0, symmetric) | — | VALIDATED |
| NH₄⁺ | 8 | +1 | none | Tetrahedral (AX₄) | 109.5° | N/A (ion) | fig2_1 | VALIDATED |
| H₃O⁺ | 8 | +1 | 1 on O | Pyramidal (AX₃E) | <109.5° (pyramidal) | N/A (ion) | — | VALIDATED |
| CO | 10 | 0 (C:−1, O:+1) | 1 each | Linear (trivial) | — | Anomalously low μ=0.112 D — formal-charge/electronegativity dipole components oppose (§2.5) | — | VALIDATED |
| CO₂ | 16 | 0 | 2 per O | Linear (AX₂) | 180° | Nonpolar (μ=0, symmetric cancellation) | — | VALIDATED |
| CN⁻ | 10 | −1 (C:−1, N:0) | 1 each | Linear (trivial) | — | N/A (ion) | — | VALIDATED — explicit exception note that octet-completion overrides formal-charge electronegativity placement (§2.10) |
| NO | 11 (odd) | 0 | 1 on N + radical | Linear (trivial) | — | N/A | — | VALIDATED — odd-electron exception |
| NO₂ | 17 (odd) | 0 | resonance | Bent (AX₂E, radical on N) | ~134° (lit.) | N/A | — | VALIDATED — odd-electron, resonance |
| NO₂⁺ | 16 | +1 | 2 per O | Linear (AX₂) | 180° | N/A (ion) | — | VALIDATED |
| NO₂⁻ | 18 | −1 | resonance | Bent (AX₂E) | ~115° (lit.) | N/A (ion) | — | VALIDATED |
| NO₃⁻ | 24 | −1 | resonance, 3 equivalent | Trigonal planar (AX₃) | 120° | N/A (ion) | fig2_2 | VALIDATED |
| N₂O | 16 | 0 | resonance, 2 non-equivalent contributors | Linear (N–N–O) | 180° | N/A | — | VALIDATED (Worked Example 6.4) |
| O₃ | 18 | 0 | resonance, 2 equivalent | Bent (AX₂E) | ~117° (lit.) | Polar | — | VALIDATED (Worked Example 6.1) |
| SO₂ | 18 | 0 | resonance, 2 equivalent | Bent (AX₂E) | ~119.5° | Polar | — | VALIDATED (Worked Example 6.5) |
| SO₃ | 24 | 0 | none (single structure suffices) | Trigonal planar (AX₃) | 120° | Nonpolar (μ=0) | — | VALIDATED (Worked Example 6.5) |
| SO₄²⁻ | 32 | −2 | resonance | Tetrahedral (AX₄) | 109.5° | N/A (ion) | — | VALIDATED (Worked Example 2.2) |
| CO₃²⁻ | 24 | −2 | resonance, 3 equivalent | Trigonal planar (AX₃) | 120° | N/A (ion) | — | VALIDATED (Worked Example 6.2) |
| HCO₃⁻ | 24 | −1 | partial resonance (2 of 3 O only) | Trigonal-planar-ish at C | ~120° | N/A (ion) | — | VALIDATED (Worked Example 6.3) |
| SCN⁻ | 16 | −1 | resonance, 2 candidates ranked | Linear (trivial) | 180° | N/A (ion) | — | VALIDATED (Worked Example 2.6) |
| OCN⁻ | 16 | −1 | single dominant structure | Linear (trivial) | 180° | N/A (ion) | — | VALIDATED (Worked Example 6.7) |
| ClO₂⁻ | 20 | −1 | resonance, 2 equivalent | Bent (AX₂E₂) | <109.5° | N/A (ion) | — | VALIDATED (Worked Example 6.6) |
| ClO₃⁻ | 26 | −1 | resonance, 3 equivalent | Pyramidal (AX₃E) | <109.5° | N/A (ion) | — | VALIDATED (Worked Example 6.6) |
| ClO₄⁻ | 32 | −1 | resonance, 4 equivalent | Tetrahedral (AX₄) | 109.5° | N/A (ion) | — | VALIDATED (Worked Example 6.6) |
| BF₃ | 24 | 0 | 3 per F | Trigonal planar (AX₃) | 120° | Nonpolar (μ=0) | fig2_4 (back-bonding refinement) | VALIDATED |
| BF₄⁻ | 32 | −1 | 3 per F | Tetrahedral (AX₄) | 109.5° | N/A (ion) | — | VALIDATED |
| BeCl₂ | 16 | 0 | 3 per Cl | Linear (AX₂) | 180° | Nonpolar (μ=0) | — | VALIDATED |
| AlCl₃ | 24 | 0 | 3 per Cl | Trigonal planar (monomer) | 120° | Nonpolar (monomer) | — | VALIDATED — MODEL LIMITATION EXPLAINED (dimerizes to Al₂Cl₆ in practice, §2.7a) |
| B₂H₆ | 12 | N/A (delocalized, not per-atom FC) | N/A | 4 terminal 2c–2e + 2 bridging 3c–2e | tetrahedral at each B | Nonpolar overall | fig2_3 | VALIDATED |
| PCl₅ | 40 | 0 | none | Trigonal bipyramidal (AX₅) | 90°/120°/180° | Nonpolar (μ=0) | — | VALIDATED |
| SF₄ | 34 | 0 | 1 equatorial | See-saw (AX₄E) | ~173°/~102° (distorted) | Polar | fig9_1 | VALIDATED |
| SF₆ | 48 | 0 | none | Octahedral (AX₆) | 90°/180° | Nonpolar (μ=0) | — | VALIDATED |
| ClF₃ | 28 | 0 | 2 equatorial | T-shaped (AX₃E₂) | ~87.5° (distorted) | Polar | — | VALIDATED |
| IF₅ | 42 | 0 | 1 axial-opposite | Square pyramidal (AX₅E) | ~81.9° basal (distorted) | Polar | — | VALIDATED |
| IF₇ | 56 | 0 | none | Pentagonal bipyramidal (AX₇) | 72°/90°/180° | Nonpolar (μ=0) | — | VALIDATED |
| XeF₂ | 22 | 0 | 3 equatorial | Linear (AX₂E₃) | 180° | Nonpolar (μ=0) | — | VALIDATED |
| XeF₄ | 36 | 0 | 2 trans | Square planar (AX₄E₂) | 90° | Nonpolar (μ=0) | fig9_2 | VALIDATED |
| XeF₆ | — (steric no. 7) | 0 | 1, stereochemically active but fluxional | Distorted octahedral (non-ideal) | variable | Small residual μ | — | MODEL LIMITATION EXPLAINED — explicit §9.6 exception, not forced into a clean AXE prediction |
| I₃⁻ | 22 | −1 | 3 equatorial (on central I) | Linear (isoelectronic with XeF₂) | 180° | N/A (ion) | — | VALIDATED |
| ICl₂⁻ | 22 | −1 | 3 equatorial (on central I) | Linear (isoelectronic with XeF₂) | 180° | N/A (ion) | — | VALIDATED |

**Totals: 43 species/ions individually validated with explicit electron count and geometry; 3 explicit MODEL LIMITATION EXPLAINED cases (O₂ Lewis-vs-MOT, AlCl₃ monomer-vs-dimer, XeF₆ fluxionality); 0 marked simply "named in prose without structure" — every entry above has a derivation traceable to a specific Part/section/worked example, not just a name.**
