## Part 13 — Integrated JEE Advanced Applications

This Part deliberately introduces no new theory — every question below is answered entirely using material already developed in Parts 1–12, cross-referenced explicitly, because integrated JEE Advanced questions are exactly this: recognizing which of several previously-learned tools applies, and applying more than one together.

### 13.1 Single-Correct

**Q1.** The correct order of N–O bond length in $\mathrm{NO_2^+}$, $\mathrm{NO_2}$, and $\mathrm{NO_2^-}$ is:
(A) $\mathrm{NO_2^+ < NO_2 < NO_2^-}$ (B) $\mathrm{NO_2^- < NO_2 < NO_2^+}$ (C) $\mathrm{NO_2 < NO_2^+ < NO_2^-}$ (D) All equal

*Reasoning:* From §2.10, average N–O bond order: $\mathrm{NO_2^+}$ (linear, two N=O double bonds, bond order 2 each, Worked structure §2.10) $>$ $\mathrm{NO_2}$ (bond order between 1 and 2, resonance-averaged, §6.6) $>$ $\mathrm{NO_2^-}$ (bond order between 1 and 2 but with more single-bond character due to the extra electron pair, §2.10). Higher bond order ⇒ shorter bond (§5.1). **Answer: (A)**, since higher bond order corresponds to shorter length and $\mathrm{NO_2^+}$ has the highest bond order.

**Q2.** Which of the following has a **zero** dipole moment?
(A) $\mathrm{SF_4}$ (B) $\mathrm{ClF_3}$ (C) $\mathrm{XeF_4}$ (D) $\mathrm{IF_5}$

*Reasoning:* From §9.4–9.5 and §5.6, only structures with a centrosymmetric or otherwise fully-cancelling bond-moment arrangement give $\mu=0$. $\mathrm{SF_4}$ (see-saw), $\mathrm{ClF_3}$ (T-shaped), and $\mathrm{IF_5}$ (square pyramidal) are all asymmetric, $\mu \ne 0$. $\mathrm{XeF_4}$ (square planar, Figure 9.2) is centrosymmetric — every Xe–F bond moment is exactly cancelled by the opposite one. **Answer: (C)**.

### 13.2 Multiple-Correct

**Q3.** Which of the following statements are correct?
(A) $\mathrm{B_2}$ is paramagnetic because of s–p mixing (§10.4). (B) The Born–Landé equation's close numerical fit to experiment for alkali halides proves the bonding is 100% ionic (§3.4). (C) A coordinate bond, once formed, cannot be distinguished from an ordinary covalent bond by any physical measurement (§2.4). (D) Resonance structures of $\mathrm{NO_3^-}$ physically interconvert rapidly at room temperature (§6.3).

*Reasoning:* (A) **Correct** — Worked Example 10.1 shows this explicitly. (B) **Incorrect** — §3.4's Model Limitation box explicitly warns against this exact inference; the equation is self-compensating. (C) **Correct** — §2.4's NH₄⁺ discussion establishes this directly. (D) **Incorrect** — §6.3's Common Trap box explicitly prohibits this framing; there is one real hybrid structure, not interconversion. **Answer: (A), (C)**.

**Q4.** Which of the following pairs are correctly matched by the *same* underlying physical mechanism?
(A) NH₃ vs. NF₃ dipole moment difference — and — Bent's rule bond-angle distortion in CHF₃ vs CH₂F₂. (B) Pseudo-noble-gas cation polarizing power — and — d-block maximum covalency via 3d→4p excitation. (C) O₂ paramagnetism (MOT) — and — B₂ paramagnetism (MOT). (D) Ice's low density — and — CsCl's 8:8 coordination.

*Reasoning:* (A) **Correct** — both trace to the same underlying issue of how substituent electronegativity redistributes s/p character and hence vector direction/magnitude (§5.5, §8.3, same mechanism at different scales). (C) **Correct** — both are direct, structurally analogous consequences of degenerate π-type orbitals being singly filled by Hund's rule (§10.4), even though they occur via different orbital-filling orders (unmixed for O₂, mixed for B₂). (B) is a mismatch — pseudo-noble-gas polarizing power (§4.4) is a *shielding* effect, unrelated to *maximum covalency via d-orbital availability* (a completely different, expanded-octet-type mechanism, §2.7b). (D) is a mismatch — ice's density anomaly is a hydrogen-bonding geometric consequence (§11.4); CsCl's coordination is a radius-ratio packing consequence (§3.15-adjacent, unrelated mechanism). **Answer: (A), (C)**.

### 13.3 Assertion–Reason

**Q5.** **Assertion:** The lattice enthalpy of $\mathrm{MgO}$ is much greater than that of $\mathrm{NaCl}$.
**Reason:** The ionic radii of $\mathrm{Mg^{2+}}$ and $\mathrm{O^{2-}}$ are smaller than those of $\mathrm{Na^+}$ and $\mathrm{Cl^-}$, and the charges are higher.

*Reasoning:* Both statements are true (§3.5, Worked Example 3.2: lattice energy $\propto z^+z^-$ and $\propto 1/r_0$, and both charge and size favour MgO here), and the Reason **correctly and completely explains** the Assertion (both the charge-product and size contributions to the Born–Landé equation point the same direction for this specific pair). **Answer: both true, Reason is the correct explanation of Assertion.**

**Q6.** **Assertion:** $\mathrm{XeF_6}$ is predicted by simple VSEPR to be pentagonal pyramidal, but is experimentally close to a distorted octahedron.
**Reason:** The lone pair in $\mathrm{XeF_6}$ is stereochemically inactive, exactly as in $\mathrm{[SbCl_6]^{3-}}$.

*Reasoning:* The Assertion is true (§9.6). The Reason is **false** — §9.6 explicitly distinguishes $\mathrm{XeF_6}$ (lone pair *stereochemically active but delocalized/fluxional*, causing the observed distortion) from $\mathrm{[SbCl_6]^{3-}}$-type anions (lone pair genuinely *inactive*, giving an *undistorted* octahedron) — these are explicitly the two contrasted cases in that section, not the same case. **Answer: Assertion true, Reason false.**

### 13.4 Matrix-Match

**Q7.** Match each species (Column I) with its correct magnetic character and bond order (Column II), drawing only on Table 10.1.

| Column I | Column II |
|---|---|
| (A) $\mathrm{O_2^{2-}}$ | (P) Paramagnetic, bond order 2.5 |
| (B) $\mathrm{N_2}$ | (Q) Diamagnetic, bond order 1 |
| (C) $\mathrm{O_2^+}$ | (R) Paramagnetic, bond order 1.5 |
| (D) $\mathrm{O_2^-}$ | (S) Diamagnetic, bond order 3 |

*Reasoning (directly from Table 10.1):* $\mathrm{O_2^{2-}}$: both degenerate $\pi^*$ orbitals completely filled — bond order $(8-6)/2 = 1$, no unpaired electrons, **diamagnetic** → (Q). $\mathrm{N_2}$: bond order 3, all electrons paired, diamagnetic → (S). $\mathrm{O_2^+}$: one $\pi^*$ electron — bond order $(8-3)/2 = 2.5$, one unpaired electron, paramagnetic → (P). $\mathrm{O_2^-}$: three $\pi^*$ electrons (one degenerate orbital paired, one singly occupied) — bond order $(8-5)/2 = 1.5$, one unpaired electron, paramagnetic → (R). **Answer: (A)-(Q), (B)-(S), (C)-(P), (D)-(R).**

*Common mistake:* assuming every oxygen-family species must be paramagnetic because O₂ is — $\mathrm{O_2^{2-}}$ (peroxide) is diamagnetic precisely because the added electrons complete the $\pi^*$ pair; the magnetic character must be read off the actual filling, never off the parent molecule.

### 13.5 Integer/Numerical

**Q8.** The dipole moment of a hypothetical diatomic molecule X–Y is $2.4$ D, and its bond length is $1.00$ Å. Calculate the percentage ionic character (nearest integer), using the method of Worked Example 5.3.

*Reasoning:* $\mu_{\text{calc}} = e \times d = (4.8\times10^{-10}\text{ esu})(1.00\times10^{-8}\text{ cm}) = 4.8\times10^{-18}\text{ esu cm} = 4.8\text{ D}$. $\%\text{ionic character} = (2.4/4.8)\times100 = 50\%$.

**Answer: 50**.

**Q9.** How many of the following species are **paramagnetic**: $\mathrm{O_2}$, $\mathrm{N_2}$, $\mathrm{O_2^-}$, $\mathrm{B_2}$, $\mathrm{C_2}$, $\mathrm{NO}$, $\mathrm{CO}$, $\mathrm{F_2}$?

*Reasoning:* From Table 10.1 and §10.6: $\mathrm{O_2}$ (P), $\mathrm{N_2}$ (D), $\mathrm{O_2^-}$ (P), $\mathrm{B_2}$ (P), $\mathrm{C_2}$ (D), $\mathrm{NO}$ (P), $\mathrm{CO}$ (D, isoelectronic with N₂, same bonding pattern), $\mathrm{F_2}$ (D). Paramagnetic count: $\mathrm{O_2, O_2^-, B_2, NO}$ = 4.

**Answer: 4**.

### 13.6 Comprehension

*Passage:* A student examines three species: $\mathrm{X = SO_3}$, $\mathrm{Y = SO_2}$, $\mathrm{Z = SO_4^{2-}}$.

**Q10.** Which of X, Y, Z requires resonance to explain its equal bond lengths, and which does not?

*Reasoning:* From §6.5 (Worked Example 6.5) and §2.5 (Worked Example 2.2): $\mathrm{SO_2}$ (Y) genuinely requires two resonance contributors to equalize its two S–O bonds. $\mathrm{SO_3}$ (X) does not strictly require resonance — a single symmetric structure with three S=O double bonds already gives equal bond lengths by molecular symmetry alone. $\mathrm{SO_4^{2-}}$ (Z) requires resonance among four equivalent contributors (extending the same logic as $\mathrm{CO_3^{2-}}$, Worked Example 6.2, to a tetrahedral rather than trigonal-planar case) to equalize all four S–O bonds.

**Q11.** Rank X, Y, Z by average S–O bond order.

*Reasoning:* $\mathrm{SO_3}$: bond order 2 (three S=O, no resonance-averaging needed, §6.5). $\mathrm{SO_2}$: bond order 1.5 (two equivalent resonance contributors, one S=O + one S–O each, §6.5). $\mathrm{SO_4^{2-}}$: using the minimal-formal-charge structure with two S=O and two S–O⁻ (§2.5, Worked Example 2.2's preferred structure), bond order $= (2\times2+2\times1)/4 = 1.5$.

**Answer:** $\mathrm{SO_3\ (2) > SO_2 = SO_4^{2-}\ (1.5)}$ — a genuinely counter-intuitive result worth flagging explicitly: despite $\mathrm{SO_4^{2-}}$ having more oxygen atoms and a higher negative charge, its *average* S–O bond order is the *same* as $\mathrm{SO_2}$'s, not higher, because the extra oxygens in $\mathrm{SO_4^{2-}}$ are accommodated partly through additional single, not double, bonds.

> **JEE Advanced Insight — the single most valuable habit from this integrated Part.** Every one of Q1–Q11 above was solved by **identifying which specific Part's tool applies**, not by fresh derivation. The core skill this chapter has been built to teach is not memorizing 200 individual facts, but recognizing — quickly and correctly — which of a small number of underlying mechanisms (energy minimization, formal charge, electronegativity-driven polarization, orbital overlap effectiveness, electron-domain repulsion, bonding/antibonding orbital character) is actually being tested in an unfamiliar-looking question.

### Part 13 Summary

This Part has deliberately introduced zero new chemistry — every question above was answered by direct application of a specific, cross-referenced tool from Parts 1–12, which is itself the point: JEE Advanced integration is the skill of correctly identifying which established tool a novel-looking question is actually testing, not a separate body of additional content to learn.

---

## Source Traceability — Part 13

| Source PDF | Pages | Material found | Destination | Status |
|---|---|---|---|---|
| Independently constructed | — | All 11 questions (Q1–Q11) newly written, each cross-referencing specific sections/worked-examples from Parts 1–12 rather than drawn from or paraphrasing any single source question bank, per the instruction not to reproduce source questions | §13.1–13.6 | INCORPORATED, independently constructed and internally cross-checked against the cited sections |
| `Topic Wise Questions/` (all five files) | Format/scope reference only | Used only to confirm the required question-format variety (single-correct, multi-correct, assertion-reason, matrix-match, integer, comprehension) was actually represented in this Part — no specific question content copied | — | Scope-check only, not a content source |

---

## Chapter-Level Concept Map and Visual Summary

![Concept map](figures/concept-maps/fig_chemical_bonding_concept_map.svg)

**Concept Map.** The organizing claim of this entire chapter, stated once at the top: electron distribution and total-energy lowering determine bonding, structure, and properties. Every arrow below it traces a specific, already-derived relationship — electron-domain arrangement → molecular geometry (Part 9); bonding/antibonding occupancy → bond order and magnetism (Part 10); charge and radius → lattice enthalpy (Part 3); polarisation → covalent character (Part 4) — not a generic "everything connects to everything" diagram.

![Visual summary part 1](figures/concept-maps/fig_chemical_bonding_visual_summary_1.svg)
![Visual summary part 2](figures/concept-maps/fig_chemical_bonding_visual_summary_2.svg)

**Visual Summary.** A compact, two-panel, last-minute revision overview of the single most load-bearing fact from each Part — deliberately not a restatement of everything covered, only the one idea each Part's worked examples most depend on.

## Chapter-Level Closing Note

Parts 1–13 are now complete as a connected sequence, saved individually (`chemical_bonding_part01-03.md` through `chemical_bonding_part13.md`) and merged into `chemical_bonding_complete.md`. The source-to-content matrix and progress ledger are updated to reflect this closing state.
